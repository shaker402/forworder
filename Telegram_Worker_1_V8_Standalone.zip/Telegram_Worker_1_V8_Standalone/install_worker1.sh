#!/usr/bin/env bash
set -Eeuo pipefail

BUNDLE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET_DIR="/opt/TelegramForwarder-worker1"
SERVICE="telegram-forwarder"
CONTAINER="telegram-forwarder-worker1"
ENV_FILE_ARG=""
TARGET_ID_ARG=""
TARGET_NAME_ARG=""
SKIP_LIVE_GEMINI="false"
SKIP_BIND="false"
SKIP_TELEGRAM_CHECK="false"
ROLLBACK_ARMED="false"
BACKUP_DIR=""
ENV_STAGING=""

log()  { printf '\n[+] %s\n' "$*"; }
warn() { printf '\n[!] %s\n' "$*" >&2; }
die()  { printf '\n[ERROR] %s\n' "$*" >&2; exit 1; }

usage() {
  printf '%s\n' \
    "Usage: sudo ./install_worker1.sh [options]" \
    "" \
    "Options:" \
    "  --target-dir PATH              Install path (default: /opt/TelegramForwarder-worker1)" \
    "  --env-file PATH               Required only for a fresh install" \
    "  --target-id ID                Override OUTPUT_GROUP_RAW_ID" \
    "  --target-name NAME            Override OUTPUT_GROUP_NAME" \
    "  --skip-live-gemini-check      Do not make one health call per Gemini slot" \
    "  --skip-bind                    Preserve existing rules without discovering new groups" \
    "  --skip-telegram-check          Do not authorize/discover target (existing settings required)" \
    "  -h, --help                    Show this help"
}

while [ "$#" -gt 0 ]; do
  case "$1" in
    --target-dir) TARGET_DIR="$2"; shift 2 ;;
    --env-file) ENV_FILE_ARG="$2"; shift 2 ;;
    --target-id) TARGET_ID_ARG="$2"; shift 2 ;;
    --target-name) TARGET_NAME_ARG="$2"; shift 2 ;;
    --skip-live-gemini-check) SKIP_LIVE_GEMINI="true"; shift ;;
    --skip-bind) SKIP_BIND="true"; shift ;;
    --skip-telegram-check) SKIP_TELEGRAM_CHECK="true"; shift ;;
    -h|--help) usage; exit 0 ;;
    *) die "Unknown option: $1" ;;
  esac
done

[ "${EUID:-$(id -u)}" -eq 0 ] || die "Run this installer as root."
TARGET_DIR="$(realpath -m -- "$TARGET_DIR")"
BUNDLE_DIR="$(realpath -m -- "$BUNDLE_DIR")"
case "$TARGET_DIR" in
  /|/opt|/usr|/etc|/root|/home|/var) die "Refusing broad target directory: $TARGET_DIR" ;;
esac
case "$BUNDLE_DIR/" in
  "$TARGET_DIR/"*) die "Run the installer from a bundle outside the target directory." ;;
esac

cleanup_temp() {
  if [ -n "$ENV_STAGING" ] && [ -f "$ENV_STAGING" ]; then
    rm -f -- "$ENV_STAGING"
  fi
}

rollback() {
  local status=$?
  if [ "$ROLLBACK_ARMED" != "true" ] || [ "$status" -eq 0 ]; then
    cleanup_temp
    return "$status"
  fi

  set +e
  trap - ERR
  warn "Installation failed; restoring the previous Worker 1 project."
  if [ -f "$TARGET_DIR/docker-compose.yml" ]; then
    (cd "$TARGET_DIR" && docker compose down --remove-orphans) >/dev/null 2>&1
  fi
  if [ -d "$TARGET_DIR" ]; then
    local failed_dir="${TARGET_DIR}.failed-v8-$(date +%Y%m%d-%H%M%S)"
    mv -- "$TARGET_DIR" "$failed_dir"
    warn "Failed new tree preserved at: $failed_dir"
  fi
  if [ -n "$BACKUP_DIR" ] && [ -d "$BACKUP_DIR" ]; then
    mv -- "$BACKUP_DIR" "$TARGET_DIR"
    if [ -f "$TARGET_DIR/docker-compose.yml" ]; then
      (cd "$TARGET_DIR" && docker compose up -d) >/dev/null 2>&1
    fi
    warn "Previous project restored: $TARGET_DIR"
  fi
  cleanup_temp
  exit "$status"
}
trap rollback ERR
trap cleanup_temp EXIT

for path in Dockerfile docker-compose.yml requirements.txt .env.example \
  message_listener.py models/models.py ai/gemini_provider.py \
  filter_policy_v8.py worker_tools/validate_env_structure.py; do
  [ -f "$BUNDLE_DIR/$path" ] || die "Bundle is incomplete: missing $path"
done

if [ -f "$BUNDLE_DIR/MANIFEST.sha256" ]; then
  log "Verifying bundle manifest..."
  (cd "$BUNDLE_DIR" && sha256sum -c MANIFEST.sha256)
fi

SOURCE_ENV=""
if [ -n "$ENV_FILE_ARG" ]; then
  SOURCE_ENV="$(realpath -m -- "$ENV_FILE_ARG")"
elif [ -f "$TARGET_DIR/.env" ]; then
  SOURCE_ENV="$TARGET_DIR/.env"
fi
[ -n "$SOURCE_ENV" ] && [ -f "$SOURCE_ENV" ] \
  || die "No existing .env found. Supply --env-file PATH for a fresh install."

ENV_STAGING="$(mktemp /tmp/telegram-worker1-env.XXXXXX)"
chmod 600 "$ENV_STAGING"
cp -- "$SOURCE_ENV" "$ENV_STAGING"
python3 "$BUNDLE_DIR/worker_tools/validate_env_structure.py" \
  --env "$ENV_STAGING" --required-keys 10

missing_commands=()
command -v docker >/dev/null 2>&1 || missing_commands+=(docker.io)
command -v python3 >/dev/null 2>&1 || missing_commands+=(python3)
if ! docker compose version >/dev/null 2>&1; then
  missing_commands+=(docker-compose-plugin)
fi
if [ "${#missing_commands[@]}" -gt 0 ]; then
  command -v apt-get >/dev/null 2>&1 \
    || die "Missing prerequisites: ${missing_commands[*]}"
  log "Installing missing prerequisites: ${missing_commands[*]}"
  export DEBIAN_FRONTEND=noninteractive
  apt-get update -y
  apt-get install -y ca-certificates "${missing_commands[@]}"
  systemctl enable --now docker >/dev/null 2>&1 || true
fi
docker compose version >/dev/null 2>&1 || die "Docker Compose v2 is required."

if [ -d "$TARGET_DIR" ]; then
  log "Stopping the previous Worker 1 container..."
  if [ -f "$TARGET_DIR/docker-compose.yml" ]; then
    (cd "$TARGET_DIR" && docker compose down --remove-orphans) || true
  fi
  BACKUP_DIR="${TARGET_DIR}.backup-before-v8-$(date +%Y%m%d-%H%M%S)"
  mv -- "$TARGET_DIR" "$BACKUP_DIR"
  warn "Recoverable backup created: $BACKUP_DIR"
fi

ROLLBACK_ARMED="true"
mkdir -p -- "$TARGET_DIR"
cp -a -- "$BUNDLE_DIR/." "$TARGET_DIR/"

for state_dir in db logs sessions temp ufb/config rss/data rss/media; do
  mkdir -p -- "$TARGET_DIR/$state_dir"
  if [ -n "$BACKUP_DIR" ] && [ -d "$BACKUP_DIR/$state_dir" ]; then
    cp -a -- "$BACKUP_DIR/$state_dir/." "$TARGET_DIR/$state_dir/"
  fi
done
if [ -n "$BACKUP_DIR" ] && [ -d "$BACKUP_DIR/config" ]; then
  cp -a -- "$BACKUP_DIR/config/." "$TARGET_DIR/config/"
fi

cp -- "$ENV_STAGING" "$TARGET_DIR/.env"
chmod 600 "$TARGET_DIR/.env"

env_updates=(
  --set "GEMINI_REQUIRED_KEY_COUNT=10"
  --set "GEMINI_API_BASE="
  --set "NATIVE_QUOTE_FORWARD=true"
  --set "NATIVE_QUOTE_FALLBACK_COPY=true"
  --set "AUTO_BIND_NEW_CHATS=true"
)
if [ -n "$TARGET_ID_ARG" ]; then
  env_updates+=(--set "OUTPUT_GROUP_RAW_ID=$TARGET_ID_ARG")
fi
if [ -n "$TARGET_NAME_ARG" ]; then
  env_updates+=(--set "OUTPUT_GROUP_NAME=$TARGET_NAME_ARG")
fi
python3 "$TARGET_DIR/worker_tools/merge_env_defaults.py" \
  --env "$TARGET_DIR/.env" --defaults "$TARGET_DIR/.env.example" \
  "${env_updates[@]}"

get_env_value() {
  local name="$1"
  awk -v wanted="$name" '
    index($0, wanted "=") == 1 { value=substr($0, length(wanted)+2) }
    END { print value }
  ' "$TARGET_DIR/.env"
}

OUTPUT_RAW="$(get_env_value OUTPUT_GROUP_RAW_ID)"
[ -n "$OUTPUT_RAW" ] || die "OUTPUT_GROUP_RAW_ID is missing from .env"
case "$OUTPUT_RAW" in *[!0-9-]*|'') die "OUTPUT_GROUP_RAW_ID must be numeric" ;; esac

cd "$TARGET_DIR"
log "Checking Python syntax and Compose configuration..."
python3 -m compileall -q \
  ai filters handlers managers models rss scheduler ufb utils worker_tools \
  auto_bind_new_chat.py bulk_bind_all.py bulk_configure_student_filter.py \
  filter_policy_v8.py main.py message_listener.py native_forward.py
docker compose config --quiet

log "Building the self-contained Worker 1 image from the bundled source..."
docker compose build "$SERVICE"

log "Running zero-network regression tests inside the final image..."
for test_file in \
  worker_tools/prefilter_recall_selftest.py \
  worker_tools/classifier_contract_selftest.py \
  worker_tools/gemini_pool_selftest.py \
  worker_tools/native_forward_selftest.py \
  worker_tools/db_session_selftest.py \
  worker_tools/bulk_policy_selftest.py \
  worker_tools/auto_bind_selftest.py; do
  docker compose run --rm -T --no-deps "$SERVICE" python "/app/$test_file"
done
docker compose run --rm -T --no-deps "$SERVICE" \
  python /app/worker_tools/evaluate_gemini_filter.py --validate-only

if [ "$SKIP_TELEGRAM_CHECK" != "true" ]; then
  log "Checking the authenticated Telegram user session..."
  printf '%s\n' "Telegram may request a login code or 2FA password on a fresh install."
  docker compose run --rm --no-deps "$SERVICE" \
    python /app/worker_tools/authorize_user.py

  log "Resolving the exact destination through the authenticated user client..."
  discovery_args=(--target-id "$OUTPUT_RAW")
  if [ -n "$TARGET_NAME_ARG" ]; then
    discovery_args+=(--target-name "$TARGET_NAME_ARG")
  fi
  DISCOVERY="$(
    docker compose run --rm -T --no-deps "$SERVICE" \
      python /app/worker_tools/discover_target.py "${discovery_args[@]}"
  )"
  printf '%s\n' "$DISCOVERY"
  NATIVE_TARGET="$(
    printf '%s\n' "$DISCOVERY" \
      | sed -n 's/^NATIVE_QUOTE_TARGET=//p' \
      | tail -n1 \
      | tr -d '\r[:space:]'
  )"
  case "$NATIVE_TARGET" in -[0-9]*) ;; *) die "Target discovery returned no marked Telegram ID" ;; esac
  python3 "$TARGET_DIR/worker_tools/merge_env_defaults.py" \
    --env "$TARGET_DIR/.env" --defaults "$TARGET_DIR/.env.example" \
    --set "NATIVE_QUOTE_TARGET=$NATIVE_TARGET" \
    --set "AUTO_BIND_TARGET_ID=$OUTPUT_RAW"
else
  NATIVE_TARGET="$(get_env_value NATIVE_QUOTE_TARGET)"
  [ -n "$NATIVE_TARGET" ] || die "--skip-telegram-check requires NATIVE_QUOTE_TARGET"
fi

python3 "$TARGET_DIR/worker_tools/validate_env_structure.py" \
  --env "$TARGET_DIR/.env" --required-keys 10

if [ "$SKIP_LIVE_GEMINI" != "true" ]; then
  log "Testing all ten Gemini key slots without displaying key values..."
  docker compose run --rm -T --no-deps "$SERVICE" \
    python /app/worker_tools/gemini_key_health.py \
      --live --require-count 10 --minimum-healthy 10
else
  warn "Live Gemini slot check skipped by request."
fi

if [ "$SKIP_BIND" != "true" ]; then
  log "Binding every visible group/channel to destination $OUTPUT_RAW..."
  docker compose run --rm -T --no-deps "$SERVICE" \
    python /app/bulk_bind_all.py --target-id "$OUTPUT_RAW" --apply
fi

log "Applying the Shaker-derived V8 policy to all destination rules..."
docker compose run --rm -T --no-deps "$SERVICE" \
  python /app/bulk_configure_student_filter.py \
    --target-id "$OUTPUT_RAW" --apply

log "Starting Worker 1..."
docker compose up -d --force-recreate "$SERVICE"

log "Waiting for a stable, healthy container..."
healthy="false"
for _attempt in $(seq 1 45); do
  running="$(docker inspect -f '{{.State.Running}}' "$CONTAINER" 2>/dev/null || true)"
  health="$(docker inspect -f '{{if .State.Health}}{{.State.Health.Status}}{{else}}none{{end}}' "$CONTAINER" 2>/dev/null || true)"
  if [ "$running" = "true" ] && [ "$health" = "healthy" ]; then
    healthy="true"
    break
  fi
  if [ "$running" = "false" ] || [ "$health" = "unhealthy" ]; then
    break
  fi
  sleep 2
done
if [ "$healthy" != "true" ]; then
  docker compose ps || true
  docker compose logs --tail=200 "$SERVICE" || true
  die "Worker 1 did not reach a healthy stable state"
fi

log "Verifying the live database and filter configuration..."
docker compose exec -T "$SERVICE" python /app/worker_tools/verify_runtime.py
docker compose ps

ROLLBACK_ARMED="false"
trap - ERR
cleanup_temp
trap - EXIT

printf '\n%s\n' \
  "Worker 1 V8 standalone installation completed." \
  "Project: $TARGET_DIR" \
  "Container: $CONTAINER" \
  "Destination raw ID: $OUTPUT_RAW" \
  "Native destination: $NATIVE_TARGET" \
  "Backup retained: ${BACKUP_DIR:-none (fresh install)}" \
  "Logs: cd $TARGET_DIR && docker compose logs -f --tail=100 $SERVICE"
