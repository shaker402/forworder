from typing import Optional, List, Dict
from .base import BaseAIProvider
import asyncio
import hashlib
import json
import logging
import os
import re
import sqlite3
import threading
import time
import unicodedata
import urllib.error
import urllib.parse
import urllib.request

logger = logging.getLogger(__name__)

# Marker used by the installer/verification logic.
MULTI_KEY_GEMINI_POOL = True
CLASSIFIER_CONTRACT_V8 = "CLASSIFIER_CONTRACT: SHAKER_WANTED_V8"


class GeminiOpenAIProvider:
    """Existing OpenAI-compatible Gemini path (kept for compatibility)."""

    def __init__(self):
        # Import only when GEMINI_API_BASE explicitly requests this path.
        from .openai_base_provider import OpenAIBaseProvider
        self._provider = OpenAIBaseProvider(
            env_prefix="GEMINI",
            default_model="gemini-pro",
            default_api_base="",
        )

    async def initialize(self, **kwargs):
        return await self._provider.initialize(**kwargs)

    async def process_message(self, *args, **kwargs):
        return await self._provider.process_message(*args, **kwargs)


class GeminiRequestError(RuntimeError):
    def __init__(self, message, status=None, body="", retry_after=None):
        super().__init__(message)
        self.status = status
        self.body = body or ""
        self.retry_after = retry_after


# Heavrnl's get_ai_provider() creates a fresh GeminiProvider for each AI call.
# Pool state therefore lives at module scope so every provider instance shares
# the same round-robin index and cooldown state.
_POOL_LOCK = threading.Lock()
_POOL_NEXT_INDEX = 0
_POOL_COOLDOWN_UNTIL = {}
_POOL_FAILURES = {}
_HTTP_SEMAPHORE = None
_HTTP_SEMAPHORE_SIZE = None
_CACHE_LOCK = threading.Lock()
_CACHE_CONNECTION = None
_CACHE_WRITES = 0


def _env_bool(name, default=False):
    fallback = "true" if default else "false"
    return os.getenv(name, fallback).strip().lower() in {
        "1", "true", "yes", "on"
    }


def _classifier_mode(prompt):
    return bool(prompt and CLASSIFIER_CONTRACT_V8 in prompt)


def _normalize_cache_text(value):
    value = unicodedata.normalize("NFKC", value or "").casefold()
    value = re.sub(r"(?i)\b(?:https?://|www\.)\S+|\b(?:t\.me|wa\.me)/\S+", "[URL]", value)
    value = re.sub(r"(?i)\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", "[EMAIL]", value)
    value = re.sub(r"@[A-Za-z0-9_]{4,}", "[USERNAME]", value)
    value = re.sub(r"(?<!\d)(?:\+?\d[\d\s().-]{6,}\d)(?!\d)", "[PHONE]", value)
    value = re.sub(r"\s+", " ", value).strip()
    return value


def _stable_classifier_prompt(prompt):
    """Remove dynamic source context while retaining the versioned policy."""
    prompt = prompt or ""
    start_marker = "Use the following one recent source-chat message"
    end_marker = "The NEW message has priority"
    start = prompt.find(start_marker)
    end = prompt.find(end_marker, start + 1) if start >= 0 else -1
    if start >= 0 and end > start:
        return prompt[:start] + "<DYNAMIC_SOURCE_CONTEXT>\n" + prompt[end:]
    return prompt


def _classifier_cacheable(message, images=None):
    if images:
        return False
    minimum = _env_int("GEMINI_CLASSIFIER_CACHE_MIN_CHARS", 60, 1)
    return len(_normalize_cache_text(message)) >= minimum


def _classifier_cache_key(model_name, prompt, message):
    material = "\n".join(
        (
            "SHAKER_WANTED_V8",
            str(model_name or ""),
            _normalize_cache_text(_stable_classifier_prompt(prompt)),
            _normalize_cache_text(message),
        )
    )
    return hashlib.sha256(material.encode("utf-8")).hexdigest()


def _cache_enabled():
    return _env_bool("GEMINI_CLASSIFIER_CACHE", True)


def _get_cache_connection():
    global _CACHE_CONNECTION
    if _CACHE_CONNECTION is not None:
        return _CACHE_CONNECTION

    path = os.getenv(
        "GEMINI_CLASSIFIER_CACHE_PATH",
        "/app/db/gemini_classifier_cache.sqlite3",
    ).strip()
    directory = os.path.dirname(path)
    if directory:
        os.makedirs(directory, exist_ok=True)

    connection = sqlite3.connect(path, timeout=10, check_same_thread=False)
    connection.execute("PRAGMA journal_mode=WAL")
    connection.execute("PRAGMA synchronous=NORMAL")
    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS classifier_cache (
            cache_key TEXT PRIMARY KEY,
            decision TEXT NOT NULL,
            created_at INTEGER NOT NULL,
            hits INTEGER NOT NULL DEFAULT 0
        )
        """
    )
    connection.commit()
    _CACHE_CONNECTION = connection
    return connection


def _cache_get(cache_key):
    if not _cache_enabled():
        return None
    ttl_seconds = _env_int("GEMINI_CLASSIFIER_CACHE_TTL_DAYS", 30, 1) * 86400
    cutoff = int(time.time()) - ttl_seconds
    try:
        with _CACHE_LOCK:
            connection = _get_cache_connection()
            row = connection.execute(
                "SELECT decision FROM classifier_cache "
                "WHERE cache_key = ? AND created_at >= ?",
                (cache_key, cutoff),
            ).fetchone()
            if not row:
                return None
            connection.execute(
                "UPDATE classifier_cache SET hits = hits + 1 WHERE cache_key = ?",
                (cache_key,),
            )
            connection.commit()
            return row[0] if row[0] in {"KEEP", "#SKIP"} else None
    except Exception as exc:
        logger.warning("Gemini classifier cache read failed: %s", exc)
        return None


def _cache_put(cache_key, decision):
    global _CACHE_WRITES
    if not _cache_enabled() or decision not in {"KEEP", "#SKIP"}:
        return
    try:
        with _CACHE_LOCK:
            connection = _get_cache_connection()
            connection.execute(
                "INSERT OR REPLACE INTO classifier_cache "
                "(cache_key, decision, created_at, hits) VALUES (?, ?, ?, 0)",
                (cache_key, decision, int(time.time())),
            )
            _CACHE_WRITES += 1
            if _CACHE_WRITES % 500 == 0:
                ttl_seconds = _env_int(
                    "GEMINI_CLASSIFIER_CACHE_TTL_DAYS", 30, 1
                ) * 86400
                cutoff = int(time.time()) - ttl_seconds
                connection.execute(
                    "DELETE FROM classifier_cache WHERE created_at < ?",
                    (cutoff,),
                )
                max_rows = _env_int(
                    "GEMINI_CLASSIFIER_CACHE_MAX_ROWS", 200000, 1000
                )
                count = connection.execute(
                    "SELECT COUNT(*) FROM classifier_cache"
                ).fetchone()[0]
                if count > max_rows:
                    connection.execute(
                        "DELETE FROM classifier_cache WHERE cache_key IN ("
                        "SELECT cache_key FROM classifier_cache "
                        "ORDER BY created_at ASC LIMIT ?)",
                        (count - max_rows,),
                    )
            connection.commit()
    except Exception as exc:
        logger.warning("Gemini classifier cache write failed: %s", exc)


def _normalize_classifier_result(result, original_message):
    value = (result or "").strip()
    if value.startswith("```") and value.endswith("```"):
        value = value[3:-3].strip()
        if value.lower().startswith("text\n"):
            value = value[5:].strip()
    if value.upper() == "KEEP":
        return "KEEP", original_message
    if value.upper() == "#SKIP":
        return "#SKIP", "#SKIP"
    raise GeminiRequestError(
        "Gemini violated the V8 classifier output contract",
        status=200,
        body=value[:500],
    )


def _load_api_keys():
    """Return a de-duplicated key pool; support the old single-key setting."""
    raw = os.getenv("GEMINI_API_KEYS", "").strip()

    if raw:
        normalized = raw.replace(";", ",").replace("\n", ",").replace("\r", ",")
        candidates = []
        for chunk in normalized.split(","):
            candidates.extend(chunk.split())
    else:
        legacy = os.getenv("GEMINI_API_KEY", "").strip()
        candidates = [legacy] if legacy else []

    keys = []
    seen = set()
    for key in candidates:
        key = key.strip()
        if key and key not in seen:
            seen.add(key)
            keys.append(key)

    return keys


def get_pool_diagnostics():
    """Return counts and slot numbers only; API-key material is never exposed."""
    keys = _load_api_keys()
    now = time.monotonic()
    with _POOL_LOCK:
        cooling_slots = [
            index + 1
            for index, key in enumerate(keys)
            if _POOL_COOLDOWN_UNTIL.get(key, 0.0) > now
        ]
        failure_counts = {
            index + 1: _POOL_FAILURES.get(key, 0)
            for index, key in enumerate(keys)
            if _POOL_FAILURES.get(key, 0)
        }
    return {
        "configured_keys": len(keys),
        "custom_compatible_base": bool(os.getenv("GEMINI_API_BASE", "").strip()),
        "cooling_slots": cooling_slots,
        "failure_counts_by_slot": failure_counts,
        "max_parallel_requests": _env_int(
            "GEMINI_MAX_PARALLEL_REQUESTS", 10, 1
        ),
    }


def _reset_runtime_state_for_tests():
    global _POOL_NEXT_INDEX, _HTTP_SEMAPHORE, _HTTP_SEMAPHORE_SIZE
    global _CACHE_CONNECTION, _CACHE_WRITES
    with _POOL_LOCK:
        _POOL_NEXT_INDEX = 0
        _POOL_COOLDOWN_UNTIL.clear()
        _POOL_FAILURES.clear()
        _HTTP_SEMAPHORE = None
        _HTTP_SEMAPHORE_SIZE = None
    with _CACHE_LOCK:
        if _CACHE_CONNECTION is not None:
            _CACHE_CONNECTION.close()
        _CACHE_CONNECTION = None
        _CACHE_WRITES = 0


def _env_int(name, default, minimum=None):
    try:
        value = int(os.getenv(name, str(default)).strip())
    except Exception:
        value = int(default)
    if minimum is not None:
        value = max(int(minimum), value)
    return value


def _env_float(name, default, minimum=None):
    try:
        value = float(os.getenv(name, str(default)).strip())
    except Exception:
        value = float(default)
    if minimum is not None:
        value = max(float(minimum), value)
    return value


def _fail_open_enabled():
    return os.getenv("GEMINI_FAIL_OPEN", "true").strip().lower() in {
        "1", "true", "yes", "on"
    }


def _get_http_semaphore():
    global _HTTP_SEMAPHORE, _HTTP_SEMAPHORE_SIZE
    size = _env_int("GEMINI_MAX_PARALLEL_REQUESTS", 10, 1)

    with _POOL_LOCK:
        if _HTTP_SEMAPHORE is None or _HTTP_SEMAPHORE_SIZE != size:
            _HTTP_SEMAPHORE = threading.BoundedSemaphore(size)
            _HTTP_SEMAPHORE_SIZE = size
        return _HTTP_SEMAPHORE


def _candidate_indices(keys, max_attempts):
    """
    Return healthy key slots in round-robin order.

    If every key is currently cooling down, return an empty list. This avoids
    hammering a known-exhausted 10-key pool for every incoming Telegram message.
    """
    global _POOL_NEXT_INDEX

    if not keys:
        return []

    now = time.monotonic()
    total = len(keys)

    with _POOL_LOCK:
        start = _POOL_NEXT_INDEX % total
        _POOL_NEXT_INDEX = (_POOL_NEXT_INDEX + 1) % total

        order = [(start + offset) % total for offset in range(total)]
        healthy = [
            index
            for index in order
            if _POOL_COOLDOWN_UNTIL.get(keys[index], 0.0) <= now
        ]
        return healthy[:max_attempts]


def _soonest_cooldown_remaining(keys):
    now = time.monotonic()
    with _POOL_LOCK:
        remaining = [
            max(0.0, _POOL_COOLDOWN_UNTIL.get(key, 0.0) - now)
            for key in keys
        ]
    return min(remaining) if remaining else 0.0


def _mark_failure(key, seconds):
    with _POOL_LOCK:
        _POOL_FAILURES[key] = _POOL_FAILURES.get(key, 0) + 1
        _POOL_COOLDOWN_UNTIL[key] = max(
            _POOL_COOLDOWN_UNTIL.get(key, 0.0),
            time.monotonic() + max(0.0, seconds),
        )


def _mark_success(key):
    with _POOL_LOCK:
        _POOL_FAILURES[key] = 0
        _POOL_COOLDOWN_UNTIL.pop(key, None)


def _extract_retry_after(headers, body):
    if headers:
        try:
            value = headers.get("Retry-After")
            if value:
                return max(0.0, float(value))
        except Exception:
            pass

    try:
        payload = json.loads(body or "{}")
        details = payload.get("error", {}).get("details", [])
        for detail in details:
            retry = detail.get("retryDelay") or detail.get("retry_delay")
            if not retry:
                continue
            if isinstance(retry, str) and retry.endswith("s"):
                return max(0.0, float(retry[:-1]))
            if isinstance(retry, dict):
                return max(0.0, float(retry.get("seconds", 0)))
    except Exception:
        pass

    # Some SDK/backend error text includes "retry in 4.28s".
    match = re.search(r"retry\s+in\s+([0-9.]+)s", body or "", re.I)
    if match:
        try:
            return max(0.0, float(match.group(1)))
        except Exception:
            pass

    return None


def _is_key_specific_bad_request(error):
    if error.status != 400:
        return False
    text = (error.body or "").lower()
    markers = (
        "api_key_invalid",
        "api key not valid",
        "api key invalid",
        "api key expired",
        "api_key_service_blocked",
    )
    return any(marker in text for marker in markers)


def _is_retriable_on_another_key(error):
    if error.status in (401, 403, 408, 429, 500, 502, 503, 504):
        return True
    if error.status is None:
        return True
    return _is_key_specific_bad_request(error)


def _cooldown_seconds_for(error):
    if error.status == 429:
        configured = _env_float("GEMINI_KEY_COOLDOWN_SECONDS", 60, 1)
        if error.retry_after is not None:
            return max(configured, error.retry_after)
        return configured

    if error.status in (400, 401, 403):
        return _env_float("GEMINI_KEY_AUTH_COOLDOWN_SECONDS", 1800, 60)

    return _env_float("GEMINI_KEY_ERROR_COOLDOWN_SECONDS", 15, 1)


def _response_text(payload):
    texts = []
    for candidate in payload.get("candidates", []) or []:
        content = candidate.get("content") or {}
        for part in content.get("parts", []) or []:
            text = part.get("text")
            if text:
                texts.append(text)

    if texts:
        return "".join(texts)

    feedback = payload.get("promptFeedback") or {}
    block_reason = feedback.get("blockReason") or feedback.get("block_reason")
    if block_reason:
        raise GeminiRequestError(
            f"Gemini returned no text (prompt blocked: {block_reason})",
            status=200,
            body=json.dumps(payload, ensure_ascii=False)[:2000],
        )

    raise GeminiRequestError(
        "Gemini returned an empty response",
        status=200,
        body=json.dumps(payload, ensure_ascii=False)[:2000],
    )


def _generate_sync(api_key, model_name, message, prompt, images):
    classifier_mode = _classifier_mode(prompt)
    if classifier_mode:
        user_text = f"<NEW_MESSAGE>\n{message}\n</NEW_MESSAGE>"
    else:
        user_text = message

    parts = [{"text": user_text}]

    if images:
        for image in images:
            try:
                mime_type = image["mime_type"]
                data = image["data"]
            except Exception as exc:
                raise GeminiRequestError(
                    f"Invalid Gemini image payload: {exc}",
                    status=400,
                ) from exc

            parts.append(
                {
                    "inlineData": {
                        "mimeType": mime_type,
                        "data": data,
                    }
                }
            )

    payload = {
        "contents": [
            {
                "role": "user",
                "parts": parts,
            }
        ],
        # Deterministic classifier: faster, repeatable KEEP/#SKIP decisions.
        "generationConfig": {
            "temperature": 0.0,
            "topP": 0.1,
            "candidateCount": 1,
        },
        # Preserve the behavior of the project's original Gemini provider.
        "safetySettings": [
            {"category": "HARM_CATEGORY_HARASSMENT", "threshold": "BLOCK_NONE"},
            {"category": "HARM_CATEGORY_HATE_SPEECH", "threshold": "BLOCK_NONE"},
            {"category": "HARM_CATEGORY_SEXUALLY_EXPLICIT", "threshold": "BLOCK_NONE"},
            {"category": "HARM_CATEGORY_DANGEROUS_CONTENT", "threshold": "BLOCK_NONE"},
        ],
    }

    if prompt:
        payload["systemInstruction"] = {
            "parts": [{"text": prompt}],
        }

    if classifier_mode:
        payload["generationConfig"]["maxOutputTokens"] = 8
        payload["generationConfig"]["responseMimeType"] = "text/plain"

    base = os.getenv(
        "GEMINI_REST_API_BASE",
        "https://generativelanguage.googleapis.com/v1beta",
    ).strip().rstrip("/")

    model_path = urllib.parse.quote(model_name, safe="-_.")
    url = f"{base}/models/{model_path}:generateContent"

    request = urllib.request.Request(
        url,
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers={
            "Content-Type": "application/json; charset=utf-8",
            "Accept": "application/json",
            "x-goog-api-key": api_key,
            "User-Agent": "Heavrnl-TelegramForwarder-GeminiPool/2.0",
        },
        method="POST",
    )

    timeout = _env_float("GEMINI_REQUEST_TIMEOUT_SECONDS", 45, 5)
    semaphore = _get_http_semaphore()

    try:
        with semaphore:
            with urllib.request.urlopen(request, timeout=timeout) as response:
                raw = response.read().decode("utf-8", errors="replace")
    except urllib.error.HTTPError as exc:
        try:
            body = exc.read().decode("utf-8", errors="replace")
        except Exception:
            body = ""
        retry_after = _extract_retry_after(exc.headers, body)
        raise GeminiRequestError(
            f"Gemini HTTP {exc.code}",
            status=exc.code,
            body=body,
            retry_after=retry_after,
        ) from None
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        reason = getattr(exc, "reason", None) or str(exc)
        raise GeminiRequestError(
            f"Gemini network error: {reason}",
            status=None,
        ) from None

    try:
        decoded = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise GeminiRequestError(
            f"Gemini returned invalid JSON: {exc}",
            status=200,
            body=raw[:2000],
        ) from None

    if isinstance(decoded, dict) and decoded.get("error"):
        error = decoded["error"]
        raise GeminiRequestError(
            f"Gemini API error: {error.get('message', 'unknown error')}",
            status=error.get("code"),
            body=raw[:2000],
        )

    return _response_text(decoded)


class GeminiProvider(BaseAIProvider):
    def __init__(self):
        self.model_name = None
        self.provider = None
        self.api_keys = []

    async def initialize(self, **kwargs):
        api_base = os.getenv("GEMINI_API_BASE", "").strip()
        configured_keys = _load_api_keys()
        required_count = _env_int("GEMINI_REQUIRED_KEY_COUNT", 0, 0)

        if api_base:
            if required_count > 1:
                raise ValueError(
                    "GEMINI_API_BASE disables native key rotation; clear it to "
                    f"use the required {required_count}-key pool"
                )
            logger.info(
                "Detected GEMINI_API_BASE; using existing OpenAI-compatible "
                "Gemini provider (multi-key pool disabled for that custom base)."
            )
            self.provider = GeminiOpenAIProvider()
            await self.provider.initialize(**kwargs)
            return

        self.api_keys = configured_keys
        if not self.api_keys:
            raise ValueError(
                "Neither GEMINI_API_KEYS nor GEMINI_API_KEY is configured"
            )
        if required_count and len(self.api_keys) != required_count:
            raise ValueError(
                f"Expected exactly {required_count} unique Gemini API keys, "
                f"found {len(self.api_keys)}"
            )

        self.model_name = kwargs.get("model") or self.model_name or "gemini-pro"

        logger.debug(
            "Initialized Gemini multi-key pool: model=%s, keys=%d, max_parallel=%d",
            self.model_name,
            len(self.api_keys),
            _env_int("GEMINI_MAX_PARALLEL_REQUESTS", 10, 1),
        )

    async def process_message(
        self,
        message: str,
        prompt: Optional[str] = None,
        images: Optional[List[Dict[str, str]]] = None,
        **kwargs,
    ) -> str:
        if self.provider is None and not self.api_keys:
            await self.initialize(**kwargs)

        classifier_mode = _classifier_mode(prompt)
        cache_key = None
        cache_model = kwargs.get("model") or self.model_name or "gemini-pro"
        if classifier_mode and _classifier_cacheable(message, images):
            cache_key = _classifier_cache_key(
                cache_model,
                prompt,
                message,
            )
            cached_decision = await asyncio.to_thread(_cache_get, cache_key)
            if cached_decision:
                logger.debug(
                    "Gemini V8 classifier cache hit: decision=%s",
                    cached_decision,
                )
                return message if cached_decision == "KEEP" else "#SKIP"

        if self.provider:
            result = await self.provider.process_message(
                message,
                prompt,
                images,
                **kwargs,
            )
            if not classifier_mode:
                return result
            try:
                decision, mapped = _normalize_classifier_result(result, message)
            except GeminiRequestError:
                if _fail_open_enabled():
                    logger.exception(
                        "Custom Gemini provider violated V8 output contract; "
                        "preserving keyword-matched message."
                    )
                    return message
                raise
            if cache_key:
                await asyncio.to_thread(_cache_put, cache_key, decision)
            return mapped

        if not self.model_name:
            self.model_name = kwargs.get("model") or "gemini-pro"

        total = len(self.api_keys)
        max_attempts = min(
            total,
            _env_int("GEMINI_MAX_KEY_ATTEMPTS", total, 1),
        )

        candidates = _candidate_indices(self.api_keys, max_attempts)
        if not candidates:
            remaining = _soonest_cooldown_remaining(self.api_keys)
            if _fail_open_enabled():
                logger.error(
                    "All %d Gemini keys are cooling down (next probe %.1fs); "
                    "GEMINI_FAIL_OPEN=true, preserving keyword-matched message.",
                    total, remaining,
                )
                return message
            raise GeminiRequestError(
                f"All {total} Gemini API keys are cooling down; "
                f"next probe in approximately {remaining:.1f}s"
            )

        last_error = None

        for attempt_number, key_index in enumerate(candidates, start=1):
            api_key = self.api_keys[key_index]
            slot = key_index + 1

            logger.debug(
                "Gemini request: model=%s, key_slot=%d/%d, attempt=%d/%d",
                self.model_name,
                slot,
                total,
                attempt_number,
                len(candidates),
            )

            try:
                result = await asyncio.to_thread(
                    _generate_sync,
                    api_key,
                    self.model_name,
                    message,
                    prompt,
                    images,
                )
            except GeminiRequestError as exc:
                last_error = exc

                if not _is_retriable_on_another_key(exc):
                    logger.error(
                        "Gemini non-retriable failure: status=%s, "
                        "key_slot=%d/%d, error=%s",
                        exc.status,
                        slot,
                        total,
                        str(exc),
                    )
                    if _fail_open_enabled():
                        logger.warning(
                            "GEMINI_FAIL_OPEN=true: preserving keyword-matched message."
                        )
                        return message
                    raise

                cooldown = _cooldown_seconds_for(exc)
                _mark_failure(api_key, cooldown)

                logger.warning(
                    "Gemini key_slot=%d/%d failed: status=%s; cooldown=%.1fs; "
                    "trying another healthy key.",
                    slot,
                    total,
                    exc.status,
                    cooldown,
                )
                continue

            _mark_success(api_key)
            logger.debug(
                "Gemini request succeeded with key_slot=%d/%d",
                slot,
                total,
            )
            if not classifier_mode:
                return result

            try:
                decision, mapped = _normalize_classifier_result(result, message)
            except GeminiRequestError as exc:
                logger.error(
                    "Gemini V8 classifier returned malformed output: %s",
                    exc.body,
                )
                if _fail_open_enabled():
                    logger.warning(
                        "GEMINI_FAIL_OPEN=true: preserving keyword-matched message."
                    )
                    return message
                raise

            if cache_key:
                await asyncio.to_thread(_cache_put, cache_key, decision)
            return mapped

        if last_error is not None:
            if _fail_open_enabled():
                logger.error(
                    "All attempted Gemini keys failed; GEMINI_FAIL_OPEN=true, "
                    "preserving keyword-matched message. Last error: %s",
                    last_error,
                )
                return message
            raise last_error

        if _fail_open_enabled():
            logger.error(
                "No Gemini API key was available; GEMINI_FAIL_OPEN=true, "
                "preserving keyword-matched message."
            )
            return message
        raise GeminiRequestError("No Gemini API key was available")
