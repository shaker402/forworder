#!/usr/bin/env python3
"""Verify deployed files, key-pool routing, rule policy, and DB lifecycle."""

import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
os.chdir(ROOT)
sys.path.insert(0, str(ROOT))

from dotenv import load_dotenv

load_dotenv(ROOT / ".env", override=True)

from ai.gemini_provider import (
    CLASSIFIER_CONTRACT_V8,
    MULTI_KEY_GEMINI_POOL,
    get_pool_diagnostics,
)
from enums.enums import ForwardMode
from filter_policy_v8 import BLACKLIST, MODEL, PROMPT, REGEX_WHITELIST, WHITELIST
from models.models import Chat, ForwardRule, Keyword, get_pool_snapshot, get_session


def id_variants(value):
    try:
        number = abs(int(str(value).strip()))
    except (TypeError, ValueError):
        return set()
    variants = {number}
    rendered = str(number)
    if rendered.startswith("100") and len(rendered) > 3:
        variants.add(int(rendered[3:]))
    return variants


def main():
    if MULTI_KEY_GEMINI_POOL is not True:
        raise SystemExit("Direct Gemini pool marker is missing")
    diagnostics = get_pool_diagnostics()
    required_keys = int(os.getenv("GEMINI_REQUIRED_KEY_COUNT", "10") or "10")
    if diagnostics["configured_keys"] != required_keys:
        raise SystemExit(
            f"Expected {required_keys} unique Gemini keys, "
            f"found {diagnostics['configured_keys']}"
        )
    if diagnostics["custom_compatible_base"]:
        raise SystemExit("GEMINI_API_BASE bypasses the native multi-key pool")
    if CLASSIFIER_CONTRACT_V8 not in PROMPT:
        raise SystemExit("V8 classifier marker is missing")

    target_id = os.getenv("OUTPUT_GROUP_RAW_ID", "").strip()
    native_target = os.getenv("NATIVE_QUOTE_TARGET", "").strip()
    if not (id_variants(target_id) & id_variants(native_target)):
        raise SystemExit("Native target does not match OUTPUT_GROUP_RAW_ID")

    session = get_session()
    try:
        target = session.query(Chat).filter(
            Chat.telegram_chat_id == target_id
        ).first()
        if target is None:
            raise SystemExit("Destination is absent from the database")
        rules = session.query(ForwardRule).filter(
            ForwardRule.target_chat_id == target.id
        ).all()
        if not rules:
            raise SystemExit("No forwarding rule targets the destination")

        for rule in rules:
            if not rule.enable_rule or not rule.is_ai or not rule.is_keyword_after_ai:
                raise SystemExit(f"Rule {rule.id} is not fully enabled for V8 AI")
            if rule.ai_model != MODEL:
                raise SystemExit(f"Rule {rule.id} model differs from V8 policy")
            if rule.forward_mode != ForwardMode.WHITELIST_THEN_BLACKLIST:
                raise SystemExit(f"Rule {rule.id} has the wrong filter order")

        sample = rules[0]
        literal_count = session.query(Keyword).filter(
            Keyword.rule_id == sample.id,
            Keyword.is_blacklist == False,
            Keyword.is_regex == False,
        ).count()
        regex_count = session.query(Keyword).filter(
            Keyword.rule_id == sample.id,
            Keyword.is_blacklist == False,
            Keyword.is_regex == True,
        ).count()
        blacklist_count = session.query(Keyword).filter(
            Keyword.rule_id == sample.id,
            Keyword.is_blacklist == True,
        ).count()
        expected = (len(WHITELIST), len(REGEX_WHITELIST), len(BLACKLIST))
        actual = (literal_count, regex_count, blacklist_count)
        if actual != expected:
            raise SystemExit(f"Keyword counts differ: runtime={actual}, expected={expected}")
        rule_count = len(rules)
        target_name = target.name
    finally:
        session.close()

    pool = get_pool_snapshot()
    if pool.get("checkedout") not in (None, 0):
        raise SystemExit(f"Database connection remained checked out: {pool}")

    print("RUNTIME_VERIFY=OK")
    print(f"GEMINI_KEYS={diagnostics['configured_keys']}")
    print(f"GEMINI_MAX_PARALLEL={diagnostics['max_parallel_requests']}")
    print(f"TARGET_NAME={target_name}")
    print(f"RULES={rule_count}")
    print(f"LITERAL_WHITELIST={literal_count}")
    print(f"REGEX_WHITELIST={regex_count}")
    print(f"BLACKLIST={blacklist_count}")
    print("NATIVE_TARGET_MATCH=YES")
    print("DB_POOL_CHECKED_OUT_AFTER_VERIFY=0")


if __name__ == "__main__":
    main()
