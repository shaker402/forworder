#!/usr/bin/env python3
"""Mocked 10-key rotation, cooldown, REST-payload, and concurrency tests."""

import asyncio
import json
import os
import sys
import threading
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import ai.gemini_provider as gemini


async def failover_test():
    os.environ["GEMINI_API_KEYS"] = ",".join(f"dummy-key-{i}" for i in range(10))
    os.environ["GEMINI_REQUIRED_KEY_COUNT"] = "10"
    os.environ["GEMINI_API_BASE"] = ""
    os.environ["GEMINI_CLASSIFIER_CACHE"] = "false"
    os.environ["GEMINI_KEY_COOLDOWN_SECONDS"] = "60"
    gemini._reset_runtime_state_for_tests()

    original_generate = gemini._generate_sync
    calls = []

    def fake_generate(key, model, message, prompt, images):
        calls.append(key)
        if key == "dummy-key-0":
            raise gemini.GeminiRequestError(
                "rate limited", status=429, retry_after=12
            )
        return "KEEP"

    gemini._generate_sync = fake_generate
    try:
        provider = gemini.GeminiProvider()
        await provider.initialize(model="test-model")
        original = "احد يعرف خصوصي يشرح الجبر؟"
        result = await provider.process_message(
            original,
            prompt=gemini.CLASSIFIER_CONTRACT_V8,
        )
        assert result == original
        assert calls[:2] == ["dummy-key-0", "dummy-key-1"]
        assert gemini.get_pool_diagnostics()["cooling_slots"] == [1]
    finally:
        gemini._generate_sync = original_generate


async def concurrency_and_payload_test():
    os.environ["GEMINI_MAX_PARALLEL_REQUESTS"] = "3"
    gemini._reset_runtime_state_for_tests()
    original_urlopen = gemini.urllib.request.urlopen
    lock = threading.Lock()
    active = 0
    maximum = 0
    payloads = []
    urls = []

    class Response:
        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc, tb):
            return False

        def read(self):
            return json.dumps(
                {"candidates": [{"content": {"parts": [{"text": "KEEP"}]}}]}
            ).encode("utf-8")

    def fake_urlopen(request, timeout):
        nonlocal active, maximum
        payload = json.loads(request.data.decode("utf-8"))
        with lock:
            payloads.append(payload)
            urls.append(request.full_url)
            active += 1
            maximum = max(maximum, active)
        time.sleep(0.02)
        with lock:
            active -= 1
        return Response()

    gemini.urllib.request.urlopen = fake_urlopen
    try:
        await asyncio.gather(
            *(
                asyncio.to_thread(
                    gemini._generate_sync,
                    f"dummy-key-{index}",
                    "test-model",
                    f"message {index}",
                    gemini.CLASSIFIER_CONTRACT_V8,
                    None,
                )
                for index in range(12)
            )
        )
    finally:
        gemini.urllib.request.urlopen = original_urlopen

    assert maximum <= 3, maximum
    assert maximum == 3, maximum
    assert all("systemInstruction" in payload for payload in payloads)
    assert all("dummy-key" not in url for url in urls)
    assert all(
        payload["generationConfig"]["maxOutputTokens"] == 8
        for payload in payloads
    )
    assert all(
        payload["contents"][0]["parts"][0]["text"].startswith("<NEW_MESSAGE>")
        for payload in payloads
    )


async def configuration_guard_test():
    os.environ["GEMINI_API_KEYS"] = ",".join(f"dummy-key-{i}" for i in range(9))
    os.environ["GEMINI_REQUIRED_KEY_COUNT"] = "10"
    provider = gemini.GeminiProvider()
    try:
        await provider.initialize(model="test-model")
    except ValueError as exc:
        assert "Expected exactly 10" in str(exc)
    else:
        raise AssertionError("Nine keys unexpectedly passed the ten-key guard")

    os.environ["GEMINI_API_KEYS"] = ",".join(f"dummy-key-{i}" for i in range(10))
    os.environ["GEMINI_API_BASE"] = "https://example.invalid/v1"
    provider = gemini.GeminiProvider()
    try:
        await provider.initialize(model="test-model")
    except ValueError as exc:
        assert "disables native key rotation" in str(exc)
    else:
        raise AssertionError("Custom base unexpectedly bypassed the pool guard")
    os.environ["GEMINI_API_BASE"] = ""


async def main():
    await failover_test()
    await concurrency_and_payload_test()
    await configuration_guard_test()
    print("GEMINI_UNIQUE_KEY_COUNT_10=OK")
    print("GEMINI_ROUND_ROBIN_FAILOVER=OK")
    print("GEMINI_429_COOLDOWN=OK")
    print("GEMINI_MAX_PARALLEL_3=OK")
    print("GEMINI_SYSTEM_INSTRUCTION_CONTRACT=OK")
    print("GEMINI_KEYS_ABSENT_FROM_URL=OK")
    print("GEMINI_CUSTOM_BASE_CONFLICT_GUARD=OK")
    print("NO_NETWORK_REQUESTS=YES")


if __name__ == "__main__":
    asyncio.run(main())
