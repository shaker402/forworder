#!/usr/bin/env python3
"""Merge missing defaults and named updates without echoing secret values."""

import argparse
import os
import re
import tempfile
from pathlib import Path

KEY_RE = re.compile(r"^([A-Za-z_][A-Za-z0-9_]*)=(.*)$")


def parse_assignments(lines):
    result = {}
    for line in lines:
        match = KEY_RE.match(line)
        if match:
            result[match.group(1)] = match.group(2)
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--env", type=Path, required=True)
    parser.add_argument("--defaults", type=Path, required=True)
    parser.add_argument("--set", action="append", default=[], dest="updates")
    args = parser.parse_args()

    lines = args.env.read_text(encoding="utf-8").splitlines()
    current = parse_assignments(lines)
    defaults = parse_assignments(
        args.defaults.read_text(encoding="utf-8").splitlines()
    )
    updates = {}
    for item in args.updates:
        if "=" not in item:
            parser.error("--set must be NAME=VALUE")
        name, value = item.split("=", 1)
        if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", name):
            parser.error(f"invalid environment name: {name}")
        updates[name] = value

    changed = []
    output = []
    seen = set()
    for line in lines:
        match = KEY_RE.match(line)
        if not match:
            output.append(line)
            continue
        name = match.group(1)
        if name in seen:
            # Remove duplicate assignments so the final value is unambiguous.
            changed.append(name)
            continue
        seen.add(name)
        if name in updates:
            output.append(f"{name}={updates[name]}")
            if match.group(2) != updates[name]:
                changed.append(name)
        else:
            output.append(line)

    missing_defaults = [name for name in defaults if name not in seen]
    if missing_defaults:
        output.extend(["", "# Added by Worker 1 V8 standalone installer"])
        for name in missing_defaults:
            output.append(f"{name}={defaults[name]}")
            seen.add(name)
            changed.append(name)

    for name, value in updates.items():
        if name not in seen:
            output.append(f"{name}={value}")
            seen.add(name)
            changed.append(name)

    rendered = "\n".join(output).rstrip() + "\n"
    with tempfile.NamedTemporaryFile(
        "w", encoding="utf-8", dir=args.env.parent, delete=False
    ) as handle:
        handle.write(rendered)
        temporary = Path(handle.name)
    os.chmod(temporary, 0o600)
    os.replace(temporary, args.env)
    print("UPDATED_ENV_NAMES=" + ",".join(sorted(set(changed))))


if __name__ == "__main__":
    main()

