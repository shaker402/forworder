# Build provenance

The rebuild used only the user-supplied local archives and logs; it did not
fetch or review GitHub.

| Input | SHA-256 | Use |
|---|---|---|
| `TelegramForwarder-main(1).zip` | `794b5b43ce460d4c21ea3b721cccf7b385f967cf60123ad32e168b6549bdb2cb` | Complete upstream 1.7.2 baseline |
| `Telegram_Worker_1_FINAL_Enhanced_V7_Standalone(2).zip` | `5ddf0af06e74b74c24da5b6e524c756ec907142c5db162ee7370a76e58bebd0e` | V7 behavior and migration requirements |
| Uploaded `Telegram_Worker_1_V8_Data_Driven_Patch(1).zip` | `5d5d17cba43ef269225f5c0c727d93f106675c0f4086f48b3e047d425c412dd5` | V8 policy intent |
| Corrected local V8.1 patch | `245e9aaa7aa27125494aab2aa767d14c572776fcc33c98b67f2b4d88f8877d8e` | Correct `/app` imports and classifier contract |
| `shaker_sample.json.zip` | `a804b77c03618e9cc1d7d4ac671c597ec0f1c91a017762705287e002f88bfe08` | 351,061-message offline corpus analysis |
| `Pasted text(20260830-193711).txt` | `b97ee229b0d51c56f6ea90eb6aaeca2223980f643954d01ff4ec7bba6574c591` | Runtime failure diagnosis |

The repeated log failure is SQLAlchemy `QueuePool` exhaustion at the source-chat
query, not a logged Gemini HTTP/auth exception. The old listener kept one
session checked out while awaiting the entire filter chain; V7 also opened an
unused migration connection. Both lifecycles are corrected in this build.
