# Telegram Worker 1 V8 Standalone

This is one complete, buildable project based on the supplied
Heavrnl/TelegramForwarder 1.7.2 source archive. V7 behavior and the corrected
V8 data-driven filter are integrated directly into the source tree. It does
not clone GitHub and does not mount an `overrides/` patch layer.

The Docker Compose service remains `telegram-forwarder`; the container remains
`telegram-forwarder-worker1`. The image is built locally from this directory.

## What was fixed

- Database sessions are fully loaded, detached, and closed before Gemini or
  Telegram network work. The leaked migration connection was removed. SQLite
  uses a shared, observable pool with WAL, busy timeout, pre-ping, and fork
  protection. This addresses the repeated `QueuePool limit ... timed out`
  failure in the supplied log.
- The native Gemini REST provider requires exactly ten unique keys, rotates
  across them, cools down 429/auth/error slots, honors `Retry-After`, limits
  concurrent calls, and never logs key values. A custom `GEMINI_API_BASE` is
  rejected because it would bypass the native pool.
- The classifier uses a strict `KEEP`/`#SKIP` contract. `KEEP` maps back to the
  untouched source text. Long repeated candidates use a privacy-reduced
  decision cache; short/context-sensitive messages and images bypass it.
- The Shaker-derived local prefilter has 100 literal terms plus five
  boundary-aware regular expressions. It prevents measured collisions such as
  `احد`/`الاحد`, `ميد`/`ميداني`, and `تدريب`/`التدريبي` before an API call.
- Only final accepted delivery uses the authenticated user client with
  `drop_author=False`, preserving Telegram's genuine “Forwarded from” header.
  Every accepted native forward receives a separate `ℹ️ Message information`
  reply containing sender, time, and original-link details; albums receive one
  information reply attached to their first forwarded item.
- The destination is excluded from listening and auto-bind paths, preventing a
  forwarding feedback loop. Native delivery falls back to the normal copy path
  when configured to do so.
- An exclusive process lock prevents two runtimes from using the same Telethon
  session files, addressing the duplicate/old encrypted-update warning pattern
  seen during the logged failure burst.
- The installer builds from bundled source, migrates existing `.env`, database,
  sessions, logs, and mutable data, verifies behavior, and automatically
  restores the previous project after any failed deployment step.
- Deployment regression tests now keep their explicit temporary target IDs
  when the real `.env` is mounted, preventing false native-target mismatch
  failures during installation.

## Upgrade an existing Worker 1

The archive intentionally contains no real credentials. The installer reads
the existing `/opt/TelegramForwarder-worker1/.env` and preserves all values.

```bash
unzip Telegram_Worker_1_V8_Standalone.zip
cd Telegram_Worker_1_V8_Standalone
chmod +x install_worker1.sh
sudo ./install_worker1.sh
```

By default the installer:

1. verifies the bundle and the existing ten-key configuration;
2. stops the old container and retains a timestamped full backup;
3. builds the bundled source into `telegram-forwarder-worker1:v8-standalone`;
4. runs all zero-network regression tests;
5. verifies/authorizes the Telegram user session and resolves the exact target;
6. makes one minimal live health call through each Gemini key slot without
   displaying keys and requires all ten slots to pass;
7. binds visible groups/channels, applies V8 to all destination rules, starts
   the worker, and verifies the live database and container health.

For a fresh install, provide an external environment file:

```bash
sudo ./install_worker1.sh --env-file /root/worker1.env
```

Useful controlled exceptions:

```bash
sudo ./install_worker1.sh --skip-live-gemini-check
sudo ./install_worker1.sh --skip-bind
sudo ./install_worker1.sh --target-id 123456789 --target-name "AI_filter"
```

Use `--skip-live-gemini-check` only when you intentionally want to deploy
during a temporary provider-wide rate limit; structural validation still
requires exactly ten unique configured keys.

## Verification after installation

```bash
cd /opt/TelegramForwarder-worker1
docker compose ps
docker compose exec -T telegram-forwarder \
  python /app/worker_tools/verify_runtime.py
docker compose logs --tail=200 telegram-forwarder
```

Run the optional 64-case live semantic evaluation:

```bash
docker compose exec -T telegram-forwarder \
  python /app/worker_tools/evaluate_gemini_filter.py \
  --output /app/logs/gemini_v8_regression_report.json
```

That report includes precision, recall, specificity, F1, accuracy, API errors,
and exact mistakes. Do not claim a production accuracy percentage until this
live evaluation and a human-labeled sample of unfiltered source traffic pass.
The Shaker export contains historical keyword candidates, not labels and not
messages rejected by the old prefilter; it informed the policy but was not
misrepresented as supervised model training.

## Failure behavior

`GEMINI_FAIL_OPEN=true` preserves a locally matched candidate if every key is
unavailable, prioritizing recall during an API outage. Set it to `false` if the
main destination must block every message that lacks a completed AI decision.

If installation fails, the new failed tree is retained with a `.failed-v8-*`
suffix, the timestamped previous project is moved back into place, and its
Compose service is restarted. Successful upgrades also retain the backup until
you choose to remove it.

The original upstream documentation is preserved in `UPSTREAM_README.md`; the
original GPL license remains in `LICENSE`.
