# V8 standalone validation report

Validation date: 2026-08-31 UTC

## Passed locally

- All 114 pinned runtime dependencies installed successfully in an isolated
  environment; `pip check` reported no broken requirements.
- All Python source files compiled; `install_worker1.sh` passed `bash -n`; the
  Compose file parsed with the expected service and container names.
- The complete application imported with all pinned dependencies, initialized a
  temporary database, and routed `gemini-3.5-flash-lite` to the native Gemini
  provider with ten configured slots.
- The real message-listener query path eagerly loaded and detached all rule
  relationships. A 50-message concurrent stress simulation observed zero
  checked-out SQLAlchemy connections while every task was waiting on simulated
  external I/O and zero afterward.
- The ten-key mocked suite passed unique-count enforcement, round-robin
  failover, 429 cooldown, three-request concurrency limiting, system-instruction
  separation, eight-token output limit, and the custom-base conflict guard.
- The classifier suite passed exact `KEEP`/`#SKIP` mapping, malformed-output
  rejection, normalized privacy-reduced cache keys, and cache read/write.
- All 20 important wanted examples reached the local prefilter. All five known
  substring collisions were rejected locally. The frozen 64-case JSONL file
  validated structurally.
- A temporary three-rule database was migrated from legacy keywords to exactly
  100 literal whitelist rows, five regex whitelist rows, and one `#SKIP`
  blacklist row per rule. The full deployed-runtime verifier then passed.
- The deployed-image bulk-policy test preserves its explicit temporary raw and
  marked Telegram target IDs even while the production `.env` is mounted.
  This prevents the production values from contaminating the offline test.
- Native forwarding passed single/album ordering, `drop_author=False`, target
  matching, screenshot-style replied metadata (sender, source, worker, time,
  original link), complete empty-detail fallbacks, and normal-copy fallback
  contracts without network access.
- Installer simulation confirmed that information replies are forced on even
  when an older environment file contains `NATIVE_QUOTE_DETAILS=false`.
- Auto-bind passed policy/keyword cloning and destination feedback exclusion.
- Installer simulations passed both paths: a forced image-build failure restored
  the entire previous tree and preserved the failed new tree; a successful mock
  upgrade migrated database/session state, preserved credential values, merged
  V8 defaults, and retained the full backup.
- All sensitive values extracted from the supplied V7 `.env` (Telegram values,
  legacy Gemini key, and ten Gemini pool slots) were byte-scanned against the
  deliverable: zero matches. No `.env`, database, or Telethon session is present.

## Deployment-time validation

This workspace had no Docker daemon and did not make live Telegram or Gemini
requests with the user's credentials. The installer therefore repeats the
tests inside the final built image, validates the Telegram session/target, calls
each Gemini slot once while reporting only slot numbers, requires all ten slots
to pass, starts the real container, waits for Docker health, and runs
`verify_runtime.py`. Any failure automatically restores the previous project.

The optional 64-case live semantic evaluation remains necessary before quoting
a measured Gemini precision/recall/accuracy percentage.
