"""Final delivery using Telegram's genuine, attribution-preserving forward."""

import logging
import os

from native_forward_runtime import get_user_client

logger = logging.getLogger(__name__)


def _env_bool(name, default=False):
    fallback = "true" if default else "false"
    return os.getenv(name, fallback).strip().lower() in {
        "1", "true", "yes", "on"
    }


def _parse_target(value):
    value = (value or "").strip()
    if not value:
        return None
    try:
        return int(value)
    except ValueError:
        return value


def _id_variants(value):
    try:
        number = abs(int(str(value).strip()))
    except (TypeError, ValueError):
        return set()
    variants = {number}
    text_value = str(number)
    if text_value.startswith("100") and len(text_value) > 3:
        variants.add(int(text_value[3:]))
    return variants


def _result_messages(result):
    if result is None:
        return []
    if isinstance(result, (list, tuple)):
        return [message for message in result if message is not None]
    return [result]


def _source_name(context):
    rule_source = getattr(getattr(context, "rule", None), "source_chat", None)
    event_chat = getattr(getattr(context, "event", None), "chat", None)
    for entity in (rule_source, event_chat):
        for attribute in ("name", "title", "username"):
            value = (getattr(entity, attribute, "") or "").strip()
            if value:
                return value

    chat_id = getattr(context, "chat_id", None)
    if chat_id is None:
        chat_id = getattr(getattr(context, "event", None), "chat_id", None)
    return str(chat_id) if chat_id is not None else "Unknown source"


def _metadata_text(context):
    """Build the separate reply shown beneath the genuine Telegram forward."""
    sender = (getattr(context, "sender_info", "") or "").strip()
    sent_time = (getattr(context, "time_info", "") or "").strip()
    original_link = (getattr(context, "original_link", "") or "").strip()
    captured_by = (
        os.getenv("NATIVE_QUOTE_CAPTURED_BY", "Telegram Worker 1").strip()
        or "Telegram Worker 1"
    )

    pieces = []
    if sender:
        pieces.append(sender)
    else:
        pieces.append("👤 Sender: Details unavailable")
    pieces.append(f"📩 Source: {_source_name(context)}")
    pieces.append(f"📥 Captured by: {captured_by}")
    if sent_time:
        pieces.append(sent_time)
    else:
        pieces.append("🕒 Sent: Time unavailable")
    if original_link:
        pieces.append(original_link)
    else:
        pieces.append("🔗 Original message: Link unavailable")
    return "\n".join(pieces)


def _cleanup_downloads(context):
    if getattr(context.rule, "enable_push", False):
        return
    for path in set(getattr(context, "media_files", []) or []):
        try:
            if path and os.path.isfile(path):
                os.remove(path)
        except OSError as exc:
            logger.warning("Could not remove temporary media %s: %s", path, exc)
    context.media_files = []


async def try_native_forward(context):
    """
    Return True on native success, False on a hard failure, or None when the
    stock copy sender should run (disabled or configured fallback).
    """
    if not _env_bool("NATIVE_QUOTE_FORWARD", False):
        return None

    fallback_copy = _env_bool("NATIVE_QUOTE_FALLBACK_COPY", True)
    user_client = get_user_client()
    target = _parse_target(os.getenv("NATIVE_QUOTE_TARGET", ""))
    if user_client is None or target is None:
        logger.error("Native forward requires the user client and NATIVE_QUOTE_TARGET")
        return None if fallback_copy else False

    # Native forwarding cannot preserve transformations that removed only part
    # of an album. The regular copy path remains authoritative in that case.
    if (
        getattr(context.rule, "enable_media_type_filter", False)
        or getattr(context.rule, "enable_media_size_filter", False)
        or getattr(context.rule, "enable_extension_filter", False)
        or getattr(context, "skipped_media", None)
        or getattr(context, "media_blocked", False)
    ):
        logger.info("Using stock sender because per-media filtering is active")
        return None

    try:
        target_entity = await user_client.get_entity(target)
        configured_rule_target = getattr(
            getattr(context.rule, "target_chat", None), "telegram_chat_id", None
        )
        if _id_variants(configured_rule_target) and not (
            _id_variants(configured_rule_target)
            & _id_variants(getattr(target_entity, "id", None))
        ):
            logger.error(
                "NATIVE_QUOTE_TARGET does not match the forwarding rule target"
            )
            return None if fallback_copy else False

        event = context.event
        messages = list(getattr(context, "media_group_messages", []) or [])
        if not messages:
            messages = [event.message]
        messages = sorted(messages, key=lambda message: int(message.id))
        message_ids = [int(message.id) for message in messages]

        native_result = await user_client.forward_messages(
            target_entity,
            message_ids,
            from_peer=event.chat_id,
            drop_author=False,
        )
        forwarded = _result_messages(native_result)
        if not forwarded:
            raise RuntimeError("Telegram returned no forwarded message")

        context.forwarded_messages = forwarded
        _cleanup_downloads(context)

        if _env_bool("NATIVE_QUOTE_DETAILS", True):
            details = _metadata_text(context)
            first_id = getattr(forwarded[0], "id", None)
            if details and first_id is not None:
                try:
                    await user_client.send_message(
                        target_entity,
                        details,
                        reply_to=first_id,
                        parse_mode=None,
                        link_preview=False,
                    )
                except Exception as exc:
                    # Never repeat the native forward after it has succeeded.
                    logger.error("Native information reply failed: %s", exc)

        logger.info(
            "Native Telegram forward completed: rule=%s messages=%s",
            context.rule.id,
            len(forwarded),
        )
        return True
    except Exception as exc:
        logger.exception("Native Telegram forward failed: %s", exc)
        return None if fallback_copy else False
