#!/usr/bin/env python3
"""Verify shadow-only model inference, sampling, and contact redaction."""

import os
import sqlite3
import sys
import tempfile
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from ai import local_shadow


def context():
    text = "احد يعرف مدرس؟ تواصل test@example.com +967 777 123 456"
    message = SimpleNamespace(id=1, grouped_id=None)
    event = SimpleNamespace(message=message)
    rule = SimpleNamespace(id=7)
    return SimpleNamespace(
        event=event,
        chat_id=-100100,
        rule=rule,
        original_message_text=text,
        message_text=text,
        shadow_event_key=None,
    )


def main():
    with tempfile.TemporaryDirectory() as directory:
        path = Path(directory) / "shadow.sqlite3"
        os.environ.update(
            {
                "LOCAL_SHADOW_ENABLED": "true",
                "LOCAL_SHADOW_DB_PATH": str(path),
                "LOCAL_SHADOW_MODEL_PATH": str(
                    ROOT / "model" / "shaker_weak_tfidf_triage.joblib"
                ),
                "LOCAL_SHADOW_REJECT_SAMPLE_RATE": "1",
                "WORKER_NAMESPACE": "worker1-selftest",
            }
        )
        item = context()
        local_shadow.record_prefilter_event(item, False)
        local_shadow.record_ai_state(item, "KEEP", "KEEP")
        report = local_shadow.diagnostics()
        assert report["mode"] == "SHADOW_ONLY"
        assert report["total"] == 1
        assert sum(report["local_proposals"].values()) == 1
        sample = local_shadow.review_sample(10)
        assert len(sample) == 1
        assert sample[0]["event_key"] == item.shadow_event_key
        assert local_shadow.set_review_label(item.shadow_event_key, "KEEP")
        assert local_shadow.diagnostics()["human_labeled"] == 1
        with sqlite3.connect(path) as connection:
            text, action, state = connection.execute(
                "SELECT redacted_text, local_action, effective_state FROM shadow_events"
            ).fetchone()
        assert "test@example.com" not in text
        assert "+967 777 123 456" not in text
        assert "[EMAIL]" in text and "[PHONE]" in text
        assert action in {"LOCAL_KEEP", "LOCAL_SKIP", "ESCALATE"}
        assert state == "KEEP"
    print("LOCAL_MODEL_SHADOW_ONLY=OK")
    print("SHADOW_CONTACT_REDACTION=OK")
    print("SHADOW_ACCEPTED_AND_REJECTED_SCHEMA=OK")


if __name__ == "__main__":
    main()
