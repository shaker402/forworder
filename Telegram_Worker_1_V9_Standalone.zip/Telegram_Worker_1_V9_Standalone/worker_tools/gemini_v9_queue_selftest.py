#!/usr/bin/env python3
"""Zero-network V9 durable queue, retry, limiter, and secret-storage tests."""

import asyncio
import os
import sys
import tempfile
import threading
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import ai.gemini_provider as gemini


def configure(directory):
    os.environ.update(
        {
            "WORKER_NAMESPACE": "worker1-selftest",
            "GEMINI_API_KEYS": ",".join(
                f"dummy-project-key-{index}" for index in range(10)
            ),
            "GEMINI_REQUIRED_KEY_COUNT": "10",
            "GEMINI_API_BASE": "",
            "GEMINI_CLASSIFIER_CACHE": "false",
            "GEMINI_QUEUE_PATH": str(Path(directory) / "queue.sqlite3"),
            "GEMINI_MAX_PARALLEL_REQUESTS": "3",
            "GEMINI_PROJECT_TARGET_RPM": "1200",
            "GEMINI_PROJECT_MIN_INTERVAL_SECONDS": "0.05",
            "GEMINI_PROJECT_INFLIGHT_LEASE_SECONDS": "10",
            "GEMINI_QUEUE_LEASE_SECONDS": "10",
            "GEMINI_QUEUE_MAX_WAIT_SECONDS": "10",
            "GEMINI_KEY_COOLDOWN_SECONDS": "0.15",
            "GEMINI_KEY_AUTH_COOLDOWN_SECONDS": "0.20",
            "GEMINI_AUTH_FAILOVER_ATTEMPTS": "2",
            "GEMINI_TRANSIENT_MAX_ATTEMPTS": "3",
            "GEMINI_RETRY_BASE_SECONDS": "0.05",
            "GEMINI_RETRY_MAX_SECONDS": "0.10",
            "GEMINI_FAIL_OPEN": "false",
        }
    )
    gemini._reset_runtime_state_for_tests()


async def retry_semantics(directory):
    configure(directory)
    original = gemini._generate_sync
    calls = []

    def fake_generate(key, model, message, prompt, images):
        calls.append((key, time.monotonic()))
        if len(calls) == 1:
            raise gemini.GeminiRequestError(
                "rate limited", status=429, retry_after=0.15
            )
        return "KEEP"

    gemini._generate_sync = fake_generate
    try:
        provider = gemini.GeminiProvider()
        await provider.initialize(model="test-model")
        started = time.monotonic()
        message = "احد يعرف خصوصي يشرح الجبر؟"
        result = await provider.process_message(
            message,
            prompt=gemini.CLASSIFIER_CONTRACT_V8,
            source_namespace="worker1:test",
            source_chat_id="100",
            telegram_message_id="1",
            rule_id="7",
        )
        assert result == message
        assert len(calls) == 2, calls
        assert calls[1][1] - calls[0][1] >= 0.13, calls
        assert time.monotonic() - started >= 0.13
        assert gemini.get_pool_diagnostics()["queue_counts"].get("KEEP") == 1
    finally:
        gemini._generate_sync = original


async def auth_and_review_semantics(directory):
    configure(directory)
    original = gemini._generate_sync
    calls = []

    def auth_then_success(key, model, message, prompt, images):
        calls.append(key)
        if len(calls) == 1:
            raise gemini.GeminiRequestError("auth", status=401)
        return "#SKIP"

    gemini._generate_sync = auth_then_success
    try:
        provider = gemini.GeminiProvider()
        await provider.initialize(model="test-model")
        result = await provider.process_message(
            "خدمة حل واجبات للتواصل",
            prompt=gemini.CLASSIFIER_CONTRACT_V8,
            source_chat_id="101",
            telegram_message_id="2",
            rule_id="7",
        )
        assert result == "#SKIP"
        assert len(calls) == 2
        assert calls[0] != calls[1]
        statuses = {
            row["status"] for row in gemini.get_pool_diagnostics()["projects"]
        }
        assert "QUARANTINED" in statuses
    finally:
        gemini._generate_sync = original

    configure(directory)
    gemini._generate_sync = lambda *_args: "uncertain explanation"
    try:
        provider = gemini.GeminiProvider()
        await provider.initialize(model="test-model")
        try:
            await provider.process_message(
                "رسالة غير واضحة",
                prompt=gemini.CLASSIFIER_CONTRACT_V8,
                source_chat_id="102",
                telegram_message_id="3",
                rule_id="7",
            )
        except gemini.GeminiReviewRequired:
            pass
        else:
            raise AssertionError("Malformed output did not require review")
        assert gemini.get_pool_diagnostics()["queue_counts"].get(
            "REVIEW_REQUIRED"
        ) == 1
    finally:
        gemini._generate_sync = original


async def concurrency_and_payload(directory):
    configure(directory)
    original_generate = gemini._generate_sync
    lock = threading.Lock()
    active = 0
    maximum = 0
    starts = {}

    def fake_generate(key, model, message, prompt, images):
        nonlocal active, maximum
        # Exercise the production global semaphore without constructing HTTP.
        with gemini._get_http_semaphore():
            with lock:
                active += 1
                maximum = max(maximum, active)
                starts.setdefault(key, []).append(time.monotonic())
            time.sleep(0.08)
            with lock:
                active -= 1
            return "KEEP"

    gemini._generate_sync = fake_generate
    try:
        provider = gemini.GeminiProvider()
        await provider.initialize(model="test-model")
        messages = [f"candidate message {index} with enough text" for index in range(16)]
        results = await asyncio.gather(
            *(
                provider.process_message(
                    message,
                    prompt=gemini.CLASSIFIER_CONTRACT_V8,
                    source_chat_id="200",
                    telegram_message_id=str(index),
                    rule_id="8",
                )
                for index, message in enumerate(messages)
            )
        )
        assert results == messages
    finally:
        gemini._generate_sync = original_generate

    assert maximum == 3, maximum
    for key_starts in starts.values():
        for first, second in zip(key_starts, key_starts[1:]):
            assert second - first >= 0.045, (first, second)
    assert gemini.get_pool_diagnostics()["queue_counts"].get("KEEP") == 16


def no_secrets_in_sqlite(directory):
    fragments = [
        f"dummy-project-key-{index}".encode("utf-8") for index in range(10)
    ]
    for path in Path(directory).glob("queue.sqlite3*"):
        data = path.read_bytes()
        assert all(fragment not in data for fragment in fragments), path


async def configuration_guard(directory):
    configure(directory)
    os.environ["GEMINI_API_KEYS"] = ",".join(
        f"dummy-project-key-{index}" for index in range(9)
    )
    provider = gemini.GeminiProvider()
    try:
        await provider.initialize(model="test-model")
    except ValueError as exc:
        assert "Expected exactly 10" in str(exc)
    else:
        raise AssertionError("Nine keys unexpectedly passed validation")


async def main():
    with tempfile.TemporaryDirectory() as directory:
        await retry_semantics(directory)
        await auth_and_review_semantics(directory)
        await concurrency_and_payload(directory)
        no_secrets_in_sqlite(directory)
        await configuration_guard(directory)
    print("GEMINI_PROJECT_BUCKETS_10=OK")
    print("GEMINI_429_REQUEUE_NO_CASCADE=OK")
    print("GEMINI_AUTH_QUARANTINE_FAILOVER=OK")
    print("GEMINI_REVIEW_REQUIRED=OK")
    print("GEMINI_MAX_PARALLEL_3=OK")
    print("GEMINI_PER_PROJECT_INTERVAL=OK")
    print("GEMINI_QUEUE_PERSISTENT_SQLITE=OK")
    print("GEMINI_KEYS_ABSENT_FROM_SQLITE=OK")
    print("NO_NETWORK_REQUESTS=YES")


if __name__ == "__main__":
    asyncio.run(main())
