#!/usr/bin/env python3
"""Zero-network persistent Telegram delivery deduplication test."""

import os
import sys
import tempfile
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from durable_delivery import (
    claim_delivery,
    complete_delivery,
    diagnostics,
    release_delivery,
)


def context(message_id=1):
    message = SimpleNamespace(id=message_id, grouped_id=None)
    event = SimpleNamespace(message=message)
    target = SimpleNamespace(telegram_chat_id=-100900)
    rule = SimpleNamespace(id=7, target_chat=target)
    return SimpleNamespace(
        event=event,
        chat_id=-100100,
        rule=rule,
        media_group_messages=[],
    )


def main():
    with tempfile.TemporaryDirectory() as directory:
        os.environ["TELEGRAM_DELIVERY_DB_PATH"] = str(
            Path(directory) / "delivery.sqlite3"
        )
        os.environ["WORKER_NAMESPACE"] = "worker1-selftest"
        item = context()
        state, key = claim_delivery(item)
        assert state == "CLAIMED"
        assert claim_delivery(item)[0] == "BUSY"
        release_delivery(key)
        state, key = claim_delivery(item)
        assert state == "CLAIMED"
        complete_delivery(key, "mock")
        assert claim_delivery(item)[0] == "DELIVERED"
        assert claim_delivery(context(2))[0] == "CLAIMED"
        assert diagnostics()["DELIVERED"] == 1
    print("TELEGRAM_DELIVERY_DEDUP_PERSISTENT=OK")
    print("DELIVERY_LEASE_RECOVERY=OK")
    print("NO_NETWORK_REQUESTS=YES")


if __name__ == "__main__":
    main()
