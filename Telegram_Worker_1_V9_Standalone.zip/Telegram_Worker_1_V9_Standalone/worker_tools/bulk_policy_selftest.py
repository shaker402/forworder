#!/usr/bin/env python3
"""Apply V8 to a temporary multi-rule database and verify exact rows."""

import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
os.chdir(ROOT)
sys.path.insert(0, str(ROOT))


def main():
    with tempfile.TemporaryDirectory() as directory:
        os.environ["DATABASE_URL"] = "sqlite:///" + str(Path(directory) / "test.db")
        os.environ["GEMINI_API_KEYS"] = ",".join(
            f"dummy-{index}" for index in range(10)
        )
        os.environ["GEMINI_REQUIRED_KEY_COUNT"] = "10"
        os.environ["GEMINI_API_BASE"] = ""
        os.environ["WORKER_NAMESPACE"] = "worker1-selftest"
        os.environ["GEMINI_QUEUE_PATH"] = str(Path(directory) / "queue.sqlite3")
        os.environ["GEMINI_MAX_KEY_ATTEMPTS"] = "1"
        os.environ["GEMINI_MAX_PARALLEL_REQUESTS"] = "3"
        os.environ["MAX_CONCURRENT_MESSAGE_HANDLERS"] = "10"
        os.environ["GEMINI_PROJECT_TARGET_RPM"] = "12"
        os.environ["GEMINI_PROJECT_MIN_INTERVAL_SECONDS"] = "5"
        os.environ["GEMINI_POLICY_VERSION"] = "SHAKER_WANTED_V9"
        os.environ["GEMINI_FAIL_OPEN"] = "false"
        os.environ["LOCAL_SHADOW_ENABLED"] = "true"
        os.environ["VERIFY_ALLOW_TEMP_PATHS"] = "true"
        os.environ["LOCAL_SHADOW_MODEL_PATH"] = str(
            ROOT / "model" / "shaker_weak_tfidf_triage.joblib"
        )
        os.environ["LOCAL_SHADOW_DB_PATH"] = str(Path(directory) / "shadow.sqlite3")
        os.environ["TELEGRAM_DELIVERY_DB_PATH"] = str(
            Path(directory) / "delivery.sqlite3"
        )
        os.environ["OUTPUT_GROUP_RAW_ID"] = "555"
        os.environ["NATIVE_QUOTE_TARGET"] = "-100555"

        from filter_policy_v8 import BLACKLIST, MODEL, REGEX_WHITELIST, WHITELIST
        from models.models import Chat, ForwardRule, Keyword, get_session, init_db

        init_db()
        session = get_session()
        target = Chat(telegram_chat_id="555", name="target")
        session.add(target)
        session.flush()
        for index in range(3):
            source = Chat(telegram_chat_id=str(1000 + index), name=f"source-{index}")
            session.add(source)
            session.flush()
            rule = ForwardRule(source_chat_id=source.id, target_chat_id=target.id)
            session.add(rule)
            session.flush()
            session.add(
                Keyword(
                    rule_id=rule.id,
                    keyword="legacy",
                    is_regex=False,
                    is_blacklist=False,
                )
            )
        session.commit()
        session.close()

        import bulk_configure_student_filter

        original_argv = sys.argv
        try:
            sys.argv = ["bulk_configure_student_filter.py", "--target-id", "555", "--apply"]
            bulk_configure_student_filter.main()
        finally:
            sys.argv = original_argv

        session = get_session()
        try:
            rules = session.query(ForwardRule).order_by(ForwardRule.id).all()
            assert len(rules) == 3
            for rule in rules:
                assert rule.is_ai and rule.is_keyword_after_ai
                assert rule.ai_model == MODEL
                literal = session.query(Keyword).filter_by(
                    rule_id=rule.id, is_regex=False, is_blacklist=False
                ).count()
                regex = session.query(Keyword).filter_by(
                    rule_id=rule.id, is_regex=True, is_blacklist=False
                ).count()
                blacklist = session.query(Keyword).filter_by(
                    rule_id=rule.id, is_blacklist=True
                ).count()
                assert (literal, regex, blacklist) == (
                    len(WHITELIST), len(REGEX_WHITELIST), len(BLACKLIST)
                )
        finally:
            session.close()

        from worker_tools import verify_runtime
        if os.environ.get("OUTPUT_GROUP_RAW_ID") != "555" or os.environ.get(
            "NATIVE_QUOTE_TARGET"
        ) != "-100555":
            raise SystemExit(
                "verify_runtime overwrote explicit regression-test target IDs"
            )
        verify_runtime.main()

        print("BULK_POLICY_RULES_CONFIGURED=3")
        print("BULK_POLICY_EXACT_KEYWORD_COUNTS=OK")
        print("BULK_POLICY_OLD_ROWS_REMOVED=OK")
        print("NO_NETWORK_REQUESTS=YES")


if __name__ == "__main__":
    main()
