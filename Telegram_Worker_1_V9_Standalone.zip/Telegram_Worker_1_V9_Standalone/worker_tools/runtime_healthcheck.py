#!/usr/bin/env python3
"""Non-network runtime health check; never prints credential values."""

import argparse
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
os.chdir(ROOT)
sys.path.insert(0, str(ROOT))

from dotenv import load_dotenv

load_dotenv(ROOT / ".env")

from ai.gemini_provider import get_pool_diagnostics
from filter_policy_v8 import BLACKLIST, REGEX_WHITELIST, WHITELIST
from models.models import get_pool_snapshot


def env_bool(name, default=False):
    fallback = "true" if default else "false"
    return os.getenv(name, fallback).strip().lower() in {
        "1", "true", "yes", "on"
    }


def id_variants(value):
    try:
        number = abs(int(str(value).strip()))
    except (TypeError, ValueError):
        return set()
    variants = {number}
    rendered = str(number)
    if rendered.startswith("100") and len(rendered) > 3:
        variants.add(int(rendered[3:]))
    return variants


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--quick", action="store_true")
    args = parser.parse_args()

    failures = []
    required_env = ("API_ID", "API_HASH", "BOT_TOKEN", "PHONE_NUMBER", "USER_ID")
    missing = [name for name in required_env if not os.getenv(name, "").strip()]
    if missing:
        failures.append("missing required environment names: " + ",".join(missing))

    gemini = get_pool_diagnostics()
    required_keys = int(os.getenv("GEMINI_REQUIRED_KEY_COUNT", "10") or "10")
    if gemini["configured_keys"] != required_keys:
        failures.append(
            f"Gemini key count is {gemini['configured_keys']}, expected {required_keys}"
        )
    if gemini["custom_compatible_base"] and required_keys > 1:
        failures.append("GEMINI_API_BASE disables the native multi-key pool")
    if gemini["max_parallel_requests"] != 3:
        failures.append("Gemini global parallel limit is not 3")
    if gemini["target_rpm_per_project"] != 12:
        failures.append("Gemini per-project target is not 12 RPM")
    if len(gemini["projects"]) != required_keys:
        failures.append("Gemini persistent project bucket count is incorrect")
    if env_bool("GEMINI_FAIL_OPEN", False):
        failures.append("GEMINI_FAIL_OPEN must remain disabled")

    native_enabled = env_bool("NATIVE_QUOTE_FORWARD", False)
    native_target = os.getenv("NATIVE_QUOTE_TARGET", "").strip()
    auto_target = os.getenv("AUTO_BIND_TARGET_ID", "").strip()
    if native_enabled and not native_target:
        failures.append("NATIVE_QUOTE_TARGET is missing")
    if env_bool("AUTO_BIND_NEW_CHATS", False) and not auto_target:
        failures.append("AUTO_BIND_TARGET_ID is missing")
    if native_target and auto_target and not (
        id_variants(native_target) & id_variants(auto_target)
    ):
        failures.append("native-forward and auto-bind targets do not match")

    policy = {
        "literal_terms": len(WHITELIST),
        "regex_terms": len(REGEX_WHITELIST),
        "blacklist": BLACKLIST,
    }
    if policy != {"literal_terms": 100, "regex_terms": 5, "blacklist": ["#SKIP"]}:
        failures.append("V8 policy term counts changed unexpectedly")

    pool = get_pool_snapshot()
    checked_out = pool.get("checkedout")
    if checked_out not in (None, 0):
        failures.append(f"database pool has {checked_out} checked-out connections")

    result = {
        "ok": not failures,
        "gemini": gemini,
        "database_pool": pool,
        "policy": policy,
        "native_forward_enabled": native_enabled,
        "network_requests": 0,
        "failures": failures,
    }
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
