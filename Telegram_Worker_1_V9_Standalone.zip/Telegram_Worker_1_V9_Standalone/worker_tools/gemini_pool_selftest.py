#!/usr/bin/env python3
"""Compatibility entry point for the Worker 1 V9 scheduler self-test."""

import asyncio

from gemini_v9_queue_selftest import main


if __name__ == "__main__":
    asyncio.run(main())
