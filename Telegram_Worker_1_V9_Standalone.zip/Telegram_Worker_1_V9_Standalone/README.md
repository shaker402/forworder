# Telegram Worker 1 V9 Standalone

This is a complete Worker 1 project based on the supplied
Heavrnl/TelegramForwarder 1.7.2 archive. It keeps the V8 Shaker-derived
prefilter/classifier policy and replaces the old Gemini key-rotation behavior
with a durable, per-project scheduler.

The project builds locally. It does not clone GitHub, mount an override layer,
or contain an `.env`, Telegram session, database, or real credential.

## V9 behavior

- Exactly ten unique Gemini keys are required. The runtime stores only SHA-256
  fingerprints in its SQLite scheduler.
- Each key/project has an independent 12-RPM bucket, at least five seconds
  between request starts, and at most one in-flight request. A global semaphore
  allows three simultaneous Gemini calls.
- Classifier work is recorded in `/app/db/gemini_queue.sqlite3` with explicit
  states: `QUEUED`, `IN_FLIGHT`, `KEEP`, `SKIP`, and `REVIEW_REQUIRED`.
- A 429 response honors `Retry-After`, cools that project, and requeues the same
  request. It does not immediately cascade across the other nine projects.
- A 401/403 or key-specific authentication error quarantines that project and
  permits bounded failover. Network and 5xx errors use bounded exponential
  backoff with jitter. Live key-health checks use the same scheduler.
- Provider failure cannot forward the original candidate. A request that
  exceeds the handler wait budget remains `QUEUED`; malformed/non-retriable or
  exhausted retries become `REVIEW_REQUIRED`.
- Classifier cache identity includes policy version, model, worker/source
  namespace, normalized message, and the complete filled prompt/context hash.
- Telegram delivery claims are persisted in
  `/app/db/telegram_delivery_dedup.sqlite3`, preventing a repeated event from
  producing another completed native/copy delivery.
- The included weak TF-IDF model runs in `SHADOW_ONLY` mode. It never keeps or
  skips a message. It stores redacted, pseudonymous telemetry in
  `/app/db/local_shadow.sqlite3` for later source-group/time-holdout evaluation.
- Existing V8 improvements remain: eager/detached database rule loading,
  destination feedback exclusion, process/session locking, collision-safe
  Arabic prefilter terms, strict Gemini `KEEP`/`#SKIP`, native Telegram
  forwarding, information replies, and recoverable installation rollback.

## Required mitigation settings

The installer forces these safety settings even when the old `.env` has other
values:

```dotenv
GEMINI_MAX_KEY_ATTEMPTS=1
GEMINI_MAX_PARALLEL_REQUESTS=3
MAX_CONCURRENT_MESSAGE_HANDLERS=10
GEMINI_PROJECT_TARGET_RPM=12
GEMINI_PROJECT_MIN_INTERVAL_SECONDS=5
GEMINI_FAIL_OPEN=false
```

## Install or upgrade Worker 1

```bash
unzip Telegram_Worker_1_V9_Standalone.zip
cd Telegram_Worker_1_V9_Standalone
chmod +x install_worker1.sh
sudo ./install_worker1.sh --env-file /root/worker1.env
```

The separate `worer1-script.sh` performs the ZIP checksum, internal manifest,
ten-key fingerprint, installation, runtime, queue, and shadow checks in one
command.

By default the installer:

1. validates the archive manifest and ten unique Worker 1 key fingerprints;
2. creates a recoverable timestamped backup of the current Worker 1 tree;
3. preserves `.env`, database, sessions, logs, and other mutable data;
4. forces the V9 safety settings and builds the bundled image;
5. runs all zero-network regression tests inside that image;
6. validates Telegram authorization/target resolution;
7. checks all ten Gemini projects through the limiter (429 is reachable;
   authentication/configuration failures are not);
8. applies the V8 message policy, starts the container, and verifies runtime,
   queue, model, deduplication, and database state.

Controlled options remain available:

```bash
sudo ./install_worker1.sh --skip-live-gemini-check
sudo ./install_worker1.sh --skip-bind
sudo ./install_worker1.sh --skip-telegram-check
```

## Runtime status and review

```bash
cd /opt/TelegramForwarder-worker1
docker compose ps
docker compose exec -T telegram-forwarder \
  python /app/worker_tools/verify_runtime.py
docker compose exec -T telegram-forwarder \
  python /app/worker_tools/gemini_queue_status.py
docker compose exec -T telegram-forwarder \
  python /app/worker_tools/local_shadow_status.py
```

To assign a human label to a reported shadow event key:

```bash
docker compose exec -T telegram-forwarder \
  python /app/worker_tools/local_shadow_status.py \
  --event-key EVENT_KEY --label KEEP
```

Export a redacted, unlabeled review sample containing event keys from both
accepted and sampled rejected traffic:

```bash
docker compose exec -T telegram-forwarder \
  python /app/worker_tools/export_shadow_review.py \
  --output /app/logs/shadow_review.jsonl --limit 500
```

The status tools do not print API keys, source IDs, or message text.

When a Worker 2 environment is available, verify zero overlap without printing
key values:

```bash
python worker_tools/compare_key_fingerprints.py \
  --env /root/worker1.env --other-env /root/worker2.env --required-keys 10
```

Worker 1 installation does not require Worker 2 files. Cross-worker overlap is
therefore intentionally reported as not checked until `worker2.env` is supplied.

## Operational note

The SQLite queue preserves deferred/review decisions across restarts and makes
them observable. A request waiting in a live handler is processed automatically.
If the process is interrupted after Telegram has stopped delivering the event,
inspect `gemini_queue_status.py`: orphaned/review work remains visible and is
not silently converted into a forward.

The local model remains shadow-only until several thousand representative
human labels from both accepted and sampled rejected messages are evaluated
with later-time and source-group holdouts. Gemini continues to decide every
production candidate in this release.

The upstream documentation is preserved in `UPSTREAM_README.md`; the GPL
license remains in `LICENSE`.
