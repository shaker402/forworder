"""Persistent Telegram delivery deduplication for Worker 1."""

from __future__ import annotations

import hashlib
import json
import os
import sqlite3
import time
from pathlib import Path


def _path() -> str:
    return os.getenv(
        "TELEGRAM_DELIVERY_DB_PATH", "/app/db/telegram_delivery_dedup.sqlite3"
    ).strip()


def _connect() -> sqlite3.Connection:
    path = _path()
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(path, timeout=30)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA busy_timeout=30000")
    connection.execute("PRAGMA journal_mode=WAL")
    connection.execute("PRAGMA synchronous=FULL")
    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS telegram_delivery (
            delivery_key TEXT PRIMARY KEY,
            worker_namespace TEXT NOT NULL,
            state TEXT NOT NULL,
            lease_until REAL NOT NULL DEFAULT 0,
            delivery_method TEXT,
            created_at REAL NOT NULL,
            updated_at REAL NOT NULL
        )
        """
    )
    return connection


def delivery_key(context) -> str:
    event = context.event
    message = event.message
    grouped_messages = getattr(context, "media_group_messages", None) or []
    message_ids = sorted(
        {
            str(getattr(message, "id", "") or ""),
            *(str(getattr(item, "id", "") or "") for item in grouped_messages),
        }
    )
    rule = context.rule
    material = {
        "worker": os.getenv("WORKER_NAMESPACE", "worker1"),
        "source": str(getattr(context, "chat_id", "") or ""),
        "message_ids": message_ids,
        "grouped_id": str(getattr(message, "grouped_id", "") or ""),
        "rule_id": str(getattr(rule, "id", "") or ""),
        "target_id": str(
            getattr(getattr(rule, "target_chat", None), "telegram_chat_id", "")
            or ""
        ),
    }
    encoded = json.dumps(material, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()


def claim_delivery(context) -> tuple[str, str]:
    key = delivery_key(context)
    now = time.time()
    try:
        lease_seconds = max(
            30.0, float(os.getenv("TELEGRAM_DELIVERY_LEASE_SECONDS", "300"))
        )
    except ValueError:
        lease_seconds = 300.0
    namespace = os.getenv("WORKER_NAMESPACE", "worker1")
    with _connect() as connection:
        connection.execute("BEGIN IMMEDIATE")
        row = connection.execute(
            "SELECT state, lease_until FROM telegram_delivery WHERE delivery_key=?",
            (key,),
        ).fetchone()
        if row and row["state"] == "DELIVERED":
            return "DELIVERED", key
        if row and row["state"] == "PROCESSING" and row["lease_until"] > now:
            return "BUSY", key
        if row:
            connection.execute(
                "UPDATE telegram_delivery SET state='PROCESSING', lease_until=?, "
                "updated_at=? WHERE delivery_key=?",
                (now + lease_seconds, now, key),
            )
        else:
            connection.execute(
                "INSERT INTO telegram_delivery "
                "(delivery_key, worker_namespace, state, lease_until, created_at, updated_at) "
                "VALUES (?, ?, 'PROCESSING', ?, ?, ?)",
                (key, namespace, now + lease_seconds, now, now),
            )
    return "CLAIMED", key


def complete_delivery(key: str, method: str) -> None:
    with _connect() as connection:
        connection.execute(
            "UPDATE telegram_delivery SET state='DELIVERED', lease_until=0, "
            "delivery_method=?, updated_at=? WHERE delivery_key=?",
            (method, time.time(), key),
        )


def release_delivery(key: str) -> None:
    with _connect() as connection:
        connection.execute(
            "DELETE FROM telegram_delivery WHERE delivery_key=? AND state='PROCESSING'",
            (key,),
        )


def diagnostics() -> dict:
    with _connect() as connection:
        rows = connection.execute(
            "SELECT state, COUNT(*) AS count FROM telegram_delivery GROUP BY state"
        ).fetchall()
    return {row["state"]: row["count"] for row in rows}
