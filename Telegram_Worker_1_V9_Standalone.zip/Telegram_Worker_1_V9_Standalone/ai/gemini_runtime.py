"""Persistent Gemini request queue and independent-project rate limiter.

Only SHA-256 key fingerprints are stored. API-key material remains in the
process environment and is never written to SQLite or logs.
"""

from __future__ import annotations

import hashlib
import os
import sqlite3
import time
from pathlib import Path


QUEUE_STATES = {"QUEUED", "IN_FLIGHT", "KEEP", "SKIP", "REVIEW_REQUIRED"}
TERMINAL_STATES = {"KEEP", "SKIP", "REVIEW_REQUIRED"}


def worker_namespace() -> str:
    value = os.getenv("WORKER_NAMESPACE", "worker1").strip()
    return value or "worker1"


def key_fingerprint(value: str) -> str:
    return hashlib.sha256((value or "").encode("utf-8")).hexdigest()


def _env_float(name: str, default: float, minimum: float = 0.0) -> float:
    try:
        value = float(os.getenv(name, str(default)).strip())
    except (TypeError, ValueError):
        value = float(default)
    return max(float(minimum), value)


class PersistentGeminiRuntime:
    """SQLite-backed queue plus ten independent per-project schedulers."""

    def __init__(self, path: str | None = None, namespace: str | None = None):
        self.path = path or os.getenv(
            "GEMINI_QUEUE_PATH", "/app/db/gemini_queue.sqlite3"
        ).strip()
        self.namespace = namespace or worker_namespace()
        self._last_maintenance = 0.0
        self._configured_fingerprints = None
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self._initialize_schema()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.path, timeout=30)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA busy_timeout=30000")
        connection.execute("PRAGMA journal_mode=WAL")
        connection.execute("PRAGMA synchronous=NORMAL")
        return connection

    def _initialize_schema(self) -> None:
        with self._connect() as connection:
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS gemini_project_state (
                    worker_namespace TEXT NOT NULL,
                    slot INTEGER NOT NULL,
                    key_fingerprint TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'ACTIVE',
                    next_start_at REAL NOT NULL DEFAULT 0,
                    cooldown_until REAL NOT NULL DEFAULT 0,
                    inflight_until REAL NOT NULL DEFAULT 0,
                    last_started_at REAL NOT NULL DEFAULT 0,
                    failure_count INTEGER NOT NULL DEFAULT 0,
                    last_error_code TEXT,
                    updated_at REAL NOT NULL,
                    PRIMARY KEY (worker_namespace, slot)
                );

                CREATE TABLE IF NOT EXISTS gemini_request_queue (
                    request_id TEXT PRIMARY KEY,
                    worker_namespace TEXT NOT NULL,
                    state TEXT NOT NULL,
                    model TEXT NOT NULL,
                    source_namespace TEXT NOT NULL,
                    source_chat_id TEXT,
                    telegram_message_id TEXT,
                    rule_id TEXT,
                    message TEXT NOT NULL,
                    prompt TEXT NOT NULL,
                    has_images INTEGER NOT NULL DEFAULT 0,
                    available_at REAL NOT NULL,
                    lease_until REAL NOT NULL DEFAULT 0,
                    assigned_slot INTEGER,
                    attempt_count INTEGER NOT NULL DEFAULT 0,
                    auth_failovers INTEGER NOT NULL DEFAULT 0,
                    transient_attempts INTEGER NOT NULL DEFAULT 0,
                    last_error_code TEXT,
                    result TEXT,
                    created_at REAL NOT NULL,
                    updated_at REAL NOT NULL
                );

                CREATE INDEX IF NOT EXISTS idx_gemini_queue_ready
                    ON gemini_request_queue(worker_namespace, state, available_at);
                """
            )

    @staticmethod
    def _row(row: sqlite3.Row | None) -> dict | None:
        return dict(row) if row is not None else None

    def initialize_projects(self, keys: list[str]) -> None:
        now = time.time()
        fingerprints = [key_fingerprint(key) for key in keys]
        signature = tuple(fingerprints)
        if self._configured_fingerprints == signature:
            return
        with self._connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            for slot, fingerprint in enumerate(fingerprints, 1):
                existing = connection.execute(
                    "SELECT key_fingerprint FROM gemini_project_state "
                    "WHERE worker_namespace=? AND slot=?",
                    (self.namespace, slot),
                ).fetchone()
                if existing is None:
                    connection.execute(
                        "INSERT INTO gemini_project_state "
                        "(worker_namespace, slot, key_fingerprint, updated_at) "
                        "VALUES (?, ?, ?, ?)",
                        (self.namespace, slot, fingerprint, now),
                    )
                elif existing["key_fingerprint"] != fingerprint:
                    connection.execute(
                        "UPDATE gemini_project_state SET key_fingerprint=?, "
                        "status='ACTIVE', next_start_at=0, cooldown_until=0, "
                        "inflight_until=0, failure_count=0, last_error_code=NULL, "
                        "updated_at=? WHERE worker_namespace=? AND slot=?",
                        (fingerprint, now, self.namespace, slot),
                    )
            if fingerprints:
                marks = ",".join("?" for _ in fingerprints)
                connection.execute(
                    f"DELETE FROM gemini_project_state WHERE worker_namespace=? "
                    f"AND slot NOT IN ({marks})",
                    (self.namespace, *range(1, len(fingerprints) + 1)),
                )
            else:
                connection.execute(
                    "DELETE FROM gemini_project_state WHERE worker_namespace=?",
                    (self.namespace,),
                )
        self._configured_fingerprints = signature

    def recover_stale_work(self) -> int:
        now = time.time()
        with self._connect() as connection:
            cursor = connection.execute(
                "UPDATE gemini_request_queue SET state='QUEUED', lease_until=0, "
                "assigned_slot=NULL, available_at=?, updated_at=? "
                "WHERE worker_namespace=? AND state='IN_FLIGHT' AND lease_until<=?",
                (now, now, self.namespace, now),
            )
            connection.execute(
                "UPDATE gemini_project_state SET inflight_until=0, updated_at=? "
                "WHERE worker_namespace=? AND inflight_until<=?",
                (now, self.namespace, now),
            )
            return cursor.rowcount

    def maintenance(self) -> int:
        """Bound completed classifier history while retaining review work."""
        now = time.time()
        interval = _env_float("GEMINI_QUEUE_MAINTENANCE_SECONDS", 3600, 60)
        if now - self._last_maintenance < interval:
            return 0
        self._last_maintenance = now
        retention_days = _env_float("GEMINI_QUEUE_RETENTION_DAYS", 30, 1)
        cutoff = now - retention_days * 86400
        try:
            maximum = max(
                1000, int(os.getenv("GEMINI_QUEUE_MAX_TERMINAL_ROWS", "200000"))
            )
        except ValueError:
            maximum = 200000
        with self._connect() as connection:
            deleted = connection.execute(
                "DELETE FROM gemini_request_queue WHERE worker_namespace=? "
                "AND state IN ('KEEP', 'SKIP') AND updated_at<?",
                (self.namespace, cutoff),
            ).rowcount
            count = connection.execute(
                "SELECT COUNT(*) FROM gemini_request_queue "
                "WHERE worker_namespace=? AND state IN ('KEEP', 'SKIP')",
                (self.namespace,),
            ).fetchone()[0]
            if count > maximum:
                cursor = connection.execute(
                    "DELETE FROM gemini_request_queue WHERE request_id IN ("
                    "SELECT request_id FROM gemini_request_queue "
                    "WHERE worker_namespace=? AND state IN ('KEEP', 'SKIP') "
                    "ORDER BY updated_at ASC LIMIT ?)",
                    (self.namespace, count - maximum),
                )
                deleted += cursor.rowcount
        return deleted

    def enqueue(
        self,
        request_id: str,
        *,
        model: str,
        source_namespace: str,
        source_chat_id: str,
        telegram_message_id: str,
        rule_id: str,
        message: str,
        prompt: str,
        has_images: bool,
    ) -> dict:
        now = time.time()
        with self._connect() as connection:
            connection.execute(
                "INSERT OR IGNORE INTO gemini_request_queue "
                "(request_id, worker_namespace, state, model, source_namespace, "
                "source_chat_id, telegram_message_id, rule_id, message, prompt, "
                "has_images, available_at, created_at, updated_at) "
                "VALUES (?, ?, 'QUEUED', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    request_id,
                    self.namespace,
                    model,
                    source_namespace,
                    source_chat_id,
                    telegram_message_id,
                    rule_id,
                    message,
                    prompt,
                    int(bool(has_images)),
                    now,
                    now,
                    now,
                ),
            )
            row = connection.execute(
                "SELECT * FROM gemini_request_queue WHERE request_id=?",
                (request_id,),
            ).fetchone()
        return self._row(row)

    def get_request(self, request_id: str) -> dict | None:
        with self._connect() as connection:
            row = connection.execute(
                "SELECT * FROM gemini_request_queue WHERE request_id=?",
                (request_id,),
            ).fetchone()
        return self._row(row)

    def claim_request(self, request_id: str) -> tuple[str, dict | None, float]:
        now = time.time()
        lease = _env_float("GEMINI_QUEUE_LEASE_SECONDS", 120, 10)
        with self._connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                "SELECT * FROM gemini_request_queue WHERE request_id=?",
                (request_id,),
            ).fetchone()
            if row is None:
                return "MISSING", None, 0.0
            data = self._row(row)
            if data["state"] in TERMINAL_STATES:
                return data["state"], data, 0.0
            if data["state"] == "IN_FLIGHT" and data["lease_until"] > now:
                return "WAIT", data, max(0.05, data["lease_until"] - now)
            if data["available_at"] > now:
                if data["state"] == "IN_FLIGHT":
                    connection.execute(
                        "UPDATE gemini_request_queue SET state='QUEUED', "
                        "lease_until=0, assigned_slot=NULL, updated_at=? "
                        "WHERE request_id=?",
                        (now, request_id),
                    )
                return "WAIT", data, max(0.05, data["available_at"] - now)
            connection.execute(
                "UPDATE gemini_request_queue SET state='IN_FLIGHT', "
                "lease_until=?, assigned_slot=NULL, updated_at=? "
                "WHERE request_id=?",
                (now + lease, now, request_id),
            )
            updated = connection.execute(
                "SELECT * FROM gemini_request_queue WHERE request_id=?",
                (request_id,),
            ).fetchone()
            return "CLAIMED", self._row(updated), 0.0

    def requeue(
        self,
        request_id: str,
        delay: float,
        error_code: str,
        *,
        auth_increment: int = 0,
        transient_increment: int = 0,
    ) -> None:
        now = time.time()
        with self._connect() as connection:
            connection.execute(
                "UPDATE gemini_request_queue SET state='QUEUED', available_at=?, "
                "lease_until=0, assigned_slot=NULL, attempt_count=attempt_count+1, "
                "auth_failovers=auth_failovers+?, "
                "transient_attempts=transient_attempts+?, last_error_code=?, "
                "updated_at=? WHERE request_id=?",
                (
                    now + max(0.0, delay),
                    auth_increment,
                    transient_increment,
                    error_code,
                    now,
                    request_id,
                ),
            )

    def assign_slot(self, request_id: str, slot: int) -> None:
        with self._connect() as connection:
            connection.execute(
                "UPDATE gemini_request_queue SET assigned_slot=?, updated_at=? "
                "WHERE request_id=?",
                (slot, time.time(), request_id),
            )

    def complete(self, request_id: str, state: str, result: str) -> None:
        if state not in {"KEEP", "SKIP"}:
            raise ValueError(f"Invalid final Gemini state: {state}")
        now = time.time()
        with self._connect() as connection:
            connection.execute(
                "UPDATE gemini_request_queue SET state=?, result=?, "
                "lease_until=0, assigned_slot=NULL, updated_at=? WHERE request_id=?",
                (state, result, now, request_id),
            )

    def mark_review_required(self, request_id: str, error_code: str) -> None:
        now = time.time()
        with self._connect() as connection:
            connection.execute(
                "UPDATE gemini_request_queue SET state='REVIEW_REQUIRED', "
                "last_error_code=?, lease_until=0, assigned_slot=NULL, "
                "updated_at=? WHERE request_id=?",
                (error_code, now, request_id),
            )

    def release_claim(self, request_id: str, delay: float = 0.0) -> None:
        now = time.time()
        with self._connect() as connection:
            connection.execute(
                "UPDATE gemini_request_queue SET state='QUEUED', available_at=?, "
                "lease_until=0, assigned_slot=NULL, updated_at=? "
                "WHERE request_id=? AND state='IN_FLIGHT'",
                (now + max(0.0, delay), now, request_id),
            )

    def reserve_project(
        self, keys: list[str], specific_slot: int | None = None
    ) -> tuple[dict | None, float]:
        now = time.time()
        target_rpm = _env_float("GEMINI_PROJECT_TARGET_RPM", 12, 1)
        configured_interval = _env_float(
            "GEMINI_PROJECT_MIN_INTERVAL_SECONDS", 5, 0.01
        )
        interval = max(configured_interval, 60.0 / target_rpm)
        inflight_lease = _env_float("GEMINI_PROJECT_INFLIGHT_LEASE_SECONDS", 120, 10)

        with self._connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            params: list[object] = [self.namespace]
            slot_clause = ""
            if specific_slot is not None:
                slot_clause = " AND slot=?"
                params.append(int(specific_slot))
            rows = connection.execute(
                "SELECT * FROM gemini_project_state WHERE worker_namespace=?"
                + slot_clause
                + " ORDER BY MAX(next_start_at, cooldown_until, inflight_until), "
                "last_started_at, slot",
                tuple(params),
            ).fetchall()
            for row in rows:
                ready_at = max(
                    float(row["next_start_at"]),
                    float(row["cooldown_until"]),
                    float(row["inflight_until"]),
                )
                if ready_at > now:
                    continue
                slot = int(row["slot"])
                connection.execute(
                    "UPDATE gemini_project_state SET status='ACTIVE', "
                    "next_start_at=?, inflight_until=?, last_started_at=?, "
                    "updated_at=? WHERE worker_namespace=? AND slot=?",
                    (
                        now + interval,
                        now + inflight_lease,
                        now,
                        now,
                        self.namespace,
                        slot,
                    ),
                )
                return {
                    "slot": slot,
                    "key_fingerprint": row["key_fingerprint"],
                    "start_at": now,
                    "interval": interval,
                }, 0.0

            waits = [
                max(
                    float(row["next_start_at"]),
                    float(row["cooldown_until"]),
                    float(row["inflight_until"]),
                )
                - now
                for row in rows
            ]
            return None, max(0.05, min(waits)) if waits else 1.0

    def finish_project(
        self,
        slot: int,
        outcome: str,
        *,
        cooldown_seconds: float = 0.0,
        error_code: str | None = None,
    ) -> None:
        now = time.time()
        cooldown_until = now + max(0.0, cooldown_seconds)
        status = {
            "SUCCESS": "ACTIVE",
            "RATE_LIMITED": "RATE_LIMITED",
            "AUTH": "QUARANTINED",
            "TRANSIENT": "BACKOFF",
        }.get(outcome, "ACTIVE")
        with self._connect() as connection:
            if outcome == "SUCCESS":
                connection.execute(
                    "UPDATE gemini_project_state SET status=?, inflight_until=0, "
                    "failure_count=0, last_error_code=NULL, updated_at=? "
                    "WHERE worker_namespace=? AND slot=?",
                    (status, now, self.namespace, slot),
                )
            else:
                connection.execute(
                    "UPDATE gemini_project_state SET status=?, inflight_until=0, "
                    "cooldown_until=MAX(cooldown_until, ?), "
                    "failure_count=failure_count+1, last_error_code=?, updated_at=? "
                    "WHERE worker_namespace=? AND slot=?",
                    (
                        status,
                        cooldown_until,
                        error_code,
                        now,
                        self.namespace,
                        slot,
                    ),
                )

    def diagnostics(self) -> dict:
        now = time.time()
        with self._connect() as connection:
            queue_rows = connection.execute(
                "SELECT state, COUNT(*) AS count FROM gemini_request_queue "
                "WHERE worker_namespace=? GROUP BY state",
                (self.namespace,),
            ).fetchall()
            projects = connection.execute(
                "SELECT slot, key_fingerprint, status, next_start_at, "
                "cooldown_until, inflight_until, failure_count, last_error_code "
                "FROM gemini_project_state WHERE worker_namespace=? ORDER BY slot",
                (self.namespace,),
            ).fetchall()
        return {
            "worker_namespace": self.namespace,
            "queue_counts": {row["state"]: row["count"] for row in queue_rows},
            "projects": [
                {
                    "slot": row["slot"],
                    "fingerprint": row["key_fingerprint"][:12],
                    "status": row["status"],
                    "ready_in_seconds": round(
                        max(
                            row["next_start_at"],
                            row["cooldown_until"],
                            row["inflight_until"],
                        )
                        - now,
                        3,
                    )
                    if max(
                        row["next_start_at"],
                        row["cooldown_until"],
                        row["inflight_until"],
                    ) > now
                    else 0.0,
                    "failure_count": row["failure_count"],
                    "last_error_code": row["last_error_code"],
                }
                for row in projects
            ],
        }

    def reset_for_tests(self) -> None:
        with self._connect() as connection:
            connection.execute(
                "DELETE FROM gemini_request_queue WHERE worker_namespace=?",
                (self.namespace,),
            )
            connection.execute(
                "DELETE FROM gemini_project_state WHERE worker_namespace=?",
                (self.namespace,),
            )
        self._configured_fingerprints = None
