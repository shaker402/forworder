from typing import Optional, List, Dict
from .base import BaseAIProvider
import asyncio
import hashlib
import json
import logging
import os
import random
import re
import sqlite3
import threading
import time
import unicodedata
import urllib.error
import urllib.parse
import urllib.request

from .gemini_runtime import PersistentGeminiRuntime, worker_namespace

logger = logging.getLogger(__name__)

# Marker used by the installer/verification logic.
MULTI_KEY_GEMINI_POOL = True
PERSISTENT_GEMINI_QUEUE_V9 = True
CLASSIFIER_CONTRACT_V8 = "CLASSIFIER_CONTRACT: SHAKER_WANTED_V8"


class GeminiOpenAIProvider:
    """Existing OpenAI-compatible Gemini path (kept for compatibility)."""

    def __init__(self):
        # Import only when GEMINI_API_BASE explicitly requests this path.
        from .openai_base_provider import OpenAIBaseProvider
        self._provider = OpenAIBaseProvider(
            env_prefix="GEMINI",
            default_model="gemini-pro",
            default_api_base="",
        )

    async def initialize(self, **kwargs):
        return await self._provider.initialize(**kwargs)

    async def process_message(self, *args, **kwargs):
        return await self._provider.process_message(*args, **kwargs)


class GeminiRequestError(RuntimeError):
    def __init__(self, message, status=None, body="", retry_after=None):
        super().__init__(message)
        self.status = status
        self.body = body or ""
        self.retry_after = retry_after


class GeminiQueueDeferred(RuntimeError):
    """The request is safely queued but exceeded this handler's wait budget."""

    queue_state = "QUEUED"

    def __init__(self, request_id):
        super().__init__(f"Gemini request remains queued ({request_id[:12]})")
        self.request_id = request_id


class GeminiReviewRequired(RuntimeError):
    """No safe automatic decision exists; a human review is required."""

    queue_state = "REVIEW_REQUIRED"

    def __init__(self, request_id, reason="provider_failure"):
        super().__init__(
            f"Gemini decision requires review ({request_id[:12]}: {reason})"
        )
        self.request_id = request_id
        self.reason = reason


# Heavrnl's get_ai_provider() creates a fresh provider for each call, so the
# global HTTP semaphore and SQLite runtime handle cross-instance coordination.
_POOL_LOCK = threading.Lock()
_HTTP_SEMAPHORE = None
_HTTP_SEMAPHORE_SIZE = None
_CACHE_LOCK = threading.Lock()
_CACHE_CONNECTION = None
_CACHE_WRITES = 0
_RUNTIME_LOCK = threading.Lock()
_RUNTIME = None
_RUNTIME_SIGNATURE = None


def _env_bool(name, default=False):
    fallback = "true" if default else "false"
    return os.getenv(name, fallback).strip().lower() in {
        "1", "true", "yes", "on"
    }


def _classifier_mode(prompt):
    return bool(prompt and CLASSIFIER_CONTRACT_V8 in prompt)


def _normalize_cache_text(value):
    value = unicodedata.normalize("NFKC", value or "").casefold()
    value = re.sub(r"(?i)\b(?:https?://|www\.)\S+|\b(?:t\.me|wa\.me)/\S+", "[URL]", value)
    value = re.sub(r"(?i)\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", "[EMAIL]", value)
    value = re.sub(r"@[A-Za-z0-9_]{4,}", "[USERNAME]", value)
    value = re.sub(r"(?<!\d)(?:\+?\d[\d\s().-]{6,}\d)(?!\d)", "[PHONE]", value)
    value = re.sub(r"\s+", " ", value).strip()
    return value


def _classifier_cacheable(message, images=None):
    if images:
        return False
    minimum = _env_int("GEMINI_CLASSIFIER_CACHE_MIN_CHARS", 60, 1)
    return len(_normalize_cache_text(message)) >= minimum


def _classifier_cache_key(
    model_name, prompt, message, source_namespace="worker1"
):
    """Hash every decision-bearing input, including filled chat context."""
    normalized_prompt = _normalize_cache_text(prompt)
    material = "\n".join(
        (
            os.getenv("GEMINI_POLICY_VERSION", "SHAKER_WANTED_V9"),
            str(model_name or ""),
            str(source_namespace or worker_namespace()),
            hashlib.sha256(normalized_prompt.encode("utf-8")).hexdigest(),
            _normalize_cache_text(message),
        )
    )
    return hashlib.sha256(material.encode("utf-8")).hexdigest()


def _cache_enabled():
    return _env_bool("GEMINI_CLASSIFIER_CACHE", True)


def _get_cache_connection():
    global _CACHE_CONNECTION
    if _CACHE_CONNECTION is not None:
        return _CACHE_CONNECTION

    path = os.getenv(
        "GEMINI_CLASSIFIER_CACHE_PATH",
        "/app/db/gemini_classifier_cache.sqlite3",
    ).strip()
    directory = os.path.dirname(path)
    if directory:
        os.makedirs(directory, exist_ok=True)

    connection = sqlite3.connect(path, timeout=10, check_same_thread=False)
    connection.execute("PRAGMA journal_mode=WAL")
    connection.execute("PRAGMA synchronous=NORMAL")
    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS classifier_cache (
            cache_key TEXT PRIMARY KEY,
            decision TEXT NOT NULL,
            created_at INTEGER NOT NULL,
            hits INTEGER NOT NULL DEFAULT 0
        )
        """
    )
    connection.commit()
    _CACHE_CONNECTION = connection
    return connection


def _cache_get(cache_key):
    if not _cache_enabled():
        return None
    ttl_seconds = _env_int("GEMINI_CLASSIFIER_CACHE_TTL_DAYS", 30, 1) * 86400
    cutoff = int(time.time()) - ttl_seconds
    try:
        with _CACHE_LOCK:
            connection = _get_cache_connection()
            row = connection.execute(
                "SELECT decision FROM classifier_cache "
                "WHERE cache_key = ? AND created_at >= ?",
                (cache_key, cutoff),
            ).fetchone()
            if not row:
                return None
            connection.execute(
                "UPDATE classifier_cache SET hits = hits + 1 WHERE cache_key = ?",
                (cache_key,),
            )
            connection.commit()
            return row[0] if row[0] in {"KEEP", "#SKIP"} else None
    except Exception as exc:
        logger.warning("Gemini classifier cache read failed: %s", exc)
        return None


def _cache_put(cache_key, decision):
    global _CACHE_WRITES
    if not _cache_enabled() or decision not in {"KEEP", "#SKIP"}:
        return
    try:
        with _CACHE_LOCK:
            connection = _get_cache_connection()
            connection.execute(
                "INSERT OR REPLACE INTO classifier_cache "
                "(cache_key, decision, created_at, hits) VALUES (?, ?, ?, 0)",
                (cache_key, decision, int(time.time())),
            )
            _CACHE_WRITES += 1
            if _CACHE_WRITES % 500 == 0:
                ttl_seconds = _env_int(
                    "GEMINI_CLASSIFIER_CACHE_TTL_DAYS", 30, 1
                ) * 86400
                cutoff = int(time.time()) - ttl_seconds
                connection.execute(
                    "DELETE FROM classifier_cache WHERE created_at < ?",
                    (cutoff,),
                )
                max_rows = _env_int(
                    "GEMINI_CLASSIFIER_CACHE_MAX_ROWS", 200000, 1000
                )
                count = connection.execute(
                    "SELECT COUNT(*) FROM classifier_cache"
                ).fetchone()[0]
                if count > max_rows:
                    connection.execute(
                        "DELETE FROM classifier_cache WHERE cache_key IN ("
                        "SELECT cache_key FROM classifier_cache "
                        "ORDER BY created_at ASC LIMIT ?)",
                        (count - max_rows,),
                    )
            connection.commit()
    except Exception as exc:
        logger.warning("Gemini classifier cache write failed: %s", exc)


def _normalize_classifier_result(result, original_message):
    value = (result or "").strip()
    if value.startswith("```") and value.endswith("```"):
        value = value[3:-3].strip()
        if value.lower().startswith("text\n"):
            value = value[5:].strip()
    if value.upper() == "KEEP":
        return "KEEP", original_message
    if value.upper() == "#SKIP":
        return "#SKIP", "#SKIP"
    raise GeminiRequestError(
        "Gemini violated the V8 classifier output contract",
        status=200,
        body=value[:500],
    )


def _load_api_keys():
    """Return a de-duplicated key pool; support the old single-key setting."""
    raw = os.getenv("GEMINI_API_KEYS", "").strip()

    if raw:
        normalized = raw.replace(";", ",").replace("\n", ",").replace("\r", ",")
        candidates = []
        for chunk in normalized.split(","):
            candidates.extend(chunk.split())
    else:
        legacy = os.getenv("GEMINI_API_KEY", "").strip()
        candidates = [legacy] if legacy else []

    keys = []
    seen = set()
    for key in candidates:
        key = key.strip()
        if key and key not in seen:
            seen.add(key)
            keys.append(key)

    return keys


def _get_runtime():
    global _RUNTIME, _RUNTIME_SIGNATURE
    signature = (
        os.getenv("GEMINI_QUEUE_PATH", "/app/db/gemini_queue.sqlite3").strip(),
        worker_namespace(),
    )
    with _RUNTIME_LOCK:
        if _RUNTIME is None or _RUNTIME_SIGNATURE != signature:
            _RUNTIME = PersistentGeminiRuntime(*signature)
            _RUNTIME_SIGNATURE = signature
        return _RUNTIME


def get_pool_diagnostics():
    """Return scheduler state and fingerprints, never API-key material."""
    keys = _load_api_keys()
    runtime = _get_runtime()
    runtime.initialize_projects(keys)
    durable = runtime.diagnostics()
    cooling_slots = [
        row["slot"]
        for row in durable["projects"]
        if row["status"] != "ACTIVE" or row["ready_in_seconds"] > 0
    ]
    return {
        "configured_keys": len(keys),
        "custom_compatible_base": bool(os.getenv("GEMINI_API_BASE", "").strip()),
        "cooling_slots": cooling_slots,
        "failure_counts_by_slot": {
            row["slot"]: row["failure_count"]
            for row in durable["projects"]
            if row["failure_count"]
        },
        "max_parallel_requests": _env_int(
            "GEMINI_MAX_PARALLEL_REQUESTS", 3, 1
        ),
        "target_rpm_per_project": _env_int(
            "GEMINI_PROJECT_TARGET_RPM", 12, 1
        ),
        "queue_counts": durable["queue_counts"],
        "projects": durable["projects"],
    }


def _reset_runtime_state_for_tests():
    global _HTTP_SEMAPHORE, _HTTP_SEMAPHORE_SIZE
    global _CACHE_CONNECTION, _CACHE_WRITES, _RUNTIME, _RUNTIME_SIGNATURE
    with _POOL_LOCK:
        _HTTP_SEMAPHORE = None
        _HTTP_SEMAPHORE_SIZE = None
    with _CACHE_LOCK:
        if _CACHE_CONNECTION is not None:
            _CACHE_CONNECTION.close()
        _CACHE_CONNECTION = None
        _CACHE_WRITES = 0
    with _RUNTIME_LOCK:
        if _RUNTIME is not None:
            _RUNTIME.reset_for_tests()
        _RUNTIME = None
        _RUNTIME_SIGNATURE = None


def _env_int(name, default, minimum=None):
    try:
        value = int(os.getenv(name, str(default)).strip())
    except Exception:
        value = int(default)
    if minimum is not None:
        value = max(int(minimum), value)
    return value


def _env_float(name, default, minimum=None):
    try:
        value = float(os.getenv(name, str(default)).strip())
    except Exception:
        value = float(default)
    if minimum is not None:
        value = max(float(minimum), value)
    return value


def _get_http_semaphore():
    global _HTTP_SEMAPHORE, _HTTP_SEMAPHORE_SIZE
    size = _env_int("GEMINI_MAX_PARALLEL_REQUESTS", 3, 1)

    with _POOL_LOCK:
        if _HTTP_SEMAPHORE is None or _HTTP_SEMAPHORE_SIZE != size:
            _HTTP_SEMAPHORE = threading.BoundedSemaphore(size)
            _HTTP_SEMAPHORE_SIZE = size
        return _HTTP_SEMAPHORE


def _extract_retry_after(headers, body):
    if headers:
        try:
            value = headers.get("Retry-After")
            if value:
                return max(0.0, float(value))
        except Exception:
            pass

    try:
        payload = json.loads(body or "{}")
        details = payload.get("error", {}).get("details", [])
        for detail in details:
            retry = detail.get("retryDelay") or detail.get("retry_delay")
            if not retry:
                continue
            if isinstance(retry, str) and retry.endswith("s"):
                return max(0.0, float(retry[:-1]))
            if isinstance(retry, dict):
                return max(0.0, float(retry.get("seconds", 0)))
    except Exception:
        pass

    # Some SDK/backend error text includes "retry in 4.28s".
    match = re.search(r"retry\s+in\s+([0-9.]+)s", body or "", re.I)
    if match:
        try:
            return max(0.0, float(match.group(1)))
        except Exception:
            pass

    return None


def _is_key_specific_bad_request(error):
    if error.status != 400:
        return False
    text = (error.body or "").lower()
    markers = (
        "api_key_invalid",
        "api key not valid",
        "api key invalid",
        "api key expired",
        "api_key_service_blocked",
    )
    return any(marker in text for marker in markers)


def _cooldown_seconds_for(error):
    if error.status == 429:
        configured = _env_float("GEMINI_KEY_COOLDOWN_SECONDS", 60, 0.05)
        if error.retry_after is not None:
            return max(configured, error.retry_after)
        return configured

    if error.status in (400, 401, 403):
        return _env_float("GEMINI_KEY_AUTH_COOLDOWN_SECONDS", 1800, 60)

    return _env_float("GEMINI_KEY_ERROR_COOLDOWN_SECONDS", 15, 1)


def _response_text(payload):
    texts = []
    for candidate in payload.get("candidates", []) or []:
        content = candidate.get("content") or {}
        for part in content.get("parts", []) or []:
            text = part.get("text")
            if text:
                texts.append(text)

    if texts:
        return "".join(texts)

    feedback = payload.get("promptFeedback") or {}
    block_reason = feedback.get("blockReason") or feedback.get("block_reason")
    if block_reason:
        raise GeminiRequestError(
            f"Gemini returned no text (prompt blocked: {block_reason})",
            status=200,
            body=json.dumps(payload, ensure_ascii=False)[:2000],
        )

    raise GeminiRequestError(
        "Gemini returned an empty response",
        status=200,
        body=json.dumps(payload, ensure_ascii=False)[:2000],
    )


def _generate_sync(api_key, model_name, message, prompt, images):
    classifier_mode = _classifier_mode(prompt)
    if classifier_mode:
        user_text = f"<NEW_MESSAGE>\n{message}\n</NEW_MESSAGE>"
    else:
        user_text = message

    parts = [{"text": user_text}]

    if images:
        for image in images:
            try:
                mime_type = image["mime_type"]
                data = image["data"]
            except Exception as exc:
                raise GeminiRequestError(
                    f"Invalid Gemini image payload: {exc}",
                    status=400,
                ) from exc

            parts.append(
                {
                    "inlineData": {
                        "mimeType": mime_type,
                        "data": data,
                    }
                }
            )

    payload = {
        "contents": [
            {
                "role": "user",
                "parts": parts,
            }
        ],
        # Deterministic classifier: faster, repeatable KEEP/#SKIP decisions.
        "generationConfig": {
            "temperature": 0.0,
            "topP": 0.1,
            "candidateCount": 1,
        },
        # Preserve the behavior of the project's original Gemini provider.
        "safetySettings": [
            {"category": "HARM_CATEGORY_HARASSMENT", "threshold": "BLOCK_NONE"},
            {"category": "HARM_CATEGORY_HATE_SPEECH", "threshold": "BLOCK_NONE"},
            {"category": "HARM_CATEGORY_SEXUALLY_EXPLICIT", "threshold": "BLOCK_NONE"},
            {"category": "HARM_CATEGORY_DANGEROUS_CONTENT", "threshold": "BLOCK_NONE"},
        ],
    }

    if prompt:
        payload["systemInstruction"] = {
            "parts": [{"text": prompt}],
        }

    if classifier_mode:
        payload["generationConfig"]["maxOutputTokens"] = 8
        payload["generationConfig"]["responseMimeType"] = "text/plain"

    base = os.getenv(
        "GEMINI_REST_API_BASE",
        "https://generativelanguage.googleapis.com/v1beta",
    ).strip().rstrip("/")

    model_path = urllib.parse.quote(model_name, safe="-_.")
    url = f"{base}/models/{model_path}:generateContent"

    request = urllib.request.Request(
        url,
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers={
            "Content-Type": "application/json; charset=utf-8",
            "Accept": "application/json",
            "x-goog-api-key": api_key,
            "User-Agent": "Heavrnl-TelegramForwarder-GeminiPool/2.0",
        },
        method="POST",
    )

    timeout = _env_float("GEMINI_REQUEST_TIMEOUT_SECONDS", 45, 5)
    semaphore = _get_http_semaphore()

    try:
        with semaphore:
            with urllib.request.urlopen(request, timeout=timeout) as response:
                raw = response.read().decode("utf-8", errors="replace")
    except urllib.error.HTTPError as exc:
        try:
            body = exc.read().decode("utf-8", errors="replace")
        except Exception:
            body = ""
        retry_after = _extract_retry_after(exc.headers, body)
        raise GeminiRequestError(
            f"Gemini HTTP {exc.code}",
            status=exc.code,
            body=body,
            retry_after=retry_after,
        ) from None
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        reason = getattr(exc, "reason", None) or str(exc)
        raise GeminiRequestError(
            f"Gemini network error: {reason}",
            status=None,
        ) from None

    try:
        decoded = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise GeminiRequestError(
            f"Gemini returned invalid JSON: {exc}",
            status=200,
            body=raw[:2000],
        ) from None

    if isinstance(decoded, dict) and decoded.get("error"):
        error = decoded["error"]
        raise GeminiRequestError(
            f"Gemini API error: {error.get('message', 'unknown error')}",
            status=error.get("code"),
            body=raw[:2000],
        )

    return _response_text(decoded)


def _request_id(
    model_name, prompt, message, images, source_namespace, source_chat_id,
    telegram_message_id, rule_id,
):
    image_hashes = []
    for image in images or []:
        value = "|".join(
            (str(image.get("mime_type", "")), str(image.get("data", "")))
        )
        image_hashes.append(hashlib.sha256(value.encode("utf-8")).hexdigest())
    material = json.dumps(
        {
            "policy": os.getenv("GEMINI_POLICY_VERSION", "SHAKER_WANTED_V9"),
            "model": model_name,
            "source_namespace": source_namespace,
            "source_chat_id": source_chat_id,
            "telegram_message_id": telegram_message_id,
            "rule_id": rule_id,
            "message": message,
            "prompt": prompt or "",
            "images": image_hashes,
        },
        ensure_ascii=False,
        sort_keys=True,
    )
    return hashlib.sha256(material.encode("utf-8")).hexdigest()


def _auth_error(error):
    return error.status in (401, 403) or _is_key_specific_bad_request(error)


def _transient_error(error):
    return error.status is None or error.status in (408, 500, 502, 503, 504)


class GeminiProvider(BaseAIProvider):
    def __init__(self):
        self.model_name = None
        self.provider = None
        self.api_keys = []
        self.runtime = None

    async def initialize(self, **kwargs):
        api_base = os.getenv("GEMINI_API_BASE", "").strip()
        configured_keys = _load_api_keys()
        required_count = _env_int("GEMINI_REQUIRED_KEY_COUNT", 0, 0)

        if api_base:
            if required_count > 1:
                raise ValueError(
                    "GEMINI_API_BASE disables native project scheduling; clear it "
                    f"to use the required {required_count}-project pool"
                )
            self.provider = GeminiOpenAIProvider()
            await self.provider.initialize(**kwargs)
            return

        self.api_keys = configured_keys
        if not self.api_keys:
            raise ValueError(
                "Neither GEMINI_API_KEYS nor GEMINI_API_KEY is configured"
            )
        if required_count and len(self.api_keys) != required_count:
            raise ValueError(
                f"Expected exactly {required_count} unique Gemini API keys, "
                f"found {len(self.api_keys)}"
            )

        self.model_name = kwargs.get("model") or self.model_name or "gemini-pro"
        self.runtime = _get_runtime()
        await asyncio.to_thread(self.runtime.initialize_projects, self.api_keys)
        recovered = await asyncio.to_thread(self.runtime.recover_stale_work)
        pruned = await asyncio.to_thread(self.runtime.maintenance)
        logger.info(
            "Gemini durable scheduler ready: model=%s projects=%d target_rpm=%d "
            "max_parallel=%d recovered=%d pruned=%d",
            self.model_name,
            len(self.api_keys),
            _env_int("GEMINI_PROJECT_TARGET_RPM", 12, 1),
            _env_int("GEMINI_MAX_PARALLEL_REQUESTS", 3, 1),
            recovered,
            pruned,
        )

    async def _reserve(self, specific_slot=None, deadline=None):
        while True:
            reservation, wait = await asyncio.to_thread(
                self.runtime.reserve_project, self.api_keys, specific_slot
            )
            if reservation:
                return reservation
            if deadline is not None and time.monotonic() >= deadline:
                return None
            sleep_for = min(max(wait, 0.05), 1.0)
            if deadline is not None:
                sleep_for = min(
                    sleep_for, max(0.01, deadline - time.monotonic())
                )
            await asyncio.sleep(sleep_for)

    async def check_key_slot(self, slot, prompt="Reply with exactly OK"):
        """Perform a live slot check through the same persistent limiter."""
        if self.provider is None and not self.api_keys:
            await self.initialize(model=self.model_name or "gemini-pro")
        if not 1 <= int(slot) <= len(self.api_keys):
            raise ValueError("Gemini slot is outside the configured project pool")
        deadline = time.monotonic() + _env_float(
            "GEMINI_HEALTH_MAX_WAIT_SECONDS", 180, 1
        )
        reservation = await self._reserve(int(slot), deadline)
        if reservation is None:
            raise GeminiQueueDeferred(f"health-slot-{slot}")
        key = self.api_keys[int(slot) - 1]
        try:
            result = await asyncio.to_thread(
                _generate_sync,
                key,
                self.model_name,
                "Reply with exactly OK",
                prompt,
                None,
            )
        except GeminiRequestError as exc:
            if exc.status == 429:
                outcome = "RATE_LIMITED"
                cooldown = _cooldown_seconds_for(exc)
            elif _auth_error(exc):
                outcome = "AUTH"
                cooldown = _cooldown_seconds_for(exc)
            else:
                outcome = "TRANSIENT"
                cooldown = _cooldown_seconds_for(exc)
            await asyncio.to_thread(
                self.runtime.finish_project,
                int(slot),
                outcome,
                cooldown_seconds=cooldown,
                error_code=str(exc.status or "NETWORK"),
            )
            raise
        await asyncio.to_thread(
            self.runtime.finish_project, int(slot), "SUCCESS"
        )
        return result

    @staticmethod
    def _mapped_terminal(row, message, classifier_mode):
        state = row["state"]
        if state == "KEEP":
            return message if classifier_mode else (row.get("result") or "")
        if state == "SKIP":
            return "#SKIP"
        if state == "REVIEW_REQUIRED":
            raise GeminiReviewRequired(
                row["request_id"], row.get("last_error_code") or "unknown"
            )
        return None

    async def _process_durable(
        self,
        message,
        prompt,
        images,
        classifier_mode,
        cache_key,
        source_namespace,
        source_chat_id,
        telegram_message_id,
        rule_id,
    ):
        request_id = _request_id(
            self.model_name,
            prompt,
            message,
            images,
            source_namespace,
            source_chat_id,
            telegram_message_id,
            rule_id,
        )
        row = await asyncio.to_thread(
            self.runtime.enqueue,
            request_id,
            model=self.model_name,
            source_namespace=source_namespace,
            source_chat_id=source_chat_id,
            telegram_message_id=telegram_message_id,
            rule_id=rule_id,
            message=message,
            prompt=prompt or "",
            has_images=bool(images),
        )
        mapped = self._mapped_terminal(row, message, classifier_mode)
        if mapped is not None:
            return mapped

        deadline = time.monotonic() + _env_float(
            "GEMINI_QUEUE_MAX_WAIT_SECONDS", 600, 0.1
        )
        while time.monotonic() < deadline:
            claim_state, row, wait = await asyncio.to_thread(
                self.runtime.claim_request, request_id
            )
            if claim_state in {"KEEP", "SKIP", "REVIEW_REQUIRED"}:
                return self._mapped_terminal(row, message, classifier_mode)
            if claim_state == "WAIT":
                await asyncio.sleep(min(max(wait, 0.05), 0.5))
                continue
            if claim_state != "CLAIMED":
                raise GeminiReviewRequired(request_id, "queue_record_missing")

            reservation = await self._reserve(deadline=deadline)
            if reservation is None:
                await asyncio.to_thread(
                    self.runtime.release_claim, request_id, 1.0
                )
                break

            slot = reservation["slot"]
            key = self.api_keys[slot - 1]
            await asyncio.to_thread(self.runtime.assign_slot, request_id, slot)
            try:
                result = await asyncio.to_thread(
                    _generate_sync,
                    key,
                    self.model_name,
                    message,
                    prompt,
                    images,
                )
            except GeminiRequestError as exc:
                code = str(exc.status or "NETWORK")
                if exc.status == 429:
                    cooldown = _cooldown_seconds_for(exc)
                    await asyncio.to_thread(
                        self.runtime.finish_project,
                        slot,
                        "RATE_LIMITED",
                        cooldown_seconds=cooldown,
                        error_code=code,
                    )
                    await asyncio.to_thread(
                        self.runtime.requeue, request_id, cooldown, code
                    )
                    logger.warning(
                        "Gemini slot %d returned 429; request %s requeued for %.1fs",
                        slot,
                        request_id[:12],
                        cooldown,
                    )
                    continue

                if _auth_error(exc):
                    cooldown = _cooldown_seconds_for(exc)
                    await asyncio.to_thread(
                        self.runtime.finish_project,
                        slot,
                        "AUTH",
                        cooldown_seconds=cooldown,
                        error_code=code,
                    )
                    failovers = int(row.get("auth_failovers", 0)) + 1
                    maximum = _env_int("GEMINI_AUTH_FAILOVER_ATTEMPTS", 2, 0)
                    if failovers > maximum:
                        await asyncio.to_thread(
                            self.runtime.mark_review_required,
                            request_id,
                            f"AUTH_{code}",
                        )
                        raise GeminiReviewRequired(request_id, f"AUTH_{code}")
                    await asyncio.to_thread(
                        self.runtime.requeue,
                        request_id,
                        0.0,
                        f"AUTH_{code}",
                        auth_increment=1,
                    )
                    continue

                if _transient_error(exc):
                    await asyncio.to_thread(
                        self.runtime.finish_project,
                        slot,
                        "TRANSIENT",
                        cooldown_seconds=0,
                        error_code=code,
                    )
                    attempt = int(row.get("transient_attempts", 0)) + 1
                    maximum = _env_int("GEMINI_TRANSIENT_MAX_ATTEMPTS", 3, 1)
                    if attempt >= maximum:
                        await asyncio.to_thread(
                            self.runtime.mark_review_required,
                            request_id,
                            f"TRANSIENT_{code}",
                        )
                        raise GeminiReviewRequired(
                            request_id, f"TRANSIENT_{code}"
                        )
                    base = _env_float("GEMINI_RETRY_BASE_SECONDS", 2, 0.05)
                    cap = _env_float("GEMINI_RETRY_MAX_SECONDS", 60, base)
                    jitter = random.uniform(0, min(base, 1.0))
                    delay = min(cap, base * (2 ** (attempt - 1)) + jitter)
                    await asyncio.to_thread(
                        self.runtime.requeue,
                        request_id,
                        delay,
                        f"TRANSIENT_{code}",
                        transient_increment=1,
                    )
                    continue

                await asyncio.to_thread(
                    self.runtime.finish_project,
                    slot,
                    "TRANSIENT",
                    cooldown_seconds=0,
                    error_code=code,
                )
                await asyncio.to_thread(
                    self.runtime.mark_review_required,
                    request_id,
                    f"NON_RETRIABLE_{code}",
                )
                raise GeminiReviewRequired(request_id, f"NON_RETRIABLE_{code}")

            await asyncio.to_thread(
                self.runtime.finish_project, slot, "SUCCESS"
            )
            if classifier_mode:
                try:
                    decision, mapped = _normalize_classifier_result(result, message)
                except GeminiRequestError:
                    await asyncio.to_thread(
                        self.runtime.mark_review_required,
                        request_id,
                        "MALFORMED_CLASSIFIER_OUTPUT",
                    )
                    raise GeminiReviewRequired(
                        request_id, "MALFORMED_CLASSIFIER_OUTPUT"
                    )
                state = "KEEP" if decision == "KEEP" else "SKIP"
                await asyncio.to_thread(
                    self.runtime.complete, request_id, state, decision
                )
                if cache_key:
                    await asyncio.to_thread(_cache_put, cache_key, decision)
                return mapped

            await asyncio.to_thread(
                self.runtime.complete, request_id, "KEEP", result
            )
            return result

        raise GeminiQueueDeferred(request_id)

    async def process_message(
        self,
        message: str,
        prompt: Optional[str] = None,
        images: Optional[List[Dict[str, str]]] = None,
        **kwargs,
    ) -> str:
        if self.provider is None and not self.api_keys:
            await self.initialize(**kwargs)

        classifier_mode = _classifier_mode(prompt)
        model_name = kwargs.get("model") or self.model_name or "gemini-pro"
        self.model_name = model_name
        source_namespace = str(
            kwargs.get("source_namespace") or worker_namespace()
        )
        source_chat_id = str(kwargs.get("source_chat_id") or "")
        telegram_message_id = str(kwargs.get("telegram_message_id") or "")
        rule_id = str(kwargs.get("rule_id") or "")
        cache_namespace = f"{source_namespace}:{source_chat_id}"
        cache_key = None
        if classifier_mode and _classifier_cacheable(message, images):
            cache_key = _classifier_cache_key(
                model_name, prompt, message, cache_namespace
            )
            cached_decision = await asyncio.to_thread(_cache_get, cache_key)
            if cached_decision:
                return message if cached_decision == "KEEP" else "#SKIP"

        if self.provider:
            request_id = _request_id(
                model_name,
                prompt,
                message,
                images,
                source_namespace,
                source_chat_id,
                telegram_message_id,
                rule_id,
            )
            try:
                result = await self.provider.process_message(
                    message, prompt, images, **kwargs
                )
                if not classifier_mode:
                    return result
                decision, mapped = _normalize_classifier_result(result, message)
            except Exception as exc:
                raise GeminiReviewRequired(
                    request_id, type(exc).__name__
                ) from exc
            if cache_key:
                await asyncio.to_thread(_cache_put, cache_key, decision)
            return mapped

        return await self._process_durable(
            message,
            prompt,
            images,
            classifier_mode,
            cache_key,
            source_namespace,
            source_chat_id,
            telegram_message_id,
            rule_id,
        )
