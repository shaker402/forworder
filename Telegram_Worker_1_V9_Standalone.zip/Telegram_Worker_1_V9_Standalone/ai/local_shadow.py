"""Shadow-only local classifier and privacy-reduced decision telemetry.

The local model never changes forwarding behavior in this release. It records
only a proposed action so it can be benchmarked against Gemini and human labels.
"""

from __future__ import annotations

import hashlib
import os
import re
import sqlite3
import threading
import time
from pathlib import Path


_MODEL = None
_MODEL_ERROR = None
_MODEL_LOCK = threading.Lock()


def _enabled() -> bool:
    return os.getenv("LOCAL_SHADOW_ENABLED", "true").strip().lower() in {
        "1", "true", "yes", "on"
    }


def _redact(text: str) -> str:
    value = text or ""
    value = re.sub(r"(?i)\b(?:https?://|www\.)\S+|\b(?:t\.me|wa\.me)/\S+", "[URL]", value)
    value = re.sub(r"(?i)\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", "[EMAIL]", value)
    value = re.sub(r"@[A-Za-z0-9_]{4,}", "[USERNAME]", value)
    value = re.sub(r"(?<!\d)(?:\+?\d[\d\s().-]{6,}\d)(?!\d)", "[PHONE]", value)
    return re.sub(r"\s+", " ", value).strip()[:4000]


def _hash(value: str) -> str:
    salt = os.getenv("LOCAL_SHADOW_HASH_SALT", "worker1-shadow-v9")
    return hashlib.sha256(f"{salt}|{value}".encode("utf-8")).hexdigest()


def _context_identity(context) -> tuple[str, str, str, str]:
    namespace = os.getenv("WORKER_NAMESPACE", "worker1").strip() or "worker1"
    source = str(getattr(context, "chat_id", "") or "")
    event = getattr(context, "event", None)
    message = getattr(event, "message", None)
    message_id = str(getattr(message, "id", "") or "")
    grouped_id = str(getattr(message, "grouped_id", "") or "")
    rule_id = str(getattr(getattr(context, "rule", None), "id", "") or "")
    source_hash = _hash(f"{namespace}|source|{source}")
    message_hash = _hash(
        f"{namespace}|message|{source}|{message_id}|{grouped_id}|{rule_id}"
    )
    event_key = _hash(f"{namespace}|event|{source_hash}|{message_hash}")
    return event_key, namespace, source_hash, message_hash


def _connect() -> sqlite3.Connection:
    path = os.getenv("LOCAL_SHADOW_DB_PATH", "/app/db/local_shadow.sqlite3")
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(path, timeout=30)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA journal_mode=WAL")
    connection.execute("PRAGMA synchronous=NORMAL")
    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS shadow_events (
            event_key TEXT PRIMARY KEY,
            worker_namespace TEXT NOT NULL,
            source_hash TEXT NOT NULL,
            message_hash TEXT NOT NULL,
            sample_origin TEXT NOT NULL,
            redacted_text TEXT NOT NULL,
            local_action TEXT,
            wanted_probability REAL,
            model_policy TEXT,
            gemini_decision TEXT,
            effective_state TEXT,
            review_label TEXT,
            created_at REAL NOT NULL,
            updated_at REAL NOT NULL
        )
        """
    )
    connection.execute(
        "CREATE INDEX IF NOT EXISTS idx_shadow_review "
        "ON shadow_events(review_label, effective_state)"
    )
    return connection


def _load_model():
    global _MODEL, _MODEL_ERROR
    if _MODEL is not None or _MODEL_ERROR is not None:
        return _MODEL
    with _MODEL_LOCK:
        if _MODEL is not None or _MODEL_ERROR is not None:
            return _MODEL
        try:
            import joblib

            path = os.getenv(
                "LOCAL_SHADOW_MODEL_PATH",
                "/app/model/shaker_weak_tfidf_triage.joblib",
            )
            bundle = joblib.load(path)
            _MODEL = bundle
        except Exception as exc:
            _MODEL_ERROR = type(exc).__name__
    return _MODEL


def _propose(text: str) -> tuple[str, float | None, str]:
    bundle = _load_model()
    if bundle is None:
        return "MODEL_UNAVAILABLE", None, _MODEL_ERROR or "unknown"
    probability = float(bundle["pipeline"].predict_proba([text or ""])[0, 1])
    skip_threshold = float(os.getenv("LOCAL_SHADOW_SKIP_THRESHOLD", "0.10"))
    keep_threshold = float(os.getenv("LOCAL_SHADOW_KEEP_THRESHOLD", "0.90"))
    if probability <= skip_threshold:
        action = "LOCAL_SKIP"
    elif probability >= keep_threshold:
        action = "LOCAL_KEEP"
    else:
        action = "ESCALATE"
    return action, probability, str(bundle.get("policy", "unknown"))


def _sample_rejected(event_key: str) -> bool:
    try:
        rate = float(os.getenv("LOCAL_SHADOW_REJECT_SAMPLE_RATE", "0.02"))
    except ValueError:
        rate = 0.02
    rate = min(1.0, max(0.0, rate))
    bucket = int(event_key[:12], 16) / float(16 ** 12)
    return bucket < rate


def record_prefilter_event(context, passed: bool) -> None:
    if not _enabled():
        return
    event_key, namespace, source_hash, message_hash = _context_identity(context)
    if not passed and not _sample_rejected(event_key):
        return
    text = getattr(context, "original_message_text", "") or getattr(
        context, "message_text", ""
    )
    redacted = _redact(text)
    local_action, probability, policy = _propose(redacted)
    now = time.time()
    origin = "PREFILTER_PASS" if passed else "PREFILTER_REJECT_SAMPLE"
    with _connect() as connection:
        connection.execute(
            "INSERT INTO shadow_events "
            "(event_key, worker_namespace, source_hash, message_hash, sample_origin, "
            "redacted_text, local_action, wanted_probability, model_policy, "
            "created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) "
            "ON CONFLICT(event_key) DO UPDATE SET sample_origin=excluded.sample_origin, "
            "redacted_text=excluded.redacted_text, local_action=excluded.local_action, "
            "wanted_probability=excluded.wanted_probability, "
            "model_policy=excluded.model_policy, updated_at=excluded.updated_at",
            (
                event_key,
                namespace,
                source_hash,
                message_hash,
                origin,
                redacted,
                local_action,
                probability,
                policy,
                now,
                now,
            ),
        )
    context.shadow_event_key = event_key


def record_ai_state(context, gemini_decision: str, effective_state: str) -> None:
    if not _enabled():
        return
    event_key, namespace, source_hash, message_hash = _context_identity(context)
    now = time.time()
    with _connect() as connection:
        connection.execute(
            "INSERT INTO shadow_events "
            "(event_key, worker_namespace, source_hash, message_hash, sample_origin, "
            "redacted_text, gemini_decision, effective_state, created_at, updated_at) "
            "VALUES (?, ?, ?, ?, 'AI_DECISION', ?, ?, ?, ?, ?) "
            "ON CONFLICT(event_key) DO UPDATE SET "
            "gemini_decision=excluded.gemini_decision, "
            "effective_state=excluded.effective_state, updated_at=excluded.updated_at",
            (
                event_key,
                namespace,
                source_hash,
                message_hash,
                _redact(getattr(context, "original_message_text", "")),
                gemini_decision,
                effective_state,
                now,
                now,
            ),
        )
    context.shadow_event_key = event_key


def set_review_label(event_key: str, label: str) -> bool:
    normalized = label.strip().upper()
    if normalized not in {"KEEP", "SKIP"}:
        raise ValueError("Review label must be KEEP or SKIP")
    with _connect() as connection:
        cursor = connection.execute(
            "UPDATE shadow_events SET review_label=?, updated_at=? WHERE event_key=?",
            (normalized, time.time(), event_key),
        )
        return cursor.rowcount == 1


def review_sample(limit: int = 200, origin: str | None = None) -> list[dict]:
    limit = min(5000, max(1, int(limit)))
    parameters: list[object] = []
    where = "WHERE review_label IS NULL"
    if origin:
        where += " AND sample_origin=?"
        parameters.append(origin)
    parameters.append(limit)
    with _connect() as connection:
        rows = connection.execute(
            "SELECT event_key, sample_origin, redacted_text, local_action, "
            "wanted_probability, gemini_decision, effective_state, created_at "
            f"FROM shadow_events {where} "
            "ORDER BY sample_origin, created_at LIMIT ?",
            tuple(parameters),
        ).fetchall()
    return [dict(row) for row in rows]


def diagnostics() -> dict:
    with _connect() as connection:
        total = connection.execute("SELECT COUNT(*) FROM shadow_events").fetchone()[0]
        labeled = connection.execute(
            "SELECT COUNT(*) FROM shadow_events WHERE review_label IS NOT NULL"
        ).fetchone()[0]
        states = connection.execute(
            "SELECT COALESCE(effective_state, 'PENDING') AS state, COUNT(*) AS count "
            "FROM shadow_events GROUP BY COALESCE(effective_state, 'PENDING')"
        ).fetchall()
        proposals = connection.execute(
            "SELECT COALESCE(local_action, 'PENDING') AS action, COUNT(*) AS count "
            "FROM shadow_events GROUP BY COALESCE(local_action, 'PENDING')"
        ).fetchall()
    return {
        "mode": "SHADOW_ONLY",
        "total": total,
        "human_labeled": labeled,
        "effective_states": {row["state"]: row["count"] for row in states},
        "local_proposals": {row["action"]: row["count"] for row in proposals},
        "model_error": _MODEL_ERROR,
    }
