# Worker 1 V9 validation report

Validation date: 2026-08-31 UTC

## Input and configuration checks

- The uploaded Worker 1 V8 Fixed archive passed its internal manifest before
  modification.
- The supplied `worker1.env` passed structural validation with exactly ten
  configured and ten unique SHA-256 key fingerprints. Complete key values were
  never printed or copied into this project.
- Fourteen sensitive values (ten Gemini slots plus the Telegram/API credential
  fields) were byte-scanned across the final source tree: zero matches. Generic
  Gemini credential-prefix scans also returned zero matches. No `.env` or
  Telethon session file is present.
- Worker 2 inputs were intentionally out of scope. Cross-worker fingerprint
  overlap was not claimed; `compare_key_fingerprints.py --other-env` is included
  for that later check.

## Passed zero-network tests

- All Python files compile and `install_worker1.sh` passes `bash -n`.
- The V9 Gemini test passed ten persistent project buckets, 429 delayed requeue
  without immediate key cascade, `Retry-After`, authentication quarantine and
  bounded failover, malformed-output review, three-call global concurrency,
  per-project spacing, terminal queue states, and nine-key rejection.
- Dummy key material was absent from the SQLite queue files. The production
  request URL does not include the key; it is sent only as the API header.
- The 200-candidate scheduler simulation produced zero modeled quota failures
  and a final dispatch start at 95.6 seconds with ten projects, five-second
  spacing, and three global in-flight calls.
- Injected `QUEUED`, `REVIEW_REQUIRED`, and unexpected provider failures all
  stopped `AIFilter`; none forwarded the unchanged candidate.
- Classifier cache tests passed complete filled-context and worker/source
  namespace separation as well as contact redaction.
- Persistent Telegram delivery tests passed claim, busy, release/reclaim, and
  completed-delivery suppression across independent SQLite connections.
- The included Shaker weak TF-IDF model loaded successfully in shadow-only mode.
  Accepted/rejected event schema, deterministic reject sampling, pseudonymous
  source/message identity, email/phone redaction, Gemini/effective states, and
  review-label storage passed.
- Existing V8 regression tests passed: all 20 important wanted examples reached
  the prefilter; all five substring collisions were rejected; the 64-case
  regression file validated.
- Native Telegram forwarding contracts passed single/album ordering,
  `drop_author=False`, target guard, metadata reply, screenshot-style layout,
  and fallback behavior without network access.
- The detached database-rule path passed 50 simulated concurrent waits with
  zero checked-out SQLAlchemy connections during and after external I/O.
- Bulk policy migration passed three rules with exactly 100 literal whitelist,
  five regex whitelist, and one blacklist row per rule. Runtime verification
  observed ten scheduler buckets, three global requests, and 12 RPM/project.
- Auto-bind source cloning and destination feedback exclusion passed.
- Mocked installer rollback restored the previous tree after a forced build
  failure. The success path preserved credential values, database/session state,
  forced the V9 mitigation values, and retained a timestamped backup.

## Deployment-time validation

This workspace has no Docker daemon and made no live Telegram or Gemini calls.
The installer repeats the zero-network tests inside the final image, validates
the Telegram session/target, checks each Gemini project through the persistent
limiter, starts the real container, waits for health, and runs runtime, queue,
and shadow diagnostics. A failed deployment restores the previous Worker 1.

A 429 counts as provider reachability during installation but remains visibly
rate-limited; authentication/configuration errors do not pass the ten-project
health requirement.

## Operational limitation made explicit

The queue preserves pending and review work across restart and never silently
turns provider failure into a forward. Live handlers automatically wait for and
complete queued work up to their configured budget. If the whole process is
interrupted after Telegram stops delivering that event, the queue item remains
observable for review; V9 does not claim autonomous reconstruction and delivery
of an orphaned Telegram event.

The weak local model is not authorized to keep or skip production messages.
Promotion requires several thousand representative human labels and later-time
plus source-group holdout evaluation against an Arabic transformer.
