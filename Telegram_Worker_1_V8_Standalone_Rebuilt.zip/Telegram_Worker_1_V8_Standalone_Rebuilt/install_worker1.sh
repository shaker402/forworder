#!/usr/bin/env bash
set -Eeuo pipefail

WORKER_NUM="1"
BUNDLE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET_DIR="${TELEGRAM_WORKER_DIR:-/opt/TelegramForwarder-worker${WORKER_NUM}}"
SERVICE="telegram-forwarder"
CONTAINER="telegram-forwarder-worker${WORKER_NUM}"
BACKUP_DIR=""
DEPLOYED_NEW_TREE=0

log()  { printf '\n\033[1;36m[+] %s\033[0m\n' "$*"; }
warn() { printf '\n\033[1;33m[!] %s\033[0m\n' "$*" >&2; }
die()  { printf '\n\033[1;31m[ERROR] %s\033[0m\n' "$*" >&2; return 1; }

rollback() {
  rc=$?
  trap - ERR
  if [ "$rc" -ne 0 ] && [ -n "$BACKUP_DIR" ] && [ -d "$BACKUP_DIR" ]; then
    warn "Installation failed; restoring the previous worker tree."
    set +e
    if [ -d "$TARGET_DIR" ]; then
      (cd "$TARGET_DIR" && docker compose down >/dev/null 2>&1) || true
      failed_dir="${TARGET_DIR}.failed-$(date +%Y%m%d-%H%M%S)"
      mv "$TARGET_DIR" "$failed_dir"
      warn "Failed new tree retained at $failed_dir"
    fi
    mv "$BACKUP_DIR" "$TARGET_DIR"
    (cd "$TARGET_DIR" && docker compose up -d "$SERVICE") || true
  elif [ "$rc" -ne 0 ] && [ "$DEPLOYED_NEW_TREE" -eq 1 ]; then
    warn "Fresh installation failed; the tree is retained at $TARGET_DIR for diagnosis."
  fi
  exit "$rc"
}
trap rollback ERR

[ "${EUID:-$(id -u)}" -eq 0 ] || die "Run this installer as root."
[ -f "$BUNDLE_DIR/.env" ] || die "Missing bundled .env"
[ -f "$BUNDLE_DIR/MANIFEST.sha256" ] || die "Missing MANIFEST.sha256"

log "Verifying the standalone source manifest..."
(cd "$BUNDLE_DIR" && sha256sum -c MANIFEST.sha256)

get_env() {
  key="$1"
  file="${2:-$BUNDLE_DIR/.env}"
  sed -n "s/^${key}=//p" "$file" | tail -n1
}

for key in API_ID API_HASH PHONE_NUMBER BOT_TOKEN USER_ID ADMINS OUTPUT_GROUP_RAW_ID; do
  value="$(get_env "$key")"
  [ -n "$value" ] && [ "$value" != "CHANGE_ME" ] \
    || die "$key is not configured in the bundled .env"
done

python3 - "$BUNDLE_DIR/.env" <<'PY_KEYS'
from pathlib import Path
import sys

value = ""
for line in Path(sys.argv[1]).read_text(encoding="utf-8").splitlines():
    if line.startswith("GEMINI_API_KEYS="):
        value = line.split("=", 1)[1].strip()
        break
keys = []
for chunk in value.replace(";", ",").split(","):
    key = chunk.strip()
    if key and key not in keys:
        keys.append(key)
if len(keys) != 10:
    raise SystemExit(f"Expected 10 unique Gemini key slots; found {len(keys)}")
print("Gemini key slots: 10 unique values configured (values not displayed)")
PY_KEYS

log "Installing/checking Docker prerequisites..."
export DEBIAN_FRONTEND=noninteractive
if command -v apt-get >/dev/null 2>&1; then
  apt-get update -y
  apt-get install -y ca-certificates python3 rsync
  if ! command -v docker >/dev/null 2>&1; then
    apt-get install -y docker.io
  fi
  systemctl enable --now docker >/dev/null 2>&1 || true
  if ! docker compose version >/dev/null 2>&1; then
    apt-get install -y docker-compose-plugin 2>/dev/null \
      || apt-get install -y docker-compose-v2 2>/dev/null \
      || die "Docker Compose v2 could not be installed"
  fi
else
  die "The automated installer supports apt-based Debian/Ubuntu hosts."
fi
docker compose version >/dev/null 2>&1 || die "Docker Compose v2 is required."

if command -v timedatectl >/dev/null 2>&1; then
  ntp_state="$(timedatectl show -p NTPSynchronized --value 2>/dev/null || true)"
  [ "$ntp_state" = "yes" ] || warn "Host NTP is not reported synchronized; Telegram requires an accurate clock."
fi

bundle_real="$(realpath "$BUNDLE_DIR")"
target_parent="$(dirname "$TARGET_DIR")"
mkdir -p "$target_parent"

if [ -d "$TARGET_DIR" ] && [ "$(realpath "$TARGET_DIR")" != "$bundle_real" ]; then
  log "Stopping and backing up the existing worker..."
  if [ -f "$TARGET_DIR/docker-compose.yml" ]; then
    (cd "$TARGET_DIR" && docker compose stop "$SERVICE") || true
  fi
  BACKUP_DIR="${TARGET_DIR}.backup-before-v8-rebuilt-$(date +%Y%m%d-%H%M%S)"
  mv "$TARGET_DIR" "$BACKUP_DIR"
fi

if [ ! -d "$TARGET_DIR" ]; then
  log "Installing the complete local source tree at $TARGET_DIR..."
  mkdir -p "$TARGET_DIR"
  rsync -a \
    --exclude '.env' \
    --exclude 'db/' \
    --exclude 'logs/' \
    --exclude 'sessions/' \
    --exclude 'temp/' \
    --exclude 'rss/data/' \
    --exclude 'rss/media/' \
    --exclude 'ufb/config/' \
    "$BUNDLE_DIR/" "$TARGET_DIR/"

  if [ -n "$BACKUP_DIR" ] \
     && [ "${PRESERVE_EXISTING_ENV:-true}" = "true" ] \
     && [ -f "$BACKUP_DIR/.env" ]; then
    cp "$BACKUP_DIR/.env" "$TARGET_DIR/.env"
  else
    cp "$BUNDLE_DIR/.env" "$TARGET_DIR/.env"
  fi

  for runtime_dir in db logs sessions temp rss/data rss/media ufb/config; do
    mkdir -p "$TARGET_DIR/$runtime_dir"
    if [ -n "$BACKUP_DIR" ] && [ -d "$BACKUP_DIR/$runtime_dir" ]; then
      rsync -a "$BACKUP_DIR/$runtime_dir/" "$TARGET_DIR/$runtime_dir/"
    fi
  done
  DEPLOYED_NEW_TREE=1
fi

chmod 600 "$TARGET_DIR/.env"
cd "$TARGET_DIR"

log "Building the bundled source (no Git clone and no floating app image)..."
docker compose build --pull "$SERVICE"
docker compose config >/dev/null

log "Running zero-network V8 regression tests..."
docker compose run --rm -T --no-deps "$SERVICE" \
  python /app/worker_tools/prefilter_recall_selftest.py
docker compose run --rm -T --no-deps "$SERVICE" \
  python /app/worker_tools/classifier_contract_selftest.py
docker compose run --rm -T --no-deps "$SERVICE" \
  python /app/worker_tools/gemini_pool_selftest.py
docker compose run --rm -T --no-deps "$SERVICE" \
  python /app/worker_tools/static_lifecycle_selftest.py
docker compose run --rm -T --no-deps "$SERVICE" \
  python /app/worker_tools/db_pool_selftest.py
docker compose run --rm -T --no-deps "$SERVICE" \
  python /app/worker_tools/evaluate_gemini_filter.py --validate-only

if [ "${SKIP_GEMINI_LIVE_PROBE:-false}" != "true" ]; then
  log "Probing all ten Gemini key slots against the configured model..."
  docker compose run --rm -T --no-deps "$SERVICE" \
    python /app/worker_tools/probe_gemini_pool.py --live --strict
else
  warn "SKIP_GEMINI_LIVE_PROBE=true: live ten-slot validation was skipped."
fi

log "Authorizing the Telegram USER account..."
echo "Telegram may ask once for a login code and 2FA password."
docker compose run --rm --no-deps "$SERVICE" \
  python /app/worker_tools/authorize_user.py

output_name="$(get_env OUTPUT_GROUP_NAME "$TARGET_DIR/.env")"
output_raw="$(get_env OUTPUT_GROUP_RAW_ID "$TARGET_DIR/.env")"
[[ "$output_raw" =~ ^-?[0-9]+$ ]] || die "OUTPUT_GROUP_RAW_ID is missing or invalid"

log "Discovering the exact USER-client native target for ${output_name:-output group}..."
discovery="$(
  docker compose run --rm -T --no-deps "$SERVICE" \
    python /app/worker_tools/discover_target.py
)"
printf '%s\n' "$discovery"
native_target="$(printf '%s\n' "$discovery" | sed -n 's/^NATIVE_QUOTE_TARGET=//p' | tail -n1 | tr -d '\r[:space:]')"
case "$native_target" in
  -*) ;;
  *) die "Could not discover a valid marked Telegram destination ID." ;;
esac

python3 - "$TARGET_DIR/.env" "$native_target" "$output_raw" <<'PY_ENV'
from pathlib import Path
import sys

path = Path(sys.argv[1])
wanted = {"NATIVE_QUOTE_TARGET": sys.argv[2], "AUTO_BIND_TARGET_ID": sys.argv[3]}
lines = path.read_text(encoding="utf-8").splitlines()
output = []
seen = set()
for line in lines:
    for key, value in wanted.items():
        if line.startswith(key + "="):
            output.append(f"{key}={value}")
            seen.add(key)
            break
    else:
        output.append(line)
for key, value in wanted.items():
    if key not in seen:
        output.append(f"{key}={value}")
path.write_text("\n".join(output) + "\n", encoding="utf-8")
PY_ENV
chmod 600 "$TARGET_DIR/.env"

log "Binding visible groups/channels and applying the V8 policy..."
docker compose run --rm -T --no-deps "$SERVICE" \
  python /app/bulk_bind_all.py --target-id "$output_raw" --apply
docker compose run --rm -T --no-deps "$SERVICE" \
  python /app/bulk_configure_student_filter.py --target-id "$output_raw" --apply

log "Starting Worker 1..."
docker compose up -d --force-recreate "$SERVICE"

stable=0
initial_restarts="$(docker inspect -f '{{.RestartCount}}' "$CONTAINER" 2>/dev/null || echo 999)"
for _ in $(seq 1 45); do
  running="$(docker inspect -f '{{.State.Running}}' "$CONTAINER" 2>/dev/null || echo false)"
  health="$(docker inspect -f '{{if .State.Health}}{{.State.Health.Status}}{{else}}starting{{end}}' "$CONTAINER" 2>/dev/null || echo missing)"
  restarts="$(docker inspect -f '{{.RestartCount}}' "$CONTAINER" 2>/dev/null || echo 999)"
  if [ "$running" = "true" ] && [ "$health" = "healthy" ] && [ "$restarts" = "$initial_restarts" ]; then
    stable=1
    break
  fi
  sleep 2
done

if [ "$stable" -ne 1 ]; then
  docker compose ps || true
  docker compose logs --tail=180 "$SERVICE" || true
  die "Worker did not become healthy or entered a restart loop."
fi

log "Verifying live database, V8 policy, and ten-key configuration..."
docker compose exec -T "$SERVICE" python /app/worker_tools/verify_runtime.py
docker compose ps

trap - ERR
DEPLOYED_NEW_TREE=0

cat <<EOF

============================================================
TELEGRAM WORKER 1 V8 REBUILT INSTALLED
============================================================
Project: $TARGET_DIR
Container: $CONTAINER
Model: gemini-3.5-flash-lite
Gemini slots: 10 local round-robin/failover keys
Source: bundled full TelegramForwarder tree (no runtime Git clone)
Backup: ${BACKUP_DIR:-not needed}

Logs:
  cd $TARGET_DIR
  docker compose logs -f --tail=100 $SERVICE
============================================================
EOF
