"""AI provider routing with lazy imports.

The upstream package imported every optional SDK when :mod:`ai` was imported.
That made the Gemini-only worker depend on successful initialization of all
other provider packages and made offline Gemini health checks unnecessarily
fragile. Providers are now imported only when their model is selected.
"""

from importlib import import_module

from .base import BaseAIProvider


_PROVIDER_CLASSES = {
    "openai": ("ai.openai_provider", "OpenAIProvider"),
    "gemini": ("ai.gemini_provider", "GeminiProvider"),
    "deepseek": ("ai.deepseek_provider", "DeepSeekProvider"),
    "qwen": ("ai.qwen_provider", "QwenProvider"),
    "grok": ("ai.grok_provider", "GrokProvider"),
    "claude": ("ai.claude_provider", "ClaudeProvider"),
}


def _load_provider_class(provider_name):
    try:
        module_name, class_name = _PROVIDER_CLASSES[provider_name]
    except KeyError as exc:
        raise ValueError(f"Unsupported AI provider: {provider_name}") from exc

    module = import_module(module_name)
    return getattr(module, class_name)


async def get_ai_provider(model=None):
    """Return the provider for an exactly configured model name."""
    # Keep dotenv/config helpers out of the package import path.  This lets the
    # Gemini pool health checks run before optional application dependencies
    # are initialized, and prevents unrelated provider SDKs from blocking it.
    from utils.constants import DEFAULT_AI_MODEL
    from utils.settings import load_ai_models

    selected_model = model or DEFAULT_AI_MODEL
    providers_config = load_ai_models(type="dict")

    for provider_name, models_list in providers_config.items():
        if selected_model in models_list:
            provider_class = _load_provider_class(provider_name)
            return provider_class()

    raise ValueError(f"Unsupported model: {selected_model}")


def __getattr__(name):
    """Keep the original public class imports backward compatible."""
    if name == "BaseAIProvider":
        return BaseAIProvider
    for provider_name, (_, class_name) in _PROVIDER_CLASSES.items():
        if name == class_name:
            return _load_provider_class(provider_name)
    raise AttributeError(name)


__all__ = [
    "BaseAIProvider",
    "OpenAIProvider",
    "GeminiProvider",
    "DeepSeekProvider",
    "QwenProvider",
    "GrokProvider",
    "ClaudeProvider",
    "get_ai_provider",
]
