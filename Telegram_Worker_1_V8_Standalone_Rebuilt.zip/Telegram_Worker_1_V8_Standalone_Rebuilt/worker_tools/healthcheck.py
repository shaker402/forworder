#!/usr/bin/env python3
"""Fast, secret-safe Docker health check."""

import os
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from dotenv import load_dotenv

load_dotenv(ROOT / ".env", override=False)

from sqlalchemy import text
from ai.gemini_provider import _load_api_keys
from models.models import get_session


def main():
    if len(_load_api_keys()) != 10:
        raise SystemExit("Gemini pool is not configured with 10 unique keys")

    if not (ROOT / "db").is_dir():
        raise SystemExit("Database directory is missing")

    session = get_session()
    try:
        session.execute(text("SELECT 1")).scalar_one()
    finally:
        session.close()

    # Compose's ``init: true`` intentionally makes Tini PID 1, so locate the
    # Python worker among container processes instead of assuming it is PID 1.
    proc = Path("/proc")
    if proc.is_dir():
        worker_running = False
        for entry in proc.iterdir():
            if not entry.name.isdigit():
                continue
            try:
                argv = entry.joinpath("cmdline").read_bytes().split(b"\x00")
            except (FileNotFoundError, PermissionError, ProcessLookupError):
                continue
            if any(argument.endswith(b"/main.py") or argument == b"main.py" for argument in argv):
                worker_running = True
                break
        if not worker_running:
            raise SystemExit("Worker main.py process is not running")

    print("healthy")


if __name__ == "__main__":
    main()
