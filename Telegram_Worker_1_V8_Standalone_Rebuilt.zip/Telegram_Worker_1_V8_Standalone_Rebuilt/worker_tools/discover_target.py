#!/usr/bin/env python3
import asyncio
import os

from dotenv import load_dotenv
from telethon import TelegramClient

load_dotenv("/app/.env", override=True)

async def main():
    api_id = int(os.environ["API_ID"])
    api_hash = os.environ["API_HASH"]
    raw_id = int(os.environ.get("OUTPUT_GROUP_RAW_ID", "5448618423"))
    wanted_name = os.environ.get("OUTPUT_GROUP_NAME", "AI_filter").strip().casefold()

    client = TelegramClient("/app/sessions/user", api_id, api_hash)
    await client.connect()
    try:
        if not await client.is_user_authorized():
            raise SystemExit("Telegram USER session is not authorized")

        matches = []
        async for dialog in client.iter_dialogs():
            if int(getattr(dialog.entity, "id", 0)) != raw_id:
                continue
            if wanted_name and (dialog.name or "").strip().casefold() != wanted_name:
                continue
            matches.append(dialog)

        if len(matches) != 1:
            raise SystemExit(
                f"Expected one output group raw_id={raw_id} name={wanted_name!r}, "
                f"found {len(matches)}"
            )

        dialog = matches[0]
        print(f"OUTPUT_GROUP_FOUND={dialog.name}")
        print(f"OUTPUT_GROUP_RAW_ID={dialog.entity.id}")
        print(f"NATIVE_QUOTE_TARGET={dialog.id}")
    finally:
        await client.disconnect()

asyncio.run(main())
