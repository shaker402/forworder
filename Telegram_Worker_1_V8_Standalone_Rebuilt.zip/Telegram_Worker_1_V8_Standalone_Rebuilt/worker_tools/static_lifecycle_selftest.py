#!/usr/bin/env python3
"""Static regression checks for the connection-lifecycle repair."""

import ast
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def function(tree, name):
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == name:
            return node
    raise AssertionError(f"Missing function: {name}")


listener_path = ROOT / "message_listener.py"
listener_text = listener_path.read_text(encoding="utf-8")
listener_tree = ast.parse(listener_text, filename=str(listener_path))

loader = function(listener_tree, "_load_forward_rules")
handler = function(listener_tree, "_handle_user_message")

assert "session.close()" in ast.unparse(loader)
assert "session.expunge_all()" in ast.unparse(loader)
assert "async with _AUTO_BIND_LOCK" in ast.unparse(loader)
assert ast.unparse(loader).find("session.close()") < ast.unparse(loader).find(
    "async with _AUTO_BIND_LOCK"
)
assert "get_session()" not in ast.unparse(handler)
assert "await _load_forward_rules(event, chat_id)" in ast.unparse(handler)

auto_bind_path = ROOT / "auto_bind_new_chat.py"
auto_bind_tree = ast.parse(
    auto_bind_path.read_text(encoding="utf-8"),
    filename=str(auto_bind_path),
)
auto_bind = function(auto_bind_tree, "ensure_auto_rule")
assert not isinstance(auto_bind, ast.AsyncFunctionDef)
assert not any(isinstance(node, ast.Await) for node in ast.walk(auto_bind))

chat_updater_path = ROOT / "scheduler" / "chat_updater.py"
chat_updater_tree = ast.parse(
    chat_updater_path.read_text(encoding="utf-8"),
    filename=str(chat_updater_path),
)
chat_update = ast.unparse(function(chat_updater_tree, "_update_all_chats"))
assert chat_update.find("session.close()") < chat_update.find(
    "await self.user_client.get_entity"
)

summary_path = ROOT / "scheduler" / "summary_scheduler.py"
summary_tree = ast.parse(
    summary_path.read_text(encoding="utf-8"),
    filename=str(summary_path),
)
summary = ast.unparse(function(summary_tree, "_execute_summary"))
assert summary.find("session.close()") < summary.find(
    "await self.user_client.get_messages"
)

rss_text = (ROOT / "filters" / "rss_filter.py").read_text(encoding="utf-8")
assert "session.close()" in rss_text

models_text = (ROOT / "models" / "models.py").read_text(encoding="utf-8")
assert "expire_on_commit=False" in models_text
assert "DATABASE_POOL_SIZE" in models_text
assert "PRAGMA journal_mode=WAL" in models_text

health_text = (ROOT / "worker_tools" / "healthcheck.py").read_text(
    encoding="utf-8"
)
assert '/proc/1/cmdline' not in health_text
assert 'entry.name.isdigit()' in health_text

sender_path = ROOT / "filters" / "sender_filter.py"
sender_tree = ast.parse(
    sender_path.read_text(encoding="utf-8"),
    filename=str(sender_path),
)
native_forward = ast.unparse(function(sender_tree, "_try_native_quote_forward"))
assert "if _compact_details_enabled():" in native_forward
assert "elif _native_inline_details_enabled():" in native_forward
assert "elif _native_details_enabled():" in native_forward

print("MESSAGE_DB_SESSION_CLOSED_BEFORE_NETWORK=OK")
print("AUTO_BIND_HAS_NO_DB_NETWORK_AWAIT=OK")
print("SCHEDULERS_CLOSE_DB_BEFORE_NETWORK=OK")
print("RSS_SESSION_LIFECYCLE=OK")
print("SQLITE_POOL_AND_WAL_CONFIGURATION=OK")
print("TINI_AWARE_HEALTHCHECK=OK")
print("NATIVE_METADATA_SINGLE_STRATEGY=OK")
