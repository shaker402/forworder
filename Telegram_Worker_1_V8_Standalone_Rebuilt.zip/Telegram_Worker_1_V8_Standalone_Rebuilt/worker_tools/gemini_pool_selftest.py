#!/usr/bin/env python3
"""Zero-network round-robin and failover test for the ten-key provider."""

import asyncio
import collections
import os
import sys
import threading
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

os.environ["GEMINI_API_KEYS"] = ",".join(f"fake-key-{index}" for index in range(1, 11))
os.environ["GEMINI_API_BASE"] = ""
os.environ["GEMINI_FORCE_REST_POOL"] = "true"
os.environ["GEMINI_CLASSIFIER_CACHE"] = "false"
os.environ["GEMINI_MAX_KEY_ATTEMPTS"] = "4"
os.environ["GEMINI_MAX_PARALLEL_REQUESTS"] = "10"
os.environ["GEMINI_FAIL_OPEN"] = "false"

import ai.gemini_provider as gemini
from filter_policy_v8 import MODEL, PROMPT


async def main():
    calls = collections.Counter()
    lock = threading.Lock()

    def fake_generate(key, model, message, prompt, images, request_timeout=None):
        assert model == MODEL
        assert request_timeout and request_timeout > 0
        with lock:
            calls[key] += 1
        return "KEEP"

    original_generate = gemini._generate_sync
    gemini._generate_sync = fake_generate
    try:
        provider = gemini.GeminiProvider()
        await provider.initialize(model=MODEL)
        results = await asyncio.gather(
            *(
                provider.process_message(
                    f"academic request {index}",
                    prompt=PROMPT,
                    model=MODEL,
                )
                for index in range(100)
            )
        )
        assert all(result.startswith("academic request") for result in results)
        assert set(calls.values()) == {10}, calls

        # Reset the rotation and verify a retriable failure moves to slot 2.
        gemini._POOL_NEXT_INDEX = 0
        gemini._POOL_COOLDOWN_UNTIL.clear()
        attempted = []

        def fake_failover(key, model, message, prompt, images, request_timeout=None):
            attempted.append(key)
            if key == "fake-key-1":
                raise gemini.GeminiRequestError("quota", status=429)
            return "#SKIP"

        gemini._generate_sync = fake_failover
        result = await provider.process_message(
            "non academic advertisement",
            prompt=PROMPT,
            model=MODEL,
        )
        assert result == "#SKIP"
        assert attempted[:2] == ["fake-key-1", "fake-key-2"], attempted
    finally:
        gemini._generate_sync = original_generate

    print("GEMINI_10_KEY_ROUND_ROBIN=OK")
    print("GEMINI_RETRIABLE_FAILOVER=OK")
    print("NETWORK_REQUESTS=0")


if __name__ == "__main__":
    asyncio.run(main())
