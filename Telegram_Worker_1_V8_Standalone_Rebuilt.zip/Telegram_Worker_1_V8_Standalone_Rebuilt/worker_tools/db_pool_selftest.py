#!/usr/bin/env python3
"""Container-side concurrent SQLAlchemy pool regression test."""

import concurrent.futures
import os
import sys
import tempfile
import time
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def main():
    with tempfile.TemporaryDirectory() as directory:
        os.environ["DATABASE_URL"] = f"sqlite:///{directory}/pool-test.db"
        os.environ["DATABASE_POOL_SIZE"] = "10"
        os.environ["DATABASE_MAX_OVERFLOW"] = "20"
        os.environ["DATABASE_POOL_TIMEOUT_SECONDS"] = "5"

        from sqlalchemy import text
        from models.models import get_session, init_db

        engine = init_db()

        def transaction(_index):
            session = get_session()
            try:
                assert session.execute(text("SELECT 1")).scalar_one() == 1
                time.sleep(0.01)
            finally:
                session.close()

        with concurrent.futures.ThreadPoolExecutor(max_workers=30) as executor:
            list(executor.map(transaction, range(120)))

        checked_out = engine.pool.checkedout()
        if checked_out != 0:
            raise AssertionError(f"Leaked SQLAlchemy connections: {checked_out}")

    print("CONCURRENT_DB_OPERATIONS=120")
    print("SQLALCHEMY_CONNECTIONS_LEAKED=0")
    print("DB_POOL_SELFTEST=OK")


if __name__ == "__main__":
    main()
