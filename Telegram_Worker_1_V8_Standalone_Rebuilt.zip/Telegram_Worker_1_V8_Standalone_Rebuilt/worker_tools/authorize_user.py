#!/usr/bin/env python3
import asyncio
import os

from dotenv import load_dotenv
from telethon import TelegramClient

load_dotenv("/app/.env", override=True)

async def main():
    api_id = os.getenv("API_ID", "").strip()
    api_hash = os.getenv("API_HASH", "").strip()
    phone = os.getenv("PHONE_NUMBER", "").strip()

    if not api_id or not api_hash or not phone:
        raise SystemExit("API_ID, API_HASH and PHONE_NUMBER are required")

    client = TelegramClient("/app/sessions/user", int(api_id), api_hash)
    await client.start(phone=phone)
    me = await client.get_me()

    expected = os.getenv("USER_ID", "").strip()
    if expected and expected not in {"CHANGE_ME", "AUTO"} and str(me.id) != expected:
        await client.disconnect()
        raise SystemExit(
            f"USER_ID mismatch: .env={expected}, authenticated={me.id}"
        )

    print(f"AUTHORIZED_USER_ID={me.id}")
    print(f"AUTHORIZED_USERNAME={me.username or ''}")
    await client.disconnect()

asyncio.run(main())
