#!/usr/bin/env python3
"""Validate all ten Gemini key slots without ever displaying a key."""

import argparse
import concurrent.futures
import json
import os
import re
import sys
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from dotenv import load_dotenv

load_dotenv(ROOT / ".env", override=False)

from ai.gemini_provider import _load_api_keys
from filter_policy_v8 import MODEL


def _safe_error(value):
    value = re.sub(r"AIza[0-9A-Za-z_-]{20,}", "<redacted>", str(value))
    value = re.sub(r"(?i)(key=)[^&\s]+", r"\1<redacted>", value)
    return value[:300]


def _model_url(model):
    base = os.getenv(
        "GEMINI_REST_API_BASE",
        "https://generativelanguage.googleapis.com/v1beta",
    ).strip().rstrip("/")
    parsed = urllib.parse.urlparse(base)
    if parsed.scheme not in {"https", "http"} or not parsed.netloc:
        raise ValueError("GEMINI_REST_API_BASE is not a valid HTTP(S) URL")
    return f"{base}/models/{urllib.parse.quote(model, safe='-_.')}"


def _probe_slot(slot, key, url, timeout):
    request = urllib.request.Request(
        url,
        headers={
            "Accept": "application/json",
            "x-goog-api-key": key,
            "User-Agent": "TelegramWorker-V8-Gemini-Probe/1.0",
        },
        method="GET",
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            payload = json.loads(response.read().decode("utf-8", errors="replace"))
        served_name = str(payload.get("name", ""))
        healthy = served_name.endswith(f"/{MODEL}") or served_name == MODEL
        return slot, healthy, "ok" if healthy else "unexpected model metadata"
    except urllib.error.HTTPError as exc:
        try:
            body = exc.read().decode("utf-8", errors="replace")
        except Exception:
            body = ""
        return slot, False, _safe_error(f"HTTP {exc.code}: {body}")
    except Exception as exc:
        return slot, False, _safe_error(f"{type(exc).__name__}: {exc}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--live", action="store_true")
    parser.add_argument("--strict", action="store_true")
    parser.add_argument("--timeout", type=float, default=10.0)
    args = parser.parse_args()

    keys = _load_api_keys()
    if len(keys) != 10 or len(set(keys)) != 10:
        raise SystemExit(f"Expected 10 unique Gemini key slots; found {len(keys)}")

    url = _model_url(MODEL)
    print(f"MODEL={MODEL}")
    print("KEY_SLOTS=10")
    print("KEY_VALUES_PRINTED=NO")

    if not args.live:
        print("OFFLINE_POOL_VALIDATION=OK")
        return

    with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
        results = list(
            executor.map(
                lambda item: _probe_slot(item[0], item[1], url, args.timeout),
                enumerate(keys, 1),
            )
        )

    failures = []
    for slot, healthy, detail in sorted(results):
        print(f"SLOT_{slot}={'OK' if healthy else 'FAILED'}")
        if not healthy:
            failures.append((slot, detail))

    if failures:
        for slot, detail in failures:
            print(f"SLOT_{slot}_ERROR={detail}")
        if args.strict:
            raise SystemExit(1)
    else:
        print("LIVE_GEMINI_10_SLOT_PROBE=OK")


if __name__ == "__main__":
    main()
