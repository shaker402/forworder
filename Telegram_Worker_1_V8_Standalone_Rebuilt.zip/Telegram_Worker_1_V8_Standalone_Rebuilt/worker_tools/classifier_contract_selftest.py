#!/usr/bin/env python3
"""Zero-network V8 Gemini request, classifier, and cache self-test."""

import json
import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import ai.gemini_provider as gemini
from ai.gemini_provider import (
    CLASSIFIER_CONTRACT_V8,
    GeminiRequestError,
    _cache_get,
    _cache_put,
    _classifier_cache_key,
    _classifier_cacheable,
    _classifier_mode,
    _generate_sync,
    _normalize_classifier_result,
)


prompt = CLASSIFIER_CONTRACT_V8 + "\nOutput exactly KEEP or #SKIP"
original = "احد يعرف خصوصي يشرح الجبر؟"

assert _classifier_mode(prompt)
assert not _classifier_mode("ordinary summary prompt")
assert _normalize_classifier_result("KEEP", original) == ("KEEP", original)
assert _normalize_classifier_result("  #skip\n", original) == ("#SKIP", "#SKIP")
assert _normalize_classifier_result("```\nKEEP\n```", original) == ("KEEP", original)

try:
    _normalize_classifier_result("The message is relevant", original)
except GeminiRequestError:
    pass
else:
    raise AssertionError("Malformed classifier output was accepted")

key_a = _classifier_cache_key("model", prompt, "للتواصل +967 777 111 222")
key_b = _classifier_cache_key("model", prompt, "للتواصل +967 733 999 888")
assert key_a == key_b, "Contact redaction must stabilize advertisement cache keys"
user_key_a = _classifier_cache_key("model", prompt, "للطلب@SellerOne")
user_key_b = _classifier_cache_key("model", prompt, "للطلب@SellerTwo")
assert user_key_a == user_key_b, "Username redaction must stabilize cache keys"
assert key_a != _classifier_cache_key("model", prompt + " changed", original)
assert not _classifier_cacheable("خصوصي")
assert _classifier_cacheable(
    "نوفر خدمات بحوث ومشاريع تخرج وواجبات وتقارير وعروض للتواصل واتساب [PHONE]"
)

with tempfile.TemporaryDirectory() as directory:
    os.environ["GEMINI_CLASSIFIER_CACHE"] = "true"
    os.environ["GEMINI_CLASSIFIER_CACHE_PATH"] = os.path.join(directory, "cache.sqlite3")
    _cache_put(key_a, "#SKIP")
    assert _cache_get(key_a) == "#SKIP"


class FakeResponse:
    def __enter__(self):
        return self

    def __exit__(self, _exc_type, _exc_value, _traceback):
        return False

    def read(self):
        return b'{"candidates":[{"content":{"parts":[{"text":"KEEP"}]}}]}'


captured = {}


def fake_urlopen(request, timeout):
    captured["url"] = request.full_url
    captured["payload"] = json.loads(request.data.decode("utf-8"))
    captured["headers"] = {key.lower(): value for key, value in request.header_items()}
    captured["timeout"] = timeout
    return FakeResponse()


original_urlopen = gemini.urllib.request.urlopen
gemini.urllib.request.urlopen = fake_urlopen
try:
    assert _generate_sync(
        "fake-key-never-sent",
        "gemini-3.5-flash-lite",
        original,
        prompt,
        None,
        request_timeout=4,
    ) == "KEEP"
finally:
    gemini.urllib.request.urlopen = original_urlopen

assert captured["url"].endswith(
    "/models/gemini-3.5-flash-lite:generateContent"
)
assert captured["payload"]["systemInstruction"]["parts"][0]["text"] == prompt
assert captured["payload"]["contents"][0]["parts"][0]["text"] == (
    f"<NEW_MESSAGE>\n{original}\n</NEW_MESSAGE>"
)
assert captured["payload"]["generationConfig"]["maxOutputTokens"] == 8
assert "x-goog-api-key" in captured["headers"]
assert captured["timeout"] == 4

print("CLASSIFIER_CONTRACT_V8=OK")
print("CLASSIFIER_CACHE_REDACTION=OK")
print("GEMINI_REST_REQUEST_SHAPE=OK")
print("NO_NETWORK_REQUESTS=YES")
