# Telegram Worker 1 — V8 Standalone Rebuilt

This is one complete, internally consistent TelegramForwarder project. It is
based on the supplied Heavrnl/TelegramForwarder source archive and directly
integrates the V7 worker behavior, the V8 data-driven filter, and the runtime
repairs derived from the supplied logs.

It does **not** clone GitHub at install time, pull
`heavrnl/telegramforwarder:latest`, or mount a separate override tree over a
possibly different application version. Docker builds the source contained in
this directory.

## Processing architecture

1. The authenticated Telegram user client receives a message.
2. A short database lookup eagerly loads and detaches the forwarding rule.
3. The database session is closed before any network wait.
4. The V8 boundary-aware local prefilter rejects non-candidates without AI.
5. A direct local ten-key Gemini pool classifies candidates.
6. Accepted messages use Telegram native forwarding.
7. Compact metadata is sent once as a reply; legacy inline/full modes are used
   only when compact mode is disabled.

## Main repairs

- Fixes the SQLAlchemy QueuePool exhaustion shown in the logs.
- Prevents a database connection from being held during Gemini/Telegram I/O.
- Fixes the enabled-RSS session leak and releases push sessions before network
  notification delivery.
- Releases chat-updater and summary-scheduler sessions before Telegram/Gemini
  requests and sleeps.
- Enables SQLite WAL, busy timeout, foreign keys, bounded shared pooling, and
  deterministic session cleanup.
- Bounds concurrent message pipelines and Gemini work.
- Keeps ten unique Gemini keys in a process-wide round-robin pool with
  per-key cooldown and capped failover.
- Adds a total Gemini deadline in addition to the per-attempt timeout.
- Adds an optional strict live probe for all ten key slots without printing
  their values.
- Keeps the V8 `KEEP/#SKIP` system-instruction contract and hash-only decision
  cache.
- Stops logging full prompts and message/model output at INFO level.
- Rate-limits repeated stale-update warnings instead of flooding Docker logs.
- Uses a Tini-aware health check that verifies the actual `main.py` child
  process and database without incorrectly requiring Worker 1 to be PID 1.
- Makes native metadata strategies mutually exclusive.
- Builds from normalized UTF-8 requirements and the included source tree.

See [REBUILD_REPORT.md](REBUILD_REPORT.md) for the evidence-to-fix mapping and
[V8_DATASET_FINDINGS.md](V8_DATASET_FINDINGS.md) for the corpus analysis.

## Fresh install

On a Debian/Ubuntu VPS:

```bash
unzip Telegram_Worker_1_V8_Standalone_Rebuilt.zip
cd Telegram_Worker_1_V8_Standalone_Rebuilt
chmod +x install_worker1.sh
sudo ./install_worker1.sh
```

The installer:

- verifies the source manifest and ten unique Gemini slots;
- builds this local source;
- runs zero-network policy, classifier, pool, lifecycle, and database tests;
- probes all ten Gemini slots live against `gemini-3.5-flash-lite`;
- authorizes the Telegram user account;
- discovers the exact native-forward destination;
- binds visible groups/channels and applies the V8 policy;
- waits for a stable healthy container and verifies the live database.

Set `SKIP_GEMINI_LIVE_PROBE=true` only if the host intentionally cannot reach
Google during installation. Set `PRESERVE_EXISTING_ENV=false` to replace an
existing installation's `.env` with the bundled one; otherwise upgrades retain
the installed `.env`, database, sessions, and runtime data.

Default install path: `/opt/TelegramForwarder-worker1`  
Container: `telegram-forwarder-worker1`

## Direct Docker operation

```bash
docker compose build --pull
docker compose up -d
docker compose ps
docker compose logs -f --tail=100 telegram-forwarder
```

The interactive authorization and rule-configuration steps are still required
on a fresh host, so the installer is recommended.

## Validation commands

Zero-network:

```bash
python worker_tools/prefilter_recall_selftest.py
python worker_tools/classifier_contract_selftest.py
python worker_tools/gemini_pool_selftest.py
python worker_tools/static_lifecycle_selftest.py
python worker_tools/evaluate_gemini_filter.py --validate-only
```

Inside the built container:

```bash
docker compose run --rm -T --no-deps telegram-forwarder \
  python /app/worker_tools/db_pool_selftest.py

docker compose run --rm -T --no-deps telegram-forwarder \
  python /app/worker_tools/probe_gemini_pool.py --live --strict
```

Optional 64-case live classifier benchmark:

```bash
docker compose exec -T telegram-forwarder \
  python /app/worker_tools/evaluate_gemini_filter.py \
  --output /app/logs/gemini_v8_regression_report.json
```

## Configuration

The supplied `.env` is retained in this bundle as requested. The code never
prints key values. Do not publish the ZIP or `.env` to a public repository.

Important defaults:

| Setting | Default | Purpose |
|---|---:|---|
| `GEMINI_MAX_PARALLEL_REQUESTS` | 10 | Maximum active Gemini HTTP calls |
| `GEMINI_MAX_KEY_ATTEMPTS` | 4 | Maximum key slots tried for one message |
| `GEMINI_REQUEST_TIMEOUT_SECONDS` | 15 | Per-attempt network timeout |
| `GEMINI_TOTAL_TIMEOUT_SECONDS` | 25 | Total per-message Gemini budget |
| `WORKER_MAX_CONCURRENT_MESSAGES` | 20 | Maximum active message pipelines |
| `DATABASE_POOL_SIZE` | 10 | Normal SQLAlchemy connections |
| `DATABASE_MAX_OVERFLOW` | 20 | Short burst capacity |
| `GEMINI_FAIL_OPEN` | true | Preserve a local match during total AI outage |

`gemini-3.5-flash-lite` and the REST `generateContent` request used here are
documented by Google:

- https://ai.google.dev/gemini-api/docs/models/gemini-3.5-flash-lite
- https://ai.google.dev/api/generate-content

The original upstream documentation is preserved as
[UPSTREAM_README.md](UPSTREAM_README.md), and the original GPL license remains
in [LICENSE](LICENSE).
