import logging
import os

from telethon.tl import types

from models.models import Chat, ForwardRule, Keyword


logger = logging.getLogger("auto_bind_new_chat")


def auto_bind_enabled():
    return (
        os.getenv("AUTO_BIND_NEW_CHATS", "false")
        .strip()
        .lower()
        in ("1", "true", "yes", "on")
    )


def is_group_or_channel(event):
    return isinstance(
        event.chat,
        (
            types.Chat,
            types.Channel,
        ),
    )


def get_chat_name(chat):
    if chat is None:
        return "Unknown Chat"

    title = getattr(chat, "title", None)

    if title:
        return title

    first_name = getattr(
        chat,
        "first_name",
        None,
    )

    last_name = getattr(
        chat,
        "last_name",
        None,
    )

    name = " ".join(
        x
        for x in [
            first_name,
            last_name,
        ]
        if x
    ).strip()

    if name:
        return name

    return f"Chat {getattr(chat, 'id', 'Unknown')}"


def ensure_auto_rule(
    session,
    event,
    source_chat,
    chat_id,
):
    """
    Automatically bind a previously unknown group/channel
    to AUTO_BIND_TARGET_ID.

    The new rule clones all scalar ForwardRule settings from
    an existing configured rule for the target, and copies
    its whitelist/blacklist keywords.
    """

    if not auto_bind_enabled():
        return source_chat

    # Never auto-bind private user conversations.
    if not is_group_or_channel(event):
        return source_chat

    target_telegram_id = (
        os.getenv("AUTO_BIND_TARGET_ID", "")
        .strip()
    )

    if not target_telegram_id:
        logger.error(
            "AUTO_BIND_NEW_CHATS is enabled but "
            "AUTO_BIND_TARGET_ID is missing."
        )
        return source_chat

    # --------------------------------------------------------
    # FIND TARGET
    # --------------------------------------------------------

    target_chat = (
        session.query(Chat)
        .filter(
            Chat.telegram_chat_id
            == target_telegram_id
        )
        .first()
    )

    if not target_chat:
        logger.error(
            "Auto-bind target is not present in database: %s",
            target_telegram_id,
        )
        return source_chat

    # --------------------------------------------------------
    # CREATE SOURCE CHAT IF NEW
    # --------------------------------------------------------

    if not source_chat:
        # message_listener resolves event.get_chat() before opening a database
        # session.  Use that cached entity here so auto-binding never performs
        # Telegram network I/O while a SQLAlchemy connection is checked out.
        chat_name = get_chat_name(getattr(event, "chat", None))
        if chat_name == "Unknown Chat":
            chat_name = f"Chat {chat_id}"

        source_chat = Chat(
            telegram_chat_id=str(chat_id),
            name=chat_name,
        )

        session.add(source_chat)
        session.flush()

        logger.info(
            "AUTO-BIND discovered new chat: %s (%s)",
            chat_name,
            chat_id,
        )

    # --------------------------------------------------------
    # CHECK WHETHER TARGET RULE ALREADY EXISTS
    # --------------------------------------------------------

    existing_rule = (
        session.query(ForwardRule)
        .filter(
            ForwardRule.source_chat_id
            == source_chat.id,
            ForwardRule.target_chat_id
            == target_chat.id,
        )
        .first()
    )

    if existing_rule:
        return source_chat

    # --------------------------------------------------------
    # FIND AN EXISTING CONFIGURED RULE AS TEMPLATE
    # --------------------------------------------------------

    template_rule = (
        session.query(ForwardRule)
        .filter(
            ForwardRule.target_chat_id
            == target_chat.id,
            ForwardRule.enable_rule == True,
        )
        .order_by(
            ForwardRule.id
        )
        .first()
    )

    if not template_rule:
        logger.error(
            "Cannot auto-bind %s: no configured "
            "template rule exists for target %s",
            chat_id,
            target_telegram_id,
        )
        return source_chat

    # --------------------------------------------------------
    # CREATE NEW RULE
    # --------------------------------------------------------

    new_rule = ForwardRule(
        source_chat_id=source_chat.id,
        target_chat_id=target_chat.id,
    )

    # Clone every normal ForwardRule database field.
    #
    # This automatically copies:
    # - enable_rule
    # - forward_mode
    # - add_mode
    # - use_bot
    # - handle_mode
    # - Gemini settings
    # - AI prompt
    # - post-AI filtering
    # - sender/link/time settings
    # - templates
    # - reverse settings
    # - media settings
    # - etc.
    #
    # Primary/source/target IDs must NOT be copied.
    excluded_columns = {
        "id",
        "source_chat_id",
        "target_chat_id",
    }

    for column in ForwardRule.__table__.columns:
        column_name = column.name

        if column_name in excluded_columns:
            continue

        setattr(
            new_rule,
            column_name,
            getattr(
                template_rule,
                column_name,
            ),
        )

    session.add(new_rule)
    session.flush()

    # --------------------------------------------------------
    # COPY ALL KEYWORDS
    # --------------------------------------------------------

    template_keywords = (
        session.query(Keyword)
        .filter(
            Keyword.rule_id
            == template_rule.id
        )
        .all()
    )

    for keyword in template_keywords:
        session.add(
            Keyword(
                rule_id=new_rule.id,
                keyword=keyword.keyword,
                is_regex=keyword.is_regex,
                is_blacklist=keyword.is_blacklist,
            )
        )

    session.commit()

    whitelist_count = sum(
        1
        for keyword in template_keywords
        if not keyword.is_blacklist
    )

    blacklist_count = sum(
        1
        for keyword in template_keywords
        if keyword.is_blacklist
    )

    logger.info(
        "AUTO-BIND completed: "
        "%s (%s) -> %s | "
        "rule=%s | whitelist=%s | blacklist=%s",
        source_chat.name,
        chat_id,
        target_chat.name,
        new_rule.id,
        whitelist_count,
        blacklist_count,
    )

    return source_chat
