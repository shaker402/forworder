# V8 Rebuild Report

## Inputs and baseline

| Input | SHA-256 |
|---|---|
| Supplied TelegramForwarder source ZIP | `794b5b43ce460d4c21ea3b721cccf7b385f967cf60123ad32e168b6549bdb2cb` |
| Supplied V7 standalone ZIP | `5ddf0af06e74b74c24da5b6e524c756ec907142c5db162ee7370a76e58bebd0e` |
| Supplied V8 patch ZIP | `5d5d17cba43ef269225f5c0c727d93f106675c0f4086f48b3e047d425c412dd5` |
| Supplied log text | `b97ee229b0d51c56f6ea90eb6aaeca2223980f643954d01ff4ec7bba6574c591` |
| Supplied Shaker corpus ZIP | `a804b77c03618e9cc1d7d4ac671c597ec0f1c91a017762705287e002f88bfe08` |
| Supplied dataset-tools ZIP | `8881eaf46d59c0537cba7d34d3df2562f40d919e798353c31b4316e00d769d1e` |

The GitHub source archive identifies upstream commit
`96093f938f185673a01434e7af3395cd27267b8b`. The rebuilt project keeps the
upstream license and full application topology.

## Log findings and repairs

| Evidence | Root cause | Repair |
|---|---|---|
| `QueuePool limit of size 5 overflow 10 ... timeout 30.00` repeated every 30 seconds | V7 reused one QueuePool but held each message-listener session across the complete async filter chain, including Gemini and Telegram network waits | Eager-load rule relationships, detach them, and close the session before the filter chain starts |
| Failures occur at `message_listener.py` while querying the source chat | New message handlers could not obtain a connection because earlier handlers still owned all 15 pool connections | Short database scope plus 10+20 bounded pool, five-second pool timeout, and pipeline concurrency limit |
| Hundreds of `very old message` / `Too many messages had to be ignored` warnings | Synchronous 30-second pool checkout waits stalled Telethon's event loop during a burst | Remove long checkouts, cap concurrent pipelines, and rate-limit repeated warning variants |
| Gemini processing starts but no completion appears before the database errors resume | AI work was coupled to a checked-out database session; the surrounding runtime became starved before completion | Decouple AI from SQLAlchemy; dedicated total/per-attempt deadlines and ten-key health tools |
| Full 13k+ classifier prompt appears in INFO logs | Upstream AI filter logs complete prompts and outputs | Log only model, lengths, and decision class |
| RSS session only closed when RSS config was absent/disabled | Enabled RSS rule leaked its SQLAlchemy session | Close immediately after reading the RSS configuration |
| Push session remained open while external notifications were sent | Slow push I/O retained a pooled connection | Detach push rows and close before awaits |
| Daily chat updates and summaries retained ORM sessions during Telegram/Gemini calls and sleeps | Long-running maintenance work could consume additional pool slots | Snapshot/eager-load required values, detach, close, then perform network work |
| V7 invokes inline native metadata and compact metadata in the same successful forward path | Independent patches were layered without one selection policy | Compact reply wins; inline or legacy full reply is used only when compact is disabled |
| Installer cloned GitHub and used a floating prebuilt application image | Runtime code could differ from files used to create/test the overrides | Include the complete source and build it locally |
| Compose enables Tini while health logic assumed the Python process was PID 1 | A healthy worker could be marked unhealthy forever | Scan container process command lines for the `main.py` child and separately test the database |

## Gemini ten-slot behavior

- Exactly ten unique values are parsed from `GEMINI_API_KEYS`.
- A process-wide locked round-robin index distributes first attempts.
- One normal message makes one request, not ten duplicate requests.
- Retriable auth/quota/network/server failures cool the failed slot and move to
  another healthy slot, up to the configured attempt cap.
- All active HTTP calls share a ten-request semaphore.
- A total deadline prevents four sequential attempts from creating an
  unbounded backlog.
- Offline tests use fake keys and make zero network requests.
- The live probe checks model access for each slot without showing a key.

## V8 data replay

The supplied 351,061-message corpus replay reproduced the patch result exactly:

| Metric | Result |
|---|---:|
| Original prefilter candidates | 339,936 |
| V8 prefilter candidates | 261,312 |
| Old candidates removed before AI | 79,134 |
| New high-signal candidates added | 510 |
| Estimated AI-call reduction | 23.2791% |

This is a load/cost estimate from an already-filtered historical export, not a
claim of end-to-end recall. The 64-case labeled regression evaluator remains
available for live model measurement.

## Completed validation

- All 103 supplied upstream file paths are present; the integrated project has
  130 non-generated files before its manifest is added.
- Python compile, installer shell syntax, JSON/JSONL parsing, 20 positive and 5
  collision prefilter cases, the 64 labeled-case schema, Gemini REST request
  shape, classifier output contract, cache redaction, ten-slot distribution,
  retriable failover, lifecycle assertions, and log rate limiting passed.
- A pinned SQLAlchemy 2.0.37 run completed 120 concurrent transactions with
  zero checked-out connections afterward.
- The full 351,061-message prefilter result matched the supplied result file
  byte-for-byte.
- Real keys are never printed by the tests. The final installer performs the
  external ten-slot live probe on the deployment host, where Google and the
  Telegram account are reachable.
