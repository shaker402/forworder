#!/usr/bin/env python3
import argparse
import asyncio
import os
import sys

os.chdir("/app")
sys.path.insert(0, "/app")

from dotenv import load_dotenv
from telethon import TelegramClient
from models.models import init_db, get_session, Chat, ForwardRule

load_dotenv("/app/.env")


def normalize_name(s):
    return (s or "").strip().casefold()


def chat_title(dialog):
    return (
        getattr(dialog, "name", None)
        or getattr(dialog.entity, "title", None)
        or getattr(dialog.entity, "first_name", None)
        or f"Chat {dialog.entity.id}"
    )


async def main():
    parser = argparse.ArgumentParser(
        description="Bulk-bind every Telegram group/channel visible to the Heavrnl user account."
    )
    target = parser.add_mutually_exclusive_group(required=True)
    target.add_argument(
        "--target",
        help='Exact destination group/channel title, e.g. "Student Help Monitor"',
    )
    target.add_argument(
        "--target-id",
        type=int,
        help="Destination Telethon/Heavrnl chat ID (the positive ID shown by the Heavrnl group list)",
    )
    parser.add_argument(
        "--apply",
        action="store_true",
        help="Actually write rules. Without this option the script is DRY-RUN only.",
    )
    args = parser.parse_args()

    api_id = os.getenv("API_ID")
    api_hash = os.getenv("API_HASH")
    if not api_id or not api_hash:
        raise SystemExit("ERROR: API_ID/API_HASH are missing from /app/.env")

    client = TelegramClient("/app/sessions/user", int(api_id), api_hash)
    await client.connect()

    try:
        if not await client.is_user_authorized():
            raise SystemExit(
                "ERROR: the Heavrnl user session is not authorized. "
                "Complete Heavrnl's first Telegram login first."
            )

        # archived=None/folder unspecified means all dialog folders are included.
        dialogs = [d async for d in client.iter_dialogs()]

        # Resolve destination exactly, never by substring.
        if args.target_id is not None:
            matches = [d for d in dialogs if int(d.entity.id) == args.target_id]
        else:
            wanted = normalize_name(args.target)
            matches = [d for d in dialogs if normalize_name(chat_title(d)) == wanted]

        if not matches:
            raise SystemExit(
                "ERROR: destination was not found in the logged-in user's Telegram dialogs."
            )

        if len(matches) > 1:
            print("ERROR: multiple destination chats have the same exact title:")
            for d in matches:
                print(f"  {chat_title(d)} -> {d.entity.id}")
            print("Run again using --target-id <ID>.")
            raise SystemExit(2)

        target_dialog = matches[0]
        target_id = int(target_dialog.entity.id)
        target_name = chat_title(target_dialog)

        # Groups + channels only. Private user/bot dialogs are intentionally excluded.
        sources = [
            d for d in dialogs
            if (getattr(d, "is_group", False) or getattr(d, "is_channel", False))
            and int(d.entity.id) != target_id
        ]

        print(f"Destination : {target_name} ({target_id})")
        print(f"Candidates  : {len(sources)} groups/channels")
        print("Private user/bot chats are excluded.")
        print()

        if not args.apply:
            print("DRY RUN — nothing will be changed.")
            for i, d in enumerate(sources, 1):
                print(f"{i:03d}. {chat_title(d)} -> {d.entity.id}")
            print()
            print("If this is correct, run the same command again with --apply.")
            return

        init_db()
        db = get_session()

        created = 0
        existing = 0

        try:
            target_db = db.query(Chat).filter(
                Chat.telegram_chat_id == str(target_id)
            ).first()

            if not target_db:
                target_db = Chat(
                    telegram_chat_id=str(target_id),
                    name=target_name,
                )
                db.add(target_db)
                db.flush()
            else:
                target_db.name = target_name

            first_source_id = None

            for d in sources:
                sid = int(d.entity.id)
                sname = chat_title(d)

                source_db = db.query(Chat).filter(
                    Chat.telegram_chat_id == str(sid)
                ).first()

                if not source_db:
                    source_db = Chat(
                        telegram_chat_id=str(sid),
                        name=sname,
                    )
                    db.add(source_db)
                    db.flush()
                else:
                    source_db.name = sname

                rule = db.query(ForwardRule).filter(
                    ForwardRule.source_chat_id == source_db.id,
                    ForwardRule.target_chat_id == target_db.id,
                ).first()

                if rule:
                    existing += 1
                    print(f"SKIP existing : {sname} ({sid})")
                    continue

                # This intentionally uses Heavrnl's normal ForwardRule defaults,
                # the same way /bind creates a new rule.
                db.add(
                    ForwardRule(
                        source_chat_id=source_db.id,
                        target_chat_id=target_db.id,
                    )
                )
                created += 1
                if first_source_id is None:
                    first_source_id = str(sid)
                print(f"BOUND         : {sname} ({sid})")

            if not target_db.current_add_id and first_source_id:
                target_db.current_add_id = first_source_id

            db.commit()

            print()
            print("DONE")
            print(f"New rules      : {created}")
            print(f"Already existed: {existing}")
            print(f"Destination    : {target_name} ({target_id})")

        except Exception:
            db.rollback()
            raise
        finally:
            db.close()

    finally:
        await client.disconnect()


if __name__ == "__main__":
    asyncio.run(main())
