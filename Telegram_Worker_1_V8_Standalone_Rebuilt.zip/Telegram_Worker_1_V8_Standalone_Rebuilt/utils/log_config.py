"""Central logging configuration for the standalone worker."""

import logging
import os
import re
import threading
import time

from dotenv import load_dotenv


class RepeatedRecordFilter(logging.Filter):
    """Rate-limit identical burst messages while preserving periodic evidence."""

    def __init__(self, window_seconds=60.0):
        super().__init__()
        self.window_seconds = float(window_seconds)
        self._lock = threading.Lock()
        self._records = {}

    def filter(self, record):
        rendered = record.getMessage()
        if record.name == "telethon.network.mtprotostate":
            rendered = re.sub(r"\bID \d+\b", "ID <message>", rendered)
        key = (record.name, record.levelno, rendered)
        now = time.monotonic()
        with self._lock:
            last, suppressed = self._records.get(key, (0.0, 0))
            if now - last < self.window_seconds:
                self._records[key] = (last, suppressed + 1)
                return False
            self._records[key] = (now, 0)

        if suppressed:
            record.msg = f"{record.getMessage()} (suppressed {suppressed} repeats)"
            record.args = ()
        return True


def setup_logging():
    """Configure one stdout handler suitable for Docker log collection."""
    load_dotenv()

    level_name = os.getenv("LOG_LEVEL", "INFO").strip().upper()
    level = getattr(logging, level_name, logging.INFO)
    root_logger = logging.getLogger()
    root_logger.setLevel(level)

    # main.py can be imported by helper paths; do not stack duplicate handlers.
    for handler in list(root_logger.handlers):
        if getattr(handler, "_telegram_worker_handler", False):
            root_logger.removeHandler(handler)

    console_handler = logging.StreamHandler()
    console_handler._telegram_worker_handler = True
    console_handler.setLevel(level)
    console_handler.addFilter(
        RepeatedRecordFilter(
            os.getenv("LOG_REPEAT_WINDOW_SECONDS", "60")
        )
    )
    console_handler.setFormatter(
        logging.Formatter(
            "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        )
    )
    root_logger.addHandler(console_handler)

    # Telethon can emit one warning per stale update after an event-loop stall.
    # Preserve the first warning via the filter without flooding Docker logs.
    logging.getLogger("telethon.network.mtprotostate").setLevel(logging.WARNING)
    logging.getLogger("telethon.network.mtprotosender").setLevel(logging.WARNING)
    logging.getLogger("sqlalchemy.engine").setLevel(logging.WARNING)
    return root_logger
