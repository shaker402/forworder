"""
Runtime holder for Heavrnl's already-authenticated Telegram USER client.

The normal Bot-mode filter chain still performs:
    keyword filtering
    -> AI
    -> information processing

Only the final accepted-message delivery uses the USER client so
Telegram can create a genuine "Forwarded from" header.
"""

_user_client = None


def set_user_client(client):
    global _user_client
    _user_client = client


def get_user_client():
    return _user_client
