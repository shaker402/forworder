from typing import Optional, List, Dict
from .base import BaseAIProvider
from .openai_base_provider import OpenAIBaseProvider
import asyncio
import json
import logging
import os
import re
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

logger = logging.getLogger(__name__)

# Marker used by the installer/verification logic.
MULTI_KEY_GEMINI_POOL = True


class GeminiOpenAIProvider(OpenAIBaseProvider):
    """Existing OpenAI-compatible Gemini path (kept for compatibility)."""

    def __init__(self):
        super().__init__(
            env_prefix="GEMINI",
            default_model="gemini-pro",
            default_api_base="",
        )


class GeminiRequestError(RuntimeError):
    def __init__(self, message, status=None, body="", retry_after=None):
        super().__init__(message)
        self.status = status
        self.body = body or ""
        self.retry_after = retry_after


# Heavrnl's get_ai_provider() creates a fresh GeminiProvider for each AI call.
# Pool state therefore lives at module scope so every provider instance shares
# the same round-robin index and cooldown state.
_POOL_LOCK = threading.Lock()
_POOL_NEXT_INDEX = 0
_POOL_COOLDOWN_UNTIL = {}
_POOL_FAILURES = {}
_HTTP_SEMAPHORE = None
_HTTP_SEMAPHORE_SIZE = None


def _load_api_keys():
    """Return a de-duplicated key pool; support the old single-key setting."""
    raw = os.getenv("GEMINI_API_KEYS", "").strip()

    if raw:
        normalized = raw.replace(";", ",").replace("\n", ",").replace("\r", ",")
        candidates = []
        for chunk in normalized.split(","):
            candidates.extend(chunk.split())
    else:
        legacy = os.getenv("GEMINI_API_KEY", "").strip()
        candidates = [legacy] if legacy else []

    keys = []
    seen = set()
    for key in candidates:
        key = key.strip()
        if key and key not in seen:
            seen.add(key)
            keys.append(key)

    return keys


def _env_int(name, default, minimum=None):
    try:
        value = int(os.getenv(name, str(default)).strip())
    except Exception:
        value = int(default)
    if minimum is not None:
        value = max(int(minimum), value)
    return value


def _env_float(name, default, minimum=None):
    try:
        value = float(os.getenv(name, str(default)).strip())
    except Exception:
        value = float(default)
    if minimum is not None:
        value = max(float(minimum), value)
    return value


def _fail_open_enabled():
    return os.getenv("GEMINI_FAIL_OPEN", "true").strip().lower() in {
        "1", "true", "yes", "on"
    }


def _get_http_semaphore():
    global _HTTP_SEMAPHORE, _HTTP_SEMAPHORE_SIZE
    size = _env_int("GEMINI_MAX_PARALLEL_REQUESTS", 10, 1)

    with _POOL_LOCK:
        if _HTTP_SEMAPHORE is None or _HTTP_SEMAPHORE_SIZE != size:
            _HTTP_SEMAPHORE = threading.BoundedSemaphore(size)
            _HTTP_SEMAPHORE_SIZE = size
        return _HTTP_SEMAPHORE


def _candidate_indices(keys, max_attempts):
    """
    Return healthy key slots in round-robin order.

    If every key is currently cooling down, return an empty list. This avoids
    hammering a known-exhausted 10-key pool for every incoming Telegram message.
    """
    global _POOL_NEXT_INDEX

    if not keys:
        return []

    now = time.monotonic()
    total = len(keys)

    with _POOL_LOCK:
        start = _POOL_NEXT_INDEX % total
        _POOL_NEXT_INDEX = (_POOL_NEXT_INDEX + 1) % total

        order = [(start + offset) % total for offset in range(total)]
        healthy = [
            index
            for index in order
            if _POOL_COOLDOWN_UNTIL.get(keys[index], 0.0) <= now
        ]
        return healthy[:max_attempts]


def _soonest_cooldown_remaining(keys):
    now = time.monotonic()
    with _POOL_LOCK:
        remaining = [
            max(0.0, _POOL_COOLDOWN_UNTIL.get(key, 0.0) - now)
            for key in keys
        ]
    return min(remaining) if remaining else 0.0


def _mark_failure(key, seconds):
    with _POOL_LOCK:
        _POOL_FAILURES[key] = _POOL_FAILURES.get(key, 0) + 1
        _POOL_COOLDOWN_UNTIL[key] = max(
            _POOL_COOLDOWN_UNTIL.get(key, 0.0),
            time.monotonic() + max(0.0, seconds),
        )


def _mark_success(key):
    with _POOL_LOCK:
        _POOL_FAILURES[key] = 0
        _POOL_COOLDOWN_UNTIL.pop(key, None)


def _extract_retry_after(headers, body):
    if headers:
        try:
            value = headers.get("Retry-After")
            if value:
                return max(0.0, float(value))
        except Exception:
            pass

    try:
        payload = json.loads(body or "{}")
        details = payload.get("error", {}).get("details", [])
        for detail in details:
            retry = detail.get("retryDelay") or detail.get("retry_delay")
            if not retry:
                continue
            if isinstance(retry, str) and retry.endswith("s"):
                return max(0.0, float(retry[:-1]))
            if isinstance(retry, dict):
                return max(0.0, float(retry.get("seconds", 0)))
    except Exception:
        pass

    # Some SDK/backend error text includes "retry in 4.28s".
    match = re.search(r"retry\s+in\s+([0-9.]+)s", body or "", re.I)
    if match:
        try:
            return max(0.0, float(match.group(1)))
        except Exception:
            pass

    return None


def _is_key_specific_bad_request(error):
    if error.status != 400:
        return False
    text = (error.body or "").lower()
    markers = (
        "api_key_invalid",
        "api key not valid",
        "api key invalid",
        "api key expired",
        "api_key_service_blocked",
    )
    return any(marker in text for marker in markers)


def _is_retriable_on_another_key(error):
    if error.status in (401, 403, 408, 429, 500, 502, 503, 504):
        return True
    if error.status is None:
        return True
    return _is_key_specific_bad_request(error)


def _cooldown_seconds_for(error):
    if error.status == 429:
        configured = _env_float("GEMINI_KEY_COOLDOWN_SECONDS", 60, 1)
        if error.retry_after is not None:
            return max(configured, error.retry_after)
        return configured

    if error.status in (400, 401, 403):
        return _env_float("GEMINI_KEY_AUTH_COOLDOWN_SECONDS", 1800, 60)

    return _env_float("GEMINI_KEY_ERROR_COOLDOWN_SECONDS", 15, 1)


def _response_text(payload):
    texts = []
    for candidate in payload.get("candidates", []) or []:
        content = candidate.get("content") or {}
        for part in content.get("parts", []) or []:
            text = part.get("text")
            if text:
                texts.append(text)

    if texts:
        return "".join(texts)

    feedback = payload.get("promptFeedback") or {}
    block_reason = feedback.get("blockReason") or feedback.get("block_reason")
    if block_reason:
        raise GeminiRequestError(
            f"Gemini returned no text (prompt blocked: {block_reason})",
            status=200,
            body=json.dumps(payload, ensure_ascii=False)[:2000],
        )

    raise GeminiRequestError(
        "Gemini returned an empty response",
        status=200,
        body=json.dumps(payload, ensure_ascii=False)[:2000],
    )


def _generate_sync(api_key, model_name, user_message, images):
    parts = [{"text": user_message}]

    if images:
        for image in images:
            try:
                mime_type = image["mime_type"]
                data = image["data"]
            except Exception as exc:
                raise GeminiRequestError(
                    f"Invalid Gemini image payload: {exc}",
                    status=400,
                ) from exc

            parts.append(
                {
                    "inlineData": {
                        "mimeType": mime_type,
                        "data": data,
                    }
                }
            )

    payload = {
        "contents": [
            {
                "role": "user",
                "parts": parts,
            }
        ],
        # Deterministic classifier: faster, repeatable KEEP/#SKIP decisions.
        "generationConfig": {
            "temperature": 0.0,
            "topP": 0.1,
            "candidateCount": 1,
        },
        # Preserve the behavior of the project's original Gemini provider.
        "safetySettings": [
            {"category": "HARM_CATEGORY_HARASSMENT", "threshold": "BLOCK_NONE"},
            {"category": "HARM_CATEGORY_HATE_SPEECH", "threshold": "BLOCK_NONE"},
            {"category": "HARM_CATEGORY_SEXUALLY_EXPLICIT", "threshold": "BLOCK_NONE"},
            {"category": "HARM_CATEGORY_DANGEROUS_CONTENT", "threshold": "BLOCK_NONE"},
        ],
    }

    base = os.getenv(
        "GEMINI_REST_API_BASE",
        "https://generativelanguage.googleapis.com/v1beta",
    ).strip().rstrip("/")

    model_path = urllib.parse.quote(model_name, safe="-_.")
    url = f"{base}/models/{model_path}:generateContent"

    request = urllib.request.Request(
        url,
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers={
            "Content-Type": "application/json; charset=utf-8",
            "Accept": "application/json",
            "x-goog-api-key": api_key,
            "User-Agent": "Heavrnl-TelegramForwarder-GeminiPool/2.0",
        },
        method="POST",
    )

    timeout = _env_float("GEMINI_REQUEST_TIMEOUT_SECONDS", 45, 5)
    semaphore = _get_http_semaphore()

    try:
        with semaphore:
            with urllib.request.urlopen(request, timeout=timeout) as response:
                raw = response.read().decode("utf-8", errors="replace")
    except urllib.error.HTTPError as exc:
        try:
            body = exc.read().decode("utf-8", errors="replace")
        except Exception:
            body = ""
        retry_after = _extract_retry_after(exc.headers, body)
        raise GeminiRequestError(
            f"Gemini HTTP {exc.code}",
            status=exc.code,
            body=body,
            retry_after=retry_after,
        ) from None
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        reason = getattr(exc, "reason", None) or str(exc)
        raise GeminiRequestError(
            f"Gemini network error: {reason}",
            status=None,
        ) from None

    try:
        decoded = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise GeminiRequestError(
            f"Gemini returned invalid JSON: {exc}",
            status=200,
            body=raw[:2000],
        ) from None

    if isinstance(decoded, dict) and decoded.get("error"):
        error = decoded["error"]
        raise GeminiRequestError(
            f"Gemini API error: {error.get('message', 'unknown error')}",
            status=error.get("code"),
            body=raw[:2000],
        )

    return _response_text(decoded)


class GeminiProvider(BaseAIProvider):
    def __init__(self):
        self.model_name = None
        self.provider = None
        self.api_keys = []

    async def initialize(self, **kwargs):
        api_base = os.getenv("GEMINI_API_BASE", "").strip()

        if api_base:
            logger.info(
                "Detected GEMINI_API_BASE; using existing OpenAI-compatible "
                "Gemini provider (multi-key pool disabled for that custom base)."
            )
            self.provider = GeminiOpenAIProvider()
            await self.provider.initialize(**kwargs)
            return

        self.api_keys = _load_api_keys()
        if not self.api_keys:
            raise ValueError(
                "Neither GEMINI_API_KEYS nor GEMINI_API_KEY is configured"
            )

        self.model_name = kwargs.get("model") or self.model_name or "gemini-pro"

        logger.debug(
            "Initialized Gemini multi-key pool: model=%s, keys=%d, max_parallel=%d",
            self.model_name,
            len(self.api_keys),
            _env_int("GEMINI_MAX_PARALLEL_REQUESTS", 10, 1),
        )

    async def process_message(
        self,
        message: str,
        prompt: Optional[str] = None,
        images: Optional[List[Dict[str, str]]] = None,
        **kwargs,
    ) -> str:
        if self.provider is None and not self.api_keys:
            await self.initialize(**kwargs)

        if self.provider:
            return await self.provider.process_message(
                message,
                prompt,
                images,
                **kwargs,
            )

        if not self.model_name:
            self.model_name = kwargs.get("model") or "gemini-pro"

        user_message = f"{prompt}\n\n{message}" if prompt else message

        total = len(self.api_keys)
        max_attempts = min(
            total,
            _env_int("GEMINI_MAX_KEY_ATTEMPTS", total, 1),
        )

        candidates = _candidate_indices(self.api_keys, max_attempts)
        if not candidates:
            remaining = _soonest_cooldown_remaining(self.api_keys)
            if _fail_open_enabled():
                logger.error(
                    "All %d Gemini keys are cooling down (next probe %.1fs); "
                    "GEMINI_FAIL_OPEN=true, preserving keyword-matched message.",
                    total, remaining,
                )
                return message
            raise GeminiRequestError(
                f"All {total} Gemini API keys are cooling down; "
                f"next probe in approximately {remaining:.1f}s"
            )

        last_error = None

        for attempt_number, key_index in enumerate(candidates, start=1):
            api_key = self.api_keys[key_index]
            slot = key_index + 1

            logger.debug(
                "Gemini request: model=%s, key_slot=%d/%d, attempt=%d/%d",
                self.model_name,
                slot,
                total,
                attempt_number,
                len(candidates),
            )

            try:
                result = await asyncio.to_thread(
                    _generate_sync,
                    api_key,
                    self.model_name,
                    user_message,
                    images,
                )
            except GeminiRequestError as exc:
                last_error = exc

                if not _is_retriable_on_another_key(exc):
                    logger.error(
                        "Gemini non-retriable failure: status=%s, "
                        "key_slot=%d/%d, error=%s",
                        exc.status,
                        slot,
                        total,
                        str(exc),
                    )
                    if _fail_open_enabled():
                        logger.warning(
                            "GEMINI_FAIL_OPEN=true: preserving keyword-matched message."
                        )
                        return message
                    raise

                cooldown = _cooldown_seconds_for(exc)
                _mark_failure(api_key, cooldown)

                logger.warning(
                    "Gemini key_slot=%d/%d failed: status=%s; cooldown=%.1fs; "
                    "trying another healthy key.",
                    slot,
                    total,
                    exc.status,
                    cooldown,
                )
                continue

            _mark_success(api_key)
            logger.debug(
                "Gemini request succeeded with key_slot=%d/%d",
                slot,
                total,
            )
            return result

        if last_error is not None:
            if _fail_open_enabled():
                logger.error(
                    "All attempted Gemini keys failed; GEMINI_FAIL_OPEN=true, "
                    "preserving keyword-matched message. Last error: %s",
                    last_error,
                )
                return message
            raise last_error

        if _fail_open_enabled():
            logger.error(
                "No Gemini API key was available; GEMINI_FAIL_OPEN=true, "
                "preserving keyword-matched message."
            )
            return message
        raise GeminiRequestError("No Gemini API key was available")
