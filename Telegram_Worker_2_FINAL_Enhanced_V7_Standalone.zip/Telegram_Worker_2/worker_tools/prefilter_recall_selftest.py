#!/usr/bin/env python3
import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
source = (ROOT / "bulk_configure_student_filter.py").read_text(encoding="utf-8")
module = ast.parse(source)
WHITELIST = None
for node in module.body:
    if isinstance(node, ast.Assign):
        if any(isinstance(t, ast.Name) and t.id == "WHITELIST" for t in node.targets):
            try:
                WHITELIST = ast.literal_eval(node.value)
            except Exception:
                pass
            if isinstance(WHITELIST, list):
                break
if not isinstance(WHITELIST, list):
    raise SystemExit("ERROR: could not read literal WHITELIST from bulk_configure_student_filter.py")

WANTED = ['يااخوان انا اختباري بعد اسبوعين ولاادري وش اذاكر احد عنده شي معين يدلني عليه وشكرًا', 'الي جابوا أ+ بالفيز كانوا مع مين؟ او اكثر خصوصي ممتاز', 'في احد عنده حلول كتاب الكتابة الاكاديميه؟', 'تكفون اللي قد اختبروا قدرات ودرجتهم مرتفعه يساعدوني وش اذاكر', 'السلام عليكم في احد تخصصه علوم حاسب؟', 'نقطه رقم ٦ ما فهمتها الله يرضى عليكم احد يشرحه', 'أبي خصوصي تنظيم كويس', 'تعرفون برامج نسجل فيها المحاضرات ثم نقدر نفرغ الكلام المسجل؟', 'السلام عليكم احد يعرف لكانفا ضروري احتاج احد فاهم فيه', 'احد يعرف موقع ولا بوت يترجم السلايدات', 'احتاج احد يشرح شبكات ويسوي واجب', 'اختباري بعد 20 يوم شسويييي اذاكر بنوك منووو', 'ابي رقم الخصوصيين اسراء وحافظ', 'السلام عليكم ابي مصادر تدريب للكمي', 'احد يعرف منحة مفتوحة للماجستير؟', 'ابحث عن زميل امن سيبراني يشارك معي في بحث']

def matches(text):
    low = text.casefold()
    return [kw for kw in WHITELIST if str(kw).casefold() in low]

missing=[]
for msg in WANTED:
    hit=matches(msg)
    if not hit:
        missing.append(msg)

print("LOCAL_PREFILTER_TERMS=", len(WHITELIST))
print("IMPORTANT_SELFTEST_MESSAGES=", len(WANTED))
print("IMPORTANT_MESSAGES_MATCHING_PREFILTER=", len(WANTED)-len(missing))
if missing:
    print("ERROR: important examples that would be lost before AI:")
    for m in missing:
        print(" -", m)
    raise SystemExit(1)
print("PREFILTER_RECALL_SELFTEST=OK")
