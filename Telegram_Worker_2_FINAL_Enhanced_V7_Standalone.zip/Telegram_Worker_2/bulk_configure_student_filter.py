#!/usr/bin/env python3
"""
Bulk-configure all Heavrnl forwarding rules targeting one destination.

FINAL HIGH-RECALL + LOW-LATENCY GOAL:
Forward ONLY messages where a student/user is genuinely ASKING FOR
help or a service related to one of the exact whitelist keywords.

This version:
- REMOVES all old whitelist/blacklist/regex keyword rows.
- Uses an expanded high-recall local whitelist BEFORE Gemini.
- Keeps #SKIP as the AI rejection blacklist marker.
- Rejects sellers, ads, promotions, and ordinary keyword mentions.
- Keeps Bot forwarding.
- Keeps Gemini AI.
- Keeps sender/link/time attribution.
- Does NOT modify API_ID, API_HASH, BOT_TOKEN, GEMINI_API_KEY(S),
  PHONE_NUMBER, USER_ID, or other .env secrets.
"""

import argparse
import json
import os
import sys

os.chdir("/app")
sys.path.insert(0, "/app")

from dotenv import load_dotenv

load_dotenv("/app/.env")

from models.models import get_session, Chat, ForwardRule, Keyword
from enums.enums import ForwardMode, AddMode, HandleMode


MODEL = "gemini-3.5-flash-lite"


# ============================================================
# STRICT AI PROMPT
# ============================================================

PROMPT = 'You are a high-recall, high-precision semantic filter for NEW Telegram messages from student, university, academic, technical, programming, engineering and cybersecurity communities.\n\nPIPELINE FACT:\nA LOCAL keyword whitelist already matched the NEW message BEFORE this Gemini call. The keyword match is only a cheap prefilter. Judge the complete meaning and intent of the NEW message.\n\nPRIMARY GOAL:\nKEEP genuine REQUESTERS who are seeking academic/educational help, a tutor/specialist/experienced person, study or exam guidance, academic material/resources, academic software/tools, scholarship/application help, a research/project collaborator, or help completing academic work.\n\nRECALL PRIORITY:\nDo not miss an obvious academic request because it is short, colloquial, misspelled, indirect, asks for a recommendation, asks for a person with experience, or does not literally say "help me".\n\n======================== KEEP ========================\n\nKEEP when the NEW message itself is ASKING / SEEKING / LOOKING FOR at least one of these:\n\n1) TUTOR / PERSON / RECOMMENDATION / CONTACT\n- private tutor, teacher, instructor, specialist, knowledgeable person;\n- experienced student/graduate who can answer an academic/course question;\n- recommendation for the best tutor/teacher/specialist;\n- tutor phone number/contact;\n- tutoring/study/discussion group;\n- asking who explained/taught a subject well.\n\nKEEP examples:\n"من أفضل خصوصي انجليزي"\n"ابي أفضل خصوصي رياضيات"\n"مين افضل مدرس عربي"\n"أحد عنده رقم خصوصي ممتاز"\n"ابي رقم الخصوصيين اسراء وحافظ"\n"ابي مختص في قواعد البيانات"\n"أحد يعرف خصوصين في امن المعلومات"\n"وش افضل خصوصي للمادة الفيز اضمن معه A+"\n"الي جابوا أ+ بالفيز كانوا مع مين؟ او اكثر خصوصي ممتاز"\n"السلام عليكم في احد تخصصه علوم حاسب؟"\n"في احد تخصصه تقنية معلومات وخريج/ه؟؟"\n"احد قد درس عند سلوى البلوشي قران ؟"\n\n2) DIRECT ACADEMIC HELP / EXPLANATION / COURSEWORK\nKEEP requests for explanation, solving, reviewing, teaching, or assistance with:\n- homework, assignments, activities, coursework;\n- projects / graduation projects;\n- research, thesis/dissertation, academic report/writing;\n- presentation, PowerPoint, poster;\n- programming, Java, Python, web/software, networking, cybersecurity, information security, databases, algorithms/data structures or similar academic technical work.\n\nKEEP examples:\n"نقطه رقم ٦ ما فهمتها الله يرضى عليكم احد يشرحه"\n"احتاج احد يشرح شبكات ويسوي واجب"\n"احد يساعدني في واجب بايثون"\n"مين يساعدني بالمشروع"\n"احتاج احد يساعدني في بحث"\n"ابي حد يساعدني في الرسالة"\n"مين يسوي برزنتيشن"\n"احد فاهم في قواعد البيانات يساعدني"\n\n3) EXAM / STUDY GUIDANCE / MATERIAL / SOLUTIONS\nKEEP requests asking what/how to study or seeking solutions, question banks, تجميعات, notes, summaries, files, sources, revision material, exam preparation, or course/book exercise solutions.\n\nKEEP examples:\n"يااخوان انا اختباري بعد اسبوعين ولاادري وش اذاكر احد عنده شي معين يدلني عليه وشكرًا"\n"تكفون اللي قد اختبروا قدرات ودرجتهم مرتفعه يساعدوني وش اذاكر"\n"اختباري بعد 20 يوم شسويييي اذاكر بنوك منووو"\n"في احد عنده حلول كتاب الكتابة الاكاديميه؟"\n"السلام عليكم ابي مصادر تدريب للكمي"\n"احد عنده ملفات او تجميعات للميد"\n"مين يراجع معي للاختبار"\n"ابي خصوصي للميد"\n"مين افضل مدرس للفاينل"\n\nKEEP a question about the academic CONTENT/FORMAT of a test, for example:\n"السلام عليكم عندكم فكره عن اختبار التحويل حق الكليه عباره عن ايش؟ يلي يعرف ضروري احتاج رد"\n\n4) ACADEMIC SOFTWARE / TOOL / DIGITAL STUDY HELP\nKEEP when the sender seeks a tool/app/bot/site or knowledgeable person specifically for an academic task.\n\nKEEP examples:\n"تعرفون برامج نسجل فيها المحاضرات ثم نقدر نفرغ الكلام المسجل؟"\n"السلام عليكم احد يعرف لكانفا ضروري احتاج احد فاهم فيه"\n"احد يعرف موقع ولا بوت يترجم السلايدات"\n"ابي برنامج يلخص المحاضرات"\n"احد يعرف اداة تسوي مراجع للبحث"\n\n5) ACADEMIC PEER / COURSE EXPERIENCE\nKEEP when the sender seeks someone with direct course/major/teacher/test experience for academic learning or course-content advice.\n\nKEEP examples:\n"السلام عليكم احد ياخد هذي المواد ؟ فقه فرائض 1 مع اميره مغازي"\n"احد قد درس المادة هذي؟"\n"مين قد اختبر مع الدكتور وكيف اذاكر له؟"\n"في احد اخذ هياكل بيانات ويفيدني؟"\n\n6) SCHOLARSHIP / ACADEMIC OPPORTUNITY / RESEARCH COLLABORATION\nKEEP genuine requesters asking for scholarship opportunities, scholarship eligibility/application help, or seeking an academic/research/project collaborator or colleague.\n\nKEEP examples:\n"احد يعرف منحة مفتوحة للماجستير؟"\n"احتاج احد يساعدني في التقديم على منحة"\n"ابحث عن زميل امن سيبراني يشارك معي في بحث"\n"محتاج مشارك في مشروع التخرج"\n\n======================== REJECT ========================\n\nA) ANSWERS / REPLIES / STATEMENTS\nREJECT answers, advice, instructions, explanations, announcements, observations and ordinary conversation when the NEW message itself is not seeking target help.\n\nREJECT examples:\n"ابدأ في التاسيس وبعدين قرامر ريدنق استماع تدريب تجميعات"\n"ان شاءالله لا داومي الاحد وروحي لمرشدتك"\n"الشرح بالمثبته بسوي لك منشن"\n"شرحتها ريناد السعيدي في اليوتيوب"\n"وعليكم السلام مافي تجسير هالسنه تدرسين وتتخرجين بشهاده دبلوم"\n"التدريب التعاوني ما ينزل ترا"\n"موادك الثانية تروحين لمرشدتك تنزلهم لك"\n"هذي بترم التخرج بس"\n"اذا مكتوب في الميد ملف دكتور فهذا يعني انه كان المنسق"\n"بالتقويم من الاحد للثلاثاء بس دايماً كل ترم يمددونه للخميس"\n"ماحد طالع له ما نزلوها باقي"\n"شكلك متخصص، التخصص دوامه يبدا 7"\n\nA vague message with no academic object, such as "بليز ممكن احد يساعدني🙏", is REJECT unless the NEW message itself makes the academic need clear.\n\nB) UNIVERSITY ADMINISTRATION / PROCEDURES\nREJECT registration, add/drop, timetable status, advisor/deanship procedures, admission status, deferment, visitor status, graduation-hour approvals, registration/calendar periods and similar university administration.\n\nREJECT examples:\n"احد زيي لما ادخل على الجدول يقولي غير مسجل ايش يعني وانا دافعه امس الظهر"\n"لاهنتم استفسار بخصوص تأجيل ترم واحد اقدر بعده اتخرج مع دفعتي؟"\n"السلام عليكم انا تخصص تعقيم دبلوم مدفوع نزلت لي مادتين بس متى ينزل الجدول كامل"\n"احد انقبل يدوي ؟"\n"في احتماليه يشيلون التدريب الميداني او يخلونه اختياري؟"\n"احد عنده تقويم الفصل الاول ؟"\n"كيف احجز موعد بالعمادة"\n"كيف اسجل مادة"\n"كيف احذف المادة"\n"كيف اعدل الجدول"\n"كيف ارفع طلب"\n"متى يفتح التسجيل"\n\nDISTINCTION:\n"اختبار التحويل عبارة عن ايش؟" = academic test content => KEEP.\n"كيف اسجل لاختبار التحويل؟" = administrative procedure => REJECT.\n"ابي مصادر تدريب للكمي" = learning/practice material => KEEP.\n"التدريب التعاوني ما ينزل" = university procedure => REJECT.\n\nC) UNIVERSITY IT / SERVICE-DESK SUPPORT\nREJECT university email, Blackboard/LMS, portal/login/password, account activation, university app/system, Wi-Fi or ordinary device/service troubleshooting.\n\nREJECT examples:\n"ماتجيني رسايل في بريد الجامعة تعرفون وش الحل ؟"\n"كيف نعرف ان الإيميل أتفعل لان من الاحد فيه محاضرات عن بعد والبلاك بورد ما تفعل"\n"كلمة السر م تفتح معي"\n"نسيت الباسورد"\n"البلاك بورد ما يفتح"\n"النظام معلق"\n\nDISTINCTION:\n"ابي مختص يساعدني في مشروع امن سيبراني" = KEEP.\n"ابي مختص يساعدني اصلح مشكلة تسجيل الدخول" = REJECT.\n\nD) TRANSPORT / LOCATION / SHOPPING / LOGISTICS\nREJECT drivers, transport/buses, rooms/buildings/locations, where to buy/print, prices and ordinary logistics.\n\nREJECT examples:\n"مين يعرف سواقات بالشهر؟"\n"السلام عليكم فيه احد يعرف ارقام باصات الترددي للكليات؟"\n"وين القاعة"\n"وين المبنى"\n"وين ينباع الكتاب"\n"وين اطبع الكتاب"\n"كم سعر الكتاب"\n"وين الاختبار"\n"متى الاختبار"\n\nE) GENERAL UNIVERSITY INFORMATION\nREJECT routine information whose answer is merely a date, rule, schedule, administrative fact or status rather than target academic learning/help.\n\nREJECT examples:\n"متى يبدأ الترم"\n"هل بكرة دوام"\n"كم ساعة المادة"\n"مين دكتور الشعبة"\n"هل الحضور اجباري"\n"متى ينزل الجدول"\n"هل فيه تجسير هالسنه"\n\nBut:\n"مين افضل مدرس للمادة" = KEEP.\n"مين يعرف دكتور يشرح المادة خصوصي" = KEEP.\n"مين قد اختبر مع الدكتور وكيف اذاكر له" = KEEP.\n\nF) SELLERS / PROVIDERS / ADS / COMMERCIAL PROMOTION\nThe sender must be SEEKING the service, not advertising/providing it.\n\nREJECT:\n"نسوي مشاريع وواجبات"\n"نحل جميع الواجبات"\n"نوفر مدرسين خصوصيين"\n"متوفر مدرس خصوصي"\n"خدمات بحوث ومشاريع تخرج"\n"نسوي برزنتيشن وباوربونت"\n"عروض وخصومات على خدماتنا"\n"للتواصل واتساب"\n\nKEEP:\n"ابي افضل خصوصي رياضيات"\n"احد عنده رقم خصوصي ممتاز"\n"احتاج احد يسوي لي مشروع"\n"احتاج احد يساعدني ببحث"\n\n======================== BROAD WORDS ========================\n\nWords such as احد، أحد، يعرف، تعرفون، يساعد، يساعدني، فاهم، مدرس، مختص، متخصص، دكتور، خصوصي، تدريب، اختبار، مراجعة، عروض, ملف, تخرج must NEVER determine the result alone. Judge WHAT the sender wants.\n\n"احد يعرف كيف اغير كلمة السر" = REJECT.\n"احد يعرف خصوصي بايثون" = KEEP.\n"ياليت احد يساعدني احجز موعد بالعمادة" = REJECT.\n"ياليت احد يساعدني في واجب شبكات" = KEEP.\n"مين يعرف سواقات بالشهر" = REJECT.\n"مين يعرف مدرس خصوصي بالشهر" = KEEP.\n\n======================== CONTEXT ========================\n\nUse this ONE recent source-chat message only when the NEW message is genuinely incomplete and cannot be understood by itself:\n{source_message_context:1}\n\nThe NEW message always has priority. NEVER classify an answer/reply as relevant merely because previous context was a relevant academic request. A clear admin/IT/logistics/advertisement/answer must remain REJECT regardless of context.\n\n======================== LANGUAGE / OUTPUT ========================\n\nUnderstand MSA, Saudi/Gulf/Yemeni colloquial Arabic, misspellings, abbreviations, short Telegram style, English and mixed Arabic-English.\n\nIf the NEW message is clearly a target academic request, KEEP it.\nIf it is ambiguous but contains a concrete academic person/help/resource/tool/coursework need, prefer KEEP rather than losing a potentially important request.\nIf it is merely vague conversation with no concrete academic need, REJECT.\n\nIf relevant: return the original NEW message EXACTLY unchanged.\nIf irrelevant: output exactly #SKIP\nNever explain, summarize, label or rewrite.'


# ============================================================
# EXACT NEW WHITELIST
# ============================================================
#
# Expanded high-recall terms are included so important requests reach Gemini.
#
# Duplicates from the supplied list such as:
#   يحل
#   يعرف
# were removed because the database needs only one copy.
#
# ============================================================

WHITELIST = ['يشرح', 'يسوي', 'يحل', 'واجب', 'مشاريع', 'مشروع', 'نشاط', 'بحث', 'بحوث', 'تخرج', 'فاهم', 'تعرفون', 'خصوصي', 'شبكات', 'امن سيبراني', 'قواعد بيانات', 'يساعدني', 'عروض', 'برزنتيشن', 'بوستر', 'باوربونت', 'شرح', 'تقرير', 'تدريب', 'يعرف', 'احد', 'أحد', 'واجبات', 'جافا', 'بايثون', 'بغيت', 'يساعد', 'مدرس', 'معلم', 'استاذ', 'أستاذ', 'مختص', 'متخصص', 'اختبار', 'امتحان', 'كويز', 'ميد', 'فاينل', 'مراجعة', 'تكليف', 'احتاج', 'أحتاج', 'محتاج', 'محتاجة', 'محتاجه', 'ابي', 'أبي', 'ابغى', 'أبغى', 'ابغا', 'أبغا', 'ساعدوني', 'يفيدني', 'يفيدنا', 'دلني', 'يدلني', 'عندكم فكره', 'عندكم فكرة', 'حلول', 'مصادر', 'بنوك', 'تجميعات', 'تجميع', 'ملخص', 'ملخصات', 'ملفات', 'ملف', 'سلايدات', 'مراجع', 'مرجع', 'مذاكرة', 'مذاكره', 'اذاكر', 'أذاكر', 'اسئلة', 'أسئلة', 'نماذج', 'نموذج', 'قدرات', 'كمي', 'لفظي', 'تحصيلي', 'GAT', 'STEP', 'خريج', 'خريجة', 'تخصصه', 'تخصصها', 'قد درس', 'درس عند', 'اخذ المادة', 'أخذ المادة', 'ياخد هذي المواد', 'قروب مناقشه', 'قروب مناقشة', 'قروب مذاكرة', 'قروب مذاكره', 'كانفا', 'ترجم', 'ترجمة', 'تلخيص', 'يفرغ', 'تفريغ', 'برنامج', 'بوت يترجم', 'اداة', 'أداة', 'علوم حاسب', 'تقنية معلومات', 'امن المعلومات', 'أمن المعلومات', 'هياكل', 'خوارزميات', 'برمجة', 'برمجه', 'software', 'programming', 'python', 'java', 'database', 'network', 'cyber', 'algorithm', 'رسالة', 'رساله', 'اطروحة', 'أطروحة', 'ثيسس', 'thesis', 'research', 'assignment', 'homework', 'project', 'presentation', 'powerpoint', 'مشارك', 'مشاركة', 'شريك', 'زميل', 'تعاون', 'منحة', 'منح', 'ابتعاث', 'scholarship']


# AI outputs this exact word when a message must NOT be forwarded.
BLACKLIST = [
    "#SKIP"
]


# ============================================================
# GEMINI MODEL CONFIG
# ============================================================

def ensure_model_config(apply=False):
    path = "/app/config/ai_models.json"

    if not os.path.exists(path):
        print(f"WARNING: {path} does not exist.")
        return False

    with open(path, "r", encoding="utf-8") as f:
        config = json.load(f)

    gemini_models = config.setdefault("gemini", [])

    if MODEL in gemini_models:
        print(f"AI model config    : {MODEL} already present")
        return True

    print(f"AI model config    : {MODEL} needs to be added")

    if apply:
        gemini_models.append(MODEL)

        with open(path, "w", encoding="utf-8") as f:
            json.dump(
                config,
                f,
                ensure_ascii=False,
                indent=4
            )

        print(f"AI model config    : added {MODEL}")

    return True


# ============================================================
# MAIN
# ============================================================

def main():

    parser = argparse.ArgumentParser(
        description=(
            "Replace all existing Heavrnl keywords with the "
            "strict requested student-service filter."
        )
    )

    parser.add_argument(
        "--target-id",
        type=int,
        required=True,
        help=(
            "Telegram/Heavrnl destination chat ID whose "
            "forwarding rules should be updated."
        ),
    )

    parser.add_argument(
        "--apply",
        action="store_true",
        help=(
            "Actually modify the database. "
            "Without --apply this is only a dry run."
        ),
    )

    args = parser.parse_args()


    # --------------------------------------------------------
    # CHECK GEMINI KEY
    # --------------------------------------------------------

    raw_gemini_keys = os.getenv("GEMINI_API_KEYS", "").strip()
    legacy_gemini_key = os.getenv("GEMINI_API_KEY", "").strip()

    if raw_gemini_keys:
        normalized_keys = raw_gemini_keys.replace(";", ",").replace("\n", ",").replace("\r", ",")
        gemini_keys = []
        for chunk in normalized_keys.split(","):
            gemini_keys.extend(part for part in chunk.split() if part)
        gemini_keys = list(dict.fromkeys(gemini_keys))
    else:
        gemini_keys = [legacy_gemini_key] if legacy_gemini_key else []

    gemini_key_set = bool(gemini_keys)

    print(
        f"GEMINI API keys    : "
        f"{len(gemini_keys)} configured"
    )

    print(f"AI model           : {MODEL}")
    print(f"Destination ID     : {args.target_id}")


    ensure_model_config(
        apply=args.apply
    )


    # --------------------------------------------------------
    # DATABASE
    # --------------------------------------------------------

    session = get_session()

    try:

        # ----------------------------------------------------
        # FIND DESTINATION CHAT
        # ----------------------------------------------------

        target = (
            session.query(Chat)
            .filter(
                Chat.telegram_chat_id == str(args.target_id)
            )
            .first()
        )

        if not target:

            raise SystemExit(
                f"ERROR: destination chat "
                f"{args.target_id} "
                f"is not present in the Heavrnl database."
            )


        # ----------------------------------------------------
        # FIND ALL RULES FOR THIS DESTINATION
        # ----------------------------------------------------

        rules = (
            session.query(ForwardRule)
            .filter(
                ForwardRule.target_chat_id == target.id
            )
            .order_by(
                ForwardRule.id
            )
            .all()
        )


        if not rules:

            raise SystemExit(
                f"ERROR: no forwarding rules currently target "
                f"{target.name} "
                f"({target.telegram_chat_id})."
            )


        rule_ids = [
            rule.id
            for rule in rules
        ]


        # ----------------------------------------------------
        # COUNT OLD KEYWORDS
        # ----------------------------------------------------

        existing_keyword_count = (
            session.query(Keyword)
            .filter(
                Keyword.rule_id.in_(rule_ids)
            )
            .count()
        )


        expected_whitelist_rows = (
            len(rules) * len(WHITELIST)
        )

        expected_blacklist_rows = (
            len(rules) * len(BLACKLIST)
        )


        print()

        print(
            f"Destination        : "
            f"{target.name} "
            f"({target.telegram_chat_id})"
        )

        print(
            f"Rules found        : "
            f"{len(rules)}"
        )

        print(
            f"OLD keyword rows   : "
            f"{existing_keyword_count}"
        )

        print(
            f"NEW whitelist      : "
            f"{len(WHITELIST)} keywords per rule"
        )

        print(
            f"NEW whitelist rows : "
            f"{expected_whitelist_rows}"
        )

        print(
            f"NEW blacklist rows : "
            f"{expected_blacklist_rows}"
        )

        print(
            f"Blacklist          : "
            f"{BLACKLIST}"
        )

        print()

        print("NEW HIGH-RECALL LOCAL WHITELIST:")

        print(
            ", ".join(WHITELIST)
        )

        print()


        # ----------------------------------------------------
        # CHECK GEMINI API KEY
        # ----------------------------------------------------

        if not gemini_key_set:

            print(
                "ERROR: neither GEMINI_API_KEYS nor "
                "GEMINI_API_KEY is configured in /app/.env."
            )

            print(
                "Nothing has been changed."
            )

            return


        # ----------------------------------------------------
        # DRY RUN
        # ----------------------------------------------------

        if not args.apply:

            print(
                "DRY RUN ONLY — nothing has been changed."
            )

            print()

            print(
                "When --apply is used:"
            )

            print(
                "1. ALL old keyword/regex rows for these "
                "rules will be deleted."
            )

            print(
                "2. ONLY the requested whitelist above "
                "will be added."
            )

            print(
                "3. #SKIP will be added as the blacklist."
            )

            print(
                "4. The compact high-precision AI requester-classifier "
                "prompt will replace the old prompt."
            )

            return


        # ====================================================
        # APPLY
        # ====================================================


        # ----------------------------------------------------
        # REMOVE ALL OLD KEYWORDS
        # ----------------------------------------------------
        #
        # This removes:
        #
        # - previous whitelist keywords
        # - previous blacklist keywords
        # - previous regex keywords
        #
        # for these forwarding rules.
        #
        # ----------------------------------------------------

        deleted_keyword_rows = (
            session.query(Keyword)
            .filter(
                Keyword.rule_id.in_(rule_ids)
            )
            .delete(
                synchronize_session=False
            )
        )


        # ----------------------------------------------------
        # CONFIGURE EVERY RULE
        # ----------------------------------------------------

        for rule in rules:

            # Rule enabled
            rule.enable_rule = True


            # ----------------------------------------------
            # KEYWORD FILTER
            # ----------------------------------------------

            rule.add_mode = AddMode.WHITELIST

            rule.forward_mode = (
                ForwardMode.WHITELIST_THEN_BLACKLIST
            )


            # ----------------------------------------------
            # FORWARDING
            # ----------------------------------------------

            rule.use_bot = True

            rule.handle_mode = (
                HandleMode.FORWARD
            )


            # ----------------------------------------------
            # AI
            # ----------------------------------------------

            rule.is_ai = True

            rule.ai_model = MODEL

            rule.ai_prompt = PROMPT

            rule.enable_ai_upload_image = False

            # Run keyword filtering again after AI.
            # AI returns #SKIP when rejected.
            rule.is_keyword_after_ai = True

            # No scheduled AI summary.
            rule.is_summary = False


            # ----------------------------------------------
            # SOURCE ATTRIBUTION
            # ----------------------------------------------

            rule.is_original_sender = True

            rule.is_original_link = True

            rule.is_original_time = True


            # ----------------------------------------------
            # DISABLE UNRELATED EXTRA FEATURES
            # ----------------------------------------------

            rule.is_delete_original = False

            rule.enable_delay = False

            rule.enable_media_type_filter = False

            rule.enable_media_size_filter = False

            rule.enable_extension_filter = False

            rule.enable_push = False

            rule.enable_only_push = False

            rule.only_rss = False


            # ----------------------------------------------
            # ADD ONLY NEW WHITELIST
            # ----------------------------------------------

            for keyword in WHITELIST:

                session.add(
                    Keyword(
                        rule_id=rule.id,
                        keyword=keyword,
                        is_regex=False,
                        is_blacklist=False,
                    )
                )


            # ----------------------------------------------
            # ADD AI REJECTION BLACKLIST
            # ----------------------------------------------

            for keyword in BLACKLIST:

                session.add(
                    Keyword(
                        rule_id=rule.id,
                        keyword=keyword,
                        is_regex=False,
                        is_blacklist=True,
                    )
                )


        # ----------------------------------------------------
        # SAVE
        # ----------------------------------------------------

        session.commit()


        # ----------------------------------------------------
        # RESULT
        # ----------------------------------------------------

        print()

        print("DONE")

        print(
            f"Configured rules    : "
            f"{len(rules)}"
        )

        print(
            f"Deleted OLD rows    : "
            f"{deleted_keyword_rows}"
        )

        print(
            f"Whitelist per rule  : "
            f"{len(WHITELIST)}"
        )

        print(
            f"Whitelist rows      : "
            f"{expected_whitelist_rows}"
        )

        print(
            f"Blacklist rows      : "
            f"{expected_blacklist_rows}"
        )

        print(
            "Filter mode         : "
            "WHITELIST_THEN_BLACKLIST"
        )

        print(
            "Forward via         : BOT"
        )

        print(
            f"AI                  : "
            f"ON ({MODEL})"
        )

        print(
            "Post-AI keywords    : ON"
        )

        print(
            "AI rejection token  : #SKIP"
        )

        print()

        print(
            "Only the requested keyword set "
            "is now active."
        )


    except Exception:

        session.rollback()

        raise


    finally:

        session.close()


if __name__ == "__main__":
    main()
