#!/usr/bin/env python3
"""Apply the single canonical Shaker-derived V8 policy to destination rules."""

import argparse
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
os.chdir(ROOT)
sys.path.insert(0, str(ROOT))

from dotenv import load_dotenv

load_dotenv(ROOT / ".env")

from ai.gemini_provider import _load_api_keys
from enums.enums import AddMode, ForwardMode, HandleMode
from filter_policy_v8 import BLACKLIST, MODEL, PROMPT, REGEX_WHITELIST, WHITELIST
from models.models import Chat, ForwardRule, Keyword, get_session


def ensure_model_config(apply=False):
    path = ROOT / "config" / "ai_models.json"
    if not path.exists():
        raise SystemExit(f"Missing AI model configuration: {path}")
    config = json.loads(path.read_text(encoding="utf-8"))
    models = config.setdefault("gemini", [])
    if MODEL in models:
        return
    if apply:
        models.append(MODEL)
        path.write_text(
            json.dumps(config, ensure_ascii=False, indent=4) + "\n",
            encoding="utf-8",
        )


def configure_rule(rule):
    rule.enable_rule = True
    rule.add_mode = AddMode.WHITELIST
    rule.forward_mode = ForwardMode.WHITELIST_THEN_BLACKLIST

    # Keep the original filter chain, with native user delivery only at the end.
    rule.use_bot = True
    rule.handle_mode = HandleMode.FORWARD
    rule.is_replace = False
    rule.is_filter_user_info = False

    rule.is_ai = True
    rule.ai_model = MODEL
    rule.ai_prompt = PROMPT
    rule.enable_ai_upload_image = False
    rule.is_keyword_after_ai = True
    rule.is_summary = False

    rule.is_original_sender = True
    rule.is_original_link = True
    rule.is_original_time = True
    rule.userinfo_template = (
        "👤 Sender: {name}\n"
        "🆔 Telegram ID: {id}\n"
        "👤 Username: {username}\n"
        "🔗 Username URL: {username_url}"
    )
    rule.time_template = "🕒 Sent: {time}"
    rule.original_link_template = "🔗 Original message: {original_link}"

    rule.is_delete_original = False
    rule.enable_delay = False
    rule.enable_comment_button = False
    rule.enable_media_type_filter = False
    rule.enable_media_size_filter = False
    rule.enable_extension_filter = False
    rule.enable_reverse_blacklist = False
    rule.enable_reverse_whitelist = False
    rule.enable_push = False
    rule.enable_only_push = False
    rule.only_rss = False
    rule.enable_sync = False
    rule.is_ufb = False


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--target-id", type=int, required=True)
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()

    keys = _load_api_keys()
    required_keys = int(os.getenv("GEMINI_REQUIRED_KEY_COUNT", "10") or "10")
    if len(keys) != required_keys:
        raise SystemExit(
            f"Expected {required_keys} unique Gemini keys, found {len(keys)}"
        )
    if os.getenv("GEMINI_API_BASE", "").strip():
        raise SystemExit("GEMINI_API_BASE must be empty for native key rotation")

    ensure_model_config(apply=args.apply)
    session = get_session()
    try:
        target = session.query(Chat).filter(
            Chat.telegram_chat_id == str(args.target_id)
        ).first()
        if target is None:
            raise SystemExit(
                f"Destination {args.target_id} is absent from the database"
            )
        rules = (
            session.query(ForwardRule)
            .filter(ForwardRule.target_chat_id == target.id)
            .order_by(ForwardRule.id)
            .all()
        )
        if not rules:
            raise SystemExit("No forwarding rules target the destination")
        rule_ids = [rule.id for rule in rules]
        old_rows = session.query(Keyword).filter(
            Keyword.rule_id.in_(rule_ids)
        ).count()

        print(f"DESTINATION={target.name} ({target.telegram_chat_id})")
        print(f"RULES={len(rules)}")
        print(f"OLD_KEYWORD_ROWS={old_rows}")
        print(f"LITERAL_WHITELIST_PER_RULE={len(WHITELIST)}")
        print(f"REGEX_WHITELIST_PER_RULE={len(REGEX_WHITELIST)}")
        print(f"BLACKLIST_PER_RULE={len(BLACKLIST)}")
        print(f"GEMINI_UNIQUE_KEYS={len(keys)}")
        print(f"MODEL={MODEL}")

        if not args.apply:
            print("DRY_RUN=YES")
            return

        deleted = session.query(Keyword).filter(
            Keyword.rule_id.in_(rule_ids)
        ).delete(synchronize_session=False)
        for rule in rules:
            configure_rule(rule)
            session.add_all(
                [
                    Keyword(
                        rule_id=rule.id,
                        keyword=term,
                        is_regex=False,
                        is_blacklist=False,
                    )
                    for term in WHITELIST
                ]
            )
            session.add_all(
                [
                    Keyword(
                        rule_id=rule.id,
                        keyword=pattern,
                        is_regex=True,
                        is_blacklist=False,
                    )
                    for pattern in REGEX_WHITELIST
                ]
            )
            session.add_all(
                [
                    Keyword(
                        rule_id=rule.id,
                        keyword=term,
                        is_regex=False,
                        is_blacklist=True,
                    )
                    for term in BLACKLIST
                ]
            )
        session.commit()
        print("APPLY=OK")
        print(f"DELETED_OLD_KEYWORD_ROWS={deleted}")
        print("FILTER_ORDER=LOCAL_WHITELIST_THEN_GEMINI_THEN_SKIP_BLACKLIST")
        print("FINAL_DELIVERY=NATIVE_USER_FORWARD_WITH_COPY_FALLBACK")
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


if __name__ == "__main__":
    main()
