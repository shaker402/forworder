import asyncio
import logging
import os

from dotenv import load_dotenv
from sqlalchemy.orm import joinedload, selectinload
from telethon import events
from telethon.tl import types

from auto_bind_new_chat import ensure_auto_rule
from filters.process import process_forward_rule
from handlers import bot_handler, user_handler
from handlers.prompt_handlers import handle_prompt_setting
from managers.state_manager import state_manager
from models.models import (
    Chat,
    ForwardRule,
    RSSConfig,
    get_session,
)
from native_forward_runtime import set_user_client as set_native_forward_user_client

load_dotenv()
logger = logging.getLogger(__name__)

PROCESSED_GROUPS = set()
GROUP_CACHE_LOCK = asyncio.Lock()
AUTO_BIND_LOCK = asyncio.Lock()
BOT_ID = None


def _env_int(name, default, minimum=1):
    try:
        value = int(os.getenv(name, str(default)).strip())
    except (TypeError, ValueError):
        value = int(default)
    return max(minimum, value)


MESSAGE_SEMAPHORE = asyncio.Semaphore(
    _env_int("MAX_CONCURRENT_MESSAGE_HANDLERS", 10)
)


def _numeric_id_variants(value):
    """Return raw and marked Telegram ID forms without resolving an entity."""
    try:
        number = abs(int(str(value).strip()))
    except (TypeError, ValueError):
        return set()
    variants = {number}
    text_value = str(number)
    if text_value.startswith("100") and len(text_value) > 3:
        variants.add(int(text_value[3:]))
    return variants


def _is_configured_output_chat(event):
    event_ids = _numeric_id_variants(getattr(event, "chat_id", None))
    chat = getattr(event, "chat", None)
    event_ids.update(_numeric_id_variants(getattr(chat, "id", None)))
    if not event_ids:
        return False

    configured_ids = set()
    for name in (
        "NATIVE_QUOTE_TARGET",
        "AUTO_BIND_TARGET_ID",
        "OUTPUT_GROUP_RAW_ID",
        "OUTPUT_GROUP_ID",
    ):
        configured_ids.update(_numeric_id_variants(os.getenv(name, "")))
    return bool(event_ids & configured_ids)


async def setup_listeners(user_client, bot_client):
    """Register the user listener and the bot command listener."""
    global BOT_ID
    set_native_forward_user_client(user_client)

    try:
        BOT_ID = int((await bot_client.get_me()).id)
        logger.info("Telegram bot identity loaded")
    except Exception as exc:
        logger.error("Could not load Telegram bot identity: %s", exc)

    async def not_from_bot(event):
        try:
            return BOT_ID is None or int(event.sender_id) != BOT_ID
        except (TypeError, ValueError):
            return True

    @user_client.on(events.NewMessage(func=not_from_bot))
    async def user_message_handler(event):
        # A genuine native forward is outgoing from the authenticated user.
        # It is output, not another source message.
        if getattr(event, "out", False) and getattr(event.message, "fwd_from", None):
            return
        if _is_configured_output_chat(event):
            return
        async with MESSAGE_SEMAPHORE:
            await handle_user_message(event, user_client, bot_client)

    @bot_client.on(events.NewMessage(func=not_from_bot))
    async def bot_message_handler(event):
        await handle_bot_message(event, bot_client)

    bot_client.add_event_handler(bot_handler.callback_handler)


def _rule_load_options():
    """Eager-load every relationship used by the asynchronous filter chain."""
    return (
        joinedload(ForwardRule.source_chat),
        joinedload(ForwardRule.target_chat),
        selectinload(ForwardRule.keywords),
        selectinload(ForwardRule.replace_rules),
        selectinload(ForwardRule.media_types),
        selectinload(ForwardRule.media_extensions),
        selectinload(ForwardRule.rule_syncs),
        selectinload(ForwardRule.push_config),
        selectinload(ForwardRule.rss_config).selectinload(RSSConfig.patterns),
    )


async def _load_detached_forward_plan(event, chat_id):
    """Load rules, detach them, then release the DB connection before AI I/O."""
    session = get_session()
    try:
        source_chat = session.query(Chat).filter(
            Chat.telegram_chat_id == str(chat_id)
        ).first()

        if not source_chat:
            async with AUTO_BIND_LOCK:
                # Another message may have created this row while we waited.
                session.rollback()
                source_chat = session.query(Chat).filter(
                    Chat.telegram_chat_id == str(chat_id)
                ).first()
                if not source_chat:
                    source_chat = await ensure_auto_rule(
                        session=session,
                        event=event,
                        source_chat=None,
                        chat_id=chat_id,
                    )
        if not source_chat:
            return None, []

        source_name = source_chat.name or str(chat_id)
        rules = (
            session.query(ForwardRule)
            .options(*_rule_load_options())
            .filter(ForwardRule.source_chat_id == source_chat.id)
            .order_by(ForwardRule.id)
            .all()
        )

        # expunge_all makes an accidental lazy query during an awaited filter
        # fail immediately in development instead of silently holding a pool slot.
        session.expunge_all()
        return source_name, rules
    finally:
        session.close()


async def handle_user_message(event, user_client, bot_client):
    """Process one source message without holding DB resources across awaits."""
    try:
        chat = await event.get_chat()
        chat_id = abs(int(chat.id))

        if isinstance(event.chat, types.Channel) and state_manager.check_state():
            sender_id = os.getenv("USER_ID")
            state_chat_id = int(f"100{chat_id}")
        else:
            sender_id = event.sender_id
            state_chat_id = chat_id

        current_state, message, _ = state_manager.get_state(
            sender_id, state_chat_id
        )
        if current_state and await handle_prompt_setting(
            event,
            bot_client,
            sender_id,
            state_chat_id,
            current_state,
            message,
        ):
            return

        if event.message.grouped_id:
            group_key = f"{chat_id}:{event.message.grouped_id}"
            async with GROUP_CACHE_LOCK:
                if group_key in PROCESSED_GROUPS:
                    return
                PROCESSED_GROUPS.add(group_key)
            asyncio.create_task(clear_group_cache(group_key))

        source_name, rules = await _load_detached_forward_plan(event, chat_id)
        if not rules:
            return

        logger.debug("Loaded %d detached rules for %s", len(rules), source_name)
        for rule in rules:
            if not rule.enable_rule:
                continue
            if rule.use_bot:
                await process_forward_rule(bot_client, event, str(chat_id), rule)
            else:
                await user_handler.process_forward_rule(
                    user_client, event, str(chat_id), rule
                )
    except Exception as exc:
        logger.exception("User-message processing failed: %s", exc)


async def handle_bot_message(event, bot_client):
    """Handle configuration commands received by the bot account."""
    try:
        chat = await event.get_chat()
        chat_id = abs(int(chat.id))
        if isinstance(event.chat, types.Channel) and state_manager.check_state():
            sender_id = os.getenv("USER_ID")
            chat_id = int(f"100{chat_id}")
        else:
            sender_id = event.sender_id

        current_state, message, _ = state_manager.get_state(sender_id, chat_id)
        if current_state:
            await handle_prompt_setting(
                event, bot_client, sender_id, chat_id, current_state, message
            )
            return
        await bot_handler.handle_command(bot_client, event)
    except Exception as exc:
        logger.exception("Bot-command processing failed: %s", exc)


async def clear_group_cache(group_key, delay=300):
    await asyncio.sleep(delay)
    async with GROUP_CACHE_LOCK:
        PROCESSED_GROUPS.discard(group_key)
