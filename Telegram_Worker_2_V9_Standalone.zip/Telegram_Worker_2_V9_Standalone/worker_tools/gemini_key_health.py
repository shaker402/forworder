#!/usr/bin/env python3
"""Optional live reachability test for each Gemini slot; key values stay hidden."""

import argparse
import asyncio
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
os.chdir(ROOT)
sys.path.insert(0, str(ROOT))

from dotenv import load_dotenv

load_dotenv(ROOT / ".env")

from ai.gemini_provider import GeminiProvider, GeminiRequestError, _load_api_keys
from filter_policy_v8 import MODEL


async def async_main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--live", action="store_true", help="make one API call per slot")
    parser.add_argument("--model", default=MODEL)
    parser.add_argument("--require-count", type=int, default=10)
    parser.add_argument("--minimum-healthy", type=int, default=1)
    parser.add_argument("--minimum-reachable", type=int, default=10)
    args = parser.parse_args()

    keys = _load_api_keys()
    print(f"CONFIGURED_UNIQUE_KEYS={len(keys)}")
    print(f"EXPECTED_KEYS={args.require_count}")
    print(f"CUSTOM_GEMINI_API_BASE_SET={bool(os.getenv('GEMINI_API_BASE', '').strip())}")
    if len(keys) != args.require_count:
        return 2
    if not args.live:
        print("LIVE_REQUESTS=SKIPPED")
        return 0

    healthy = 0
    reachable_but_limited = 0
    provider = GeminiProvider()
    await provider.initialize(model=args.model)
    for slot, _key in enumerate(keys, 1):
        try:
            result = await provider.check_key_slot(
                slot, "Reply with exactly OK and nothing else."
            )
            if result.strip():
                healthy += 1
                print(f"SLOT_{slot}=OK")
            else:
                print(f"SLOT_{slot}=EMPTY_RESPONSE")
        except GeminiRequestError as exc:
            if exc.status == 429:
                reachable_but_limited += 1
                print(f"SLOT_{slot}=RATE_LIMITED")
            elif exc.status in (400, 401, 403):
                print(f"SLOT_{slot}=AUTH_OR_CONFIGURATION_ERROR_{exc.status}")
            else:
                print(f"SLOT_{slot}=ERROR_{exc.status or 'NETWORK'}")

    print(f"HEALTHY_KEYS={healthy}")
    print(f"REACHABLE_BUT_RATE_LIMITED={reachable_but_limited}")
    reachable = healthy + reachable_but_limited
    print(f"REACHABLE_KEYS={reachable}")
    return 0 if (
        healthy >= args.minimum_healthy
        and reachable >= args.minimum_reachable
    ) else 3


if __name__ == "__main__":
    raise SystemExit(asyncio.run(async_main()))
