#!/usr/bin/env python3
import argparse
import asyncio
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
os.chdir(ROOT)
sys.path.insert(0, str(ROOT))

from dotenv import load_dotenv
from telethon import TelegramClient

load_dotenv(ROOT / ".env", override=True)


async def async_main(args):
    api_id = int(os.environ["API_ID"])
    api_hash = os.environ["API_HASH"]
    raw_id = args.target_id or int(os.environ["OUTPUT_GROUP_RAW_ID"])
    wanted_name = (
        args.target_name
        if args.target_name is not None
        else os.environ.get("OUTPUT_GROUP_NAME", "")
    ).strip().casefold()

    client = TelegramClient(str(ROOT / "sessions" / "user"), api_id, api_hash)
    await client.connect()
    try:
        if not await client.is_user_authorized():
            raise SystemExit("Telegram user session is not authorized")
        matches = []
        async for dialog in client.iter_dialogs():
            if int(getattr(dialog.entity, "id", 0)) != raw_id:
                continue
            if wanted_name and (dialog.name or "").strip().casefold() != wanted_name:
                continue
            matches.append(dialog)
        if len(matches) != 1:
            raise SystemExit(
                f"Expected exactly one destination with raw ID {raw_id}; "
                f"found {len(matches)}"
            )
        dialog = matches[0]
        print(f"OUTPUT_GROUP_FOUND={dialog.name}")
        print(f"OUTPUT_GROUP_RAW_ID={dialog.entity.id}")
        print(f"NATIVE_QUOTE_TARGET={dialog.id}")
    finally:
        await client.disconnect()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--target-id", type=int)
    parser.add_argument("--target-name")
    asyncio.run(async_main(parser.parse_args()))


if __name__ == "__main__":
    main()
