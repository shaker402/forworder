#!/usr/bin/env python3
"""Regression test for the QueuePool exhaustion shown in the supplied logs."""

import asyncio
import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


async def run_test():
    with tempfile.TemporaryDirectory() as directory:
        os.chdir(ROOT)
        os.environ["DATABASE_URL"] = "sqlite:///" + str(Path(directory) / "test.db")
        os.environ["DB_POOL_SIZE"] = "4"
        os.environ["DB_POOL_MAX_OVERFLOW"] = "0"
        os.environ["DB_POOL_TIMEOUT_SECONDS"] = "1"

        from sqlalchemy.orm import joinedload, selectinload
        from enums.enums import ForwardMode
        from models.models import (
            Chat,
            ForwardRule,
            Keyword,
            get_pool_snapshot,
            get_session,
            init_db,
        )

        init_db()
        session = get_session()
        source = Chat(telegram_chat_id="111", name="source")
        target = Chat(telegram_chat_id="222", name="target")
        session.add_all([source, target])
        session.flush()
        rule = ForwardRule(
            source_chat_id=source.id,
            target_chat_id=target.id,
            forward_mode=ForwardMode.WHITELIST_THEN_BLACKLIST,
        )
        session.add(rule)
        session.flush()
        session.add(
            Keyword(
                rule_id=rule.id,
                keyword="واجب",
                is_regex=False,
                is_blacklist=False,
            )
        )
        session.commit()
        session.close()

        from message_listener import _load_detached_forward_plan

        source_name, listener_rules = await _load_detached_forward_plan(
            object(), 111
        )
        assert source_name == "source"
        assert listener_rules[0].target_chat.name == "target"
        assert listener_rules[0].keywords[0].keyword == "واجب"
        assert get_pool_snapshot().get("checkedout") == 0

        reached_external_wait = asyncio.Event()
        waiting = 0
        waiting_lock = asyncio.Lock()

        async def simulated_message():
            nonlocal waiting
            db = get_session()
            try:
                loaded = (
                    db.query(ForwardRule)
                    .options(
                        joinedload(ForwardRule.source_chat),
                        joinedload(ForwardRule.target_chat),
                        selectinload(ForwardRule.keywords),
                    )
                    .first()
                )
                db.expunge_all()
            finally:
                db.close()
            assert loaded.target_chat.name == "target"
            assert loaded.keywords[0].keyword == "واجب"
            async with waiting_lock:
                waiting += 1
                if waiting == 50:
                    reached_external_wait.set()
            await asyncio.sleep(0.05)  # stand-in for Gemini/Telegram network I/O

        tasks = [asyncio.create_task(simulated_message()) for _ in range(50)]
        await reached_external_wait.wait()
        during_wait = get_pool_snapshot()
        assert during_wait.get("checkedout") == 0, during_wait
        await asyncio.gather(*tasks)
        after = get_pool_snapshot()
        assert after.get("checkedout") == 0, after

        print("DB_DETACHED_BEFORE_EXTERNAL_AWAIT=OK")
        print("REAL_MESSAGE_LISTENER_DETACH_PATH=OK")
        print("SIMULATED_CONCURRENT_MESSAGES=50")
        print("POOL_CHECKED_OUT_DURING_WAIT=0")
        print("POOL_CHECKED_OUT_AFTER_TEST=0")


if __name__ == "__main__":
    asyncio.run(run_test())
