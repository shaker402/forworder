#!/usr/bin/env python3
"""Export an explicitly requested redacted shadow-review JSONL sample."""

import argparse
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
os.chdir(ROOT)
sys.path.insert(0, str(ROOT))

from dotenv import load_dotenv

load_dotenv(ROOT / ".env", override=False)

from ai.local_shadow import review_sample


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--limit", type=int, default=200)
    parser.add_argument(
        "--origin",
        choices=("PREFILTER_PASS", "PREFILTER_REJECT_SAMPLE", "AI_DECISION"),
    )
    args = parser.parse_args()
    rows = review_sample(args.limit, args.origin)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    temporary = args.output.with_suffix(args.output.suffix + ".tmp")
    with temporary.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")
    os.chmod(temporary, 0o600)
    os.replace(temporary, args.output)
    print(f"REDACTED_REVIEW_ROWS={len(rows)}")
    print(f"OUTPUT={args.output}")
    print("RAW_SOURCE_IDS_INCLUDED=NO")


if __name__ == "__main__":
    main()
