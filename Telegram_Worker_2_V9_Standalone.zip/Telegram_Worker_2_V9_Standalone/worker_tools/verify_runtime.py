#!/usr/bin/env python3
"""Verify deployed files, key-pool routing, rule policy, and DB lifecycle."""

import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
os.chdir(ROOT)
sys.path.insert(0, str(ROOT))

from dotenv import load_dotenv

# Compose and the regression tests may intentionally provide explicit values.
# Load only missing names so a mounted .env cannot overwrite those values.
load_dotenv(ROOT / ".env", override=False)

from ai.gemini_provider import (
    CLASSIFIER_CONTRACT_V8,
    MULTI_KEY_GEMINI_POOL,
    PERSISTENT_GEMINI_QUEUE_V9,
    get_pool_diagnostics,
)
from enums.enums import ForwardMode
from filter_policy_v8 import BLACKLIST, MODEL, PROMPT, REGEX_WHITELIST, WHITELIST
from models.models import Chat, ForwardRule, Keyword, get_pool_snapshot, get_session


def id_variants(value):
    try:
        number = abs(int(str(value).strip()))
    except (TypeError, ValueError):
        return set()
    variants = {number}
    rendered = str(number)
    if rendered.startswith("100") and len(rendered) > 3:
        variants.add(int(rendered[3:]))
    return variants


def main():
    if MULTI_KEY_GEMINI_POOL is not True:
        raise SystemExit("Direct Gemini pool marker is missing")
    if PERSISTENT_GEMINI_QUEUE_V9 is not True:
        raise SystemExit("Persistent Gemini queue marker is missing")
    diagnostics = get_pool_diagnostics()
    required_keys = int(os.getenv("GEMINI_REQUIRED_KEY_COUNT", "10") or "10")
    if diagnostics["configured_keys"] != required_keys:
        raise SystemExit(
            f"Expected {required_keys} unique Gemini keys, "
            f"found {diagnostics['configured_keys']}"
        )
    if diagnostics["custom_compatible_base"]:
        raise SystemExit("GEMINI_API_BASE bypasses the native multi-key pool")
    expected_settings = {
        "GEMINI_MAX_KEY_ATTEMPTS": "1",
        "GEMINI_MAX_PARALLEL_REQUESTS": "3",
        "MAX_CONCURRENT_MESSAGE_HANDLERS": "10",
        "GEMINI_PROJECT_TARGET_RPM": "12",
        "GEMINI_PROJECT_MIN_INTERVAL_SECONDS": "5",
        "GEMINI_POLICY_VERSION": "shaker_wanted_v9",
        "GEMINI_FAIL_OPEN": "false",
        "LOCAL_SHADOW_ENABLED": "true",
    }
    for name, expected_value in expected_settings.items():
        actual_value = os.getenv(name, "").strip().lower()
        if actual_value != expected_value:
            raise SystemExit(
                f"{name} must be {expected_value}, found {actual_value or 'unset'}"
            )
    if os.getenv("VERIFY_ALLOW_TEMP_PATHS", "false").lower() != "true":
        expected_paths = {
            "GEMINI_QUEUE_PATH": "/app/db/gemini_queue.sqlite3",
            "LOCAL_SHADOW_MODEL_PATH": "/app/model/shaker_weak_tfidf_triage.joblib",
            "LOCAL_SHADOW_DB_PATH": "/app/db/local_shadow.sqlite3",
            "TELEGRAM_DELIVERY_DB_PATH": "/app/db/telegram_delivery_dedup.sqlite3",
        }
        for name, expected_value in expected_paths.items():
            if os.getenv(name, "").strip() != expected_value:
                raise SystemExit(f"{name} must be {expected_value}")
    if len(diagnostics["projects"]) != required_keys:
        raise SystemExit("Persistent scheduler does not contain ten project buckets")
    if not (ROOT / "model" / "shaker_weak_tfidf_triage.joblib").is_file():
        raise SystemExit("Local shadow model is missing")
    if CLASSIFIER_CONTRACT_V8 not in PROMPT:
        raise SystemExit("V8 classifier marker is missing")
    if os.getenv("WORKER_NAMESPACE", "").strip() != "worker2":
        raise SystemExit("Worker 2 queue/cache namespace is missing")
    if os.getenv("WORKER_INSTANCE", "").strip() != "worker2":
        raise SystemExit("Worker 2 runtime identity is missing")
    if os.getenv("NATIVE_QUOTE_CAPTURED_BY", "").strip() != "Telegram Worker 2":
        raise SystemExit("Worker 2 metadata label is incorrect")

    target_id = os.getenv("OUTPUT_GROUP_RAW_ID", "").strip()
    native_target = os.getenv("NATIVE_QUOTE_TARGET", "").strip()
    if not (id_variants(target_id) & id_variants(native_target)):
        raise SystemExit("Native target does not match OUTPUT_GROUP_RAW_ID")

    session = get_session()
    try:
        target = session.query(Chat).filter(
            Chat.telegram_chat_id == target_id
        ).first()
        if target is None:
            raise SystemExit("Destination is absent from the database")
        rules = session.query(ForwardRule).filter(
            ForwardRule.target_chat_id == target.id
        ).all()
        if not rules:
            raise SystemExit("No forwarding rule targets the destination")

        for rule in rules:
            if not rule.enable_rule or not rule.is_ai or not rule.is_keyword_after_ai:
                raise SystemExit(f"Rule {rule.id} is not fully enabled for V8 AI")
            if rule.ai_model != MODEL:
                raise SystemExit(f"Rule {rule.id} model differs from V8 policy")
            if rule.forward_mode != ForwardMode.WHITELIST_THEN_BLACKLIST:
                raise SystemExit(f"Rule {rule.id} has the wrong filter order")

        sample = rules[0]
        literal_count = session.query(Keyword).filter(
            Keyword.rule_id == sample.id,
            Keyword.is_blacklist == False,
            Keyword.is_regex == False,
        ).count()
        regex_count = session.query(Keyword).filter(
            Keyword.rule_id == sample.id,
            Keyword.is_blacklist == False,
            Keyword.is_regex == True,
        ).count()
        blacklist_count = session.query(Keyword).filter(
            Keyword.rule_id == sample.id,
            Keyword.is_blacklist == True,
        ).count()
        expected = (len(WHITELIST), len(REGEX_WHITELIST), len(BLACKLIST))
        actual = (literal_count, regex_count, blacklist_count)
        if actual != expected:
            raise SystemExit(f"Keyword counts differ: runtime={actual}, expected={expected}")
        rule_count = len(rules)
        target_name = target.name
    finally:
        session.close()

    pool = get_pool_snapshot()
    if pool.get("checkedout") not in (None, 0):
        raise SystemExit(f"Database connection remained checked out: {pool}")

    print("RUNTIME_VERIFY=OK")
    print(f"GEMINI_KEYS={diagnostics['configured_keys']}")
    print(f"GEMINI_MAX_PARALLEL={diagnostics['max_parallel_requests']}")
    print(f"GEMINI_PROJECT_TARGET_RPM={diagnostics['target_rpm_per_project']}")
    print(f"GEMINI_PROJECT_BUCKETS={len(diagnostics['projects'])}")
    print(f"GEMINI_QUEUE_COUNTS={diagnostics['queue_counts']}")
    print("LOCAL_MODEL_MODE=SHADOW_ONLY")
    print("AI_FAILURE_POLICY=NO_FORWARD")
    print(f"TARGET_NAME={target_name}")
    print(f"RULES={rule_count}")
    print(f"LITERAL_WHITELIST={literal_count}")
    print(f"REGEX_WHITELIST={regex_count}")
    print(f"BLACKLIST={blacklist_count}")
    print("NATIVE_TARGET_MATCH=YES")
    print("WORKER_NAMESPACE=worker2")
    print("WORKER_INSTANCE=worker2")
    print("CAPTURED_BY=Telegram Worker 2")
    print("DB_POOL_CHECKED_OUT_AFTER_VERIFY=0")


if __name__ == "__main__":
    main()
