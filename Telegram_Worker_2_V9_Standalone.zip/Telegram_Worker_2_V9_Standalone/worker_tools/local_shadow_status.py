#!/usr/bin/env python3
"""Print aggregate shadow-model metrics without message text or source IDs."""

import argparse
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
os.chdir(ROOT)
sys.path.insert(0, str(ROOT))

from dotenv import load_dotenv

load_dotenv(ROOT / ".env", override=False)

from ai.local_shadow import diagnostics, set_review_label


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--event-key")
    parser.add_argument("--label", choices=("KEEP", "SKIP"))
    args = parser.parse_args()
    if bool(args.event_key) != bool(args.label):
        parser.error("--event-key and --label must be supplied together")
    if args.event_key:
        if not set_review_label(args.event_key, args.label):
            raise SystemExit("Unknown shadow event key")
        print("REVIEW_LABEL_SAVED=YES")
    print(json.dumps(diagnostics(), ensure_ascii=False, indent=2))
    print("MESSAGE_TEXT_PRINTED=NO")


if __name__ == "__main__":
    main()
