#!/usr/bin/env python3
import asyncio
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
os.chdir(ROOT)
sys.path.insert(0, str(ROOT))

from dotenv import load_dotenv
from telethon import TelegramClient

load_dotenv(ROOT / ".env", override=True)


async def main():
    api_id = os.getenv("API_ID", "").strip()
    api_hash = os.getenv("API_HASH", "").strip()
    phone = os.getenv("PHONE_NUMBER", "").strip()
    if not api_id or not api_hash or not phone:
        raise SystemExit("API_ID, API_HASH and PHONE_NUMBER are required")

    client = TelegramClient(str(ROOT / "sessions" / "user"), int(api_id), api_hash)
    await client.start(phone=phone)
    try:
        me = await client.get_me()
        expected = os.getenv("USER_ID", "").strip()
        if expected and expected not in {"CHANGE_ME", "AUTO"} and str(me.id) != expected:
            raise SystemExit(
                f"USER_ID mismatch: configured ID differs from authenticated ID {me.id}"
            )
        print(f"AUTHORIZED_USER_ID={me.id}")
        print("AUTHORIZED_USER_SESSION=OK")
    finally:
        await client.disconnect()


if __name__ == "__main__":
    asyncio.run(main())

