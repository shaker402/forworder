#!/usr/bin/env python3
"""Zero-network automatic source discovery and target-exclusion test."""

import asyncio
import os
import sys
import tempfile
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
os.chdir(ROOT)
sys.path.insert(0, str(ROOT))


async def main():
    with tempfile.TemporaryDirectory() as directory:
        os.environ["DATABASE_URL"] = "sqlite:///" + str(Path(directory) / "test.db")
        os.environ["AUTO_BIND_NEW_CHATS"] = "true"
        os.environ["AUTO_BIND_TARGET_ID"] = "555"

        from models.models import Chat, ForwardRule, Keyword, get_session, init_db
        import auto_bind_new_chat

        init_db()
        session = get_session()
        target = Chat(telegram_chat_id="555", name="output")
        template_source = Chat(telegram_chat_id="100", name="template")
        session.add_all([target, template_source])
        session.flush()
        template = ForwardRule(
            source_chat_id=template_source.id,
            target_chat_id=target.id,
            is_ai=True,
            ai_model="gemini-3.5-flash-lite",
            is_keyword_after_ai=True,
        )
        session.add(template)
        session.flush()
        session.add(
            Keyword(
                rule_id=template.id,
                keyword="واجب",
                is_regex=False,
                is_blacklist=False,
            )
        )
        session.commit()

        original_group_check = auto_bind_new_chat.is_group_or_channel
        auto_bind_new_chat.is_group_or_channel = lambda event: True
        try:
            event = SimpleNamespace(chat=SimpleNamespace(id=777, title="new source"))
            source = await auto_bind_new_chat.ensure_auto_rule(
                session, event, None, 777
            )
            assert source.telegram_chat_id == "777"
            new_rule = session.query(ForwardRule).filter_by(
                source_chat_id=source.id, target_chat_id=target.id
            ).one()
            assert new_rule.is_ai and new_rule.is_keyword_after_ai
            assert new_rule.ai_model == "gemini-3.5-flash-lite"
            copied = session.query(Keyword).filter_by(rule_id=new_rule.id).all()
            assert [(item.keyword, item.is_blacklist) for item in copied] == [
                ("واجب", False)
            ]

            result = await auto_bind_new_chat.ensure_auto_rule(
                session,
                SimpleNamespace(chat=SimpleNamespace(id=555, title="output")),
                None,
                -100555,
            )
            assert result is None
            assert session.query(Chat).filter_by(telegram_chat_id="100555").count() == 0
        finally:
            auto_bind_new_chat.is_group_or_channel = original_group_check
            session.close()

        print("AUTO_BIND_CLONES_V8_SCALAR_POLICY=OK")
        print("AUTO_BIND_COPIES_KEYWORDS=OK")
        print("AUTO_BIND_OUTPUT_TARGET_EXCLUDED=OK")
        print("NO_NETWORK_REQUESTS=YES")


if __name__ == "__main__":
    asyncio.run(main())
