#!/usr/bin/env python3
"""Print privacy-safe durable Gemini scheduler status."""

import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
os.chdir(ROOT)
sys.path.insert(0, str(ROOT))

from dotenv import load_dotenv

load_dotenv(ROOT / ".env", override=False)

from ai.gemini_provider import get_pool_diagnostics


if __name__ == "__main__":
    print(json.dumps(get_pool_diagnostics(), ensure_ascii=False, indent=2))
    print("API_KEY_VALUES_PRINTED=NO")
