#!/usr/bin/env python3
"""Validate Gemini key sets by SHA-256 fingerprint without printing keys."""

import argparse
import hashlib
import re
from pathlib import Path


def read_values(path):
    values = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line or line.lstrip().startswith("#") or "=" not in line:
            continue
        name, value = line.split("=", 1)
        if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", name.strip()):
            values[name.strip()] = value.strip()
    return values


def key_fingerprints(path):
    values = read_values(path)
    raw = values.get("GEMINI_API_KEYS", "")
    candidates = []
    for chunk in raw.replace(";", ",").replace("\\n", ",").split(","):
        candidates.extend(chunk.split())
    if not candidates and values.get("GEMINI_API_KEY"):
        candidates = [values["GEMINI_API_KEY"]]
    fingerprints = [
        hashlib.sha256(value.encode("utf-8")).hexdigest()
        for value in candidates if value
    ]
    return fingerprints


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--env", type=Path, required=True)
    parser.add_argument("--other-env", type=Path)
    parser.add_argument("--required-keys", type=int, default=10)
    args = parser.parse_args()

    first = key_fingerprints(args.env)
    unique_first = list(dict.fromkeys(first))
    if len(first) != args.required_keys or len(unique_first) != args.required_keys:
        raise SystemExit(
            f"Expected {args.required_keys} configured and unique key fingerprints; "
            f"found configured={len(first)} unique={len(unique_first)}"
        )
    print(f"FIRST_ENV_UNIQUE_FINGERPRINTS={len(unique_first)}")
    print("FIRST_ENV_FINGERPRINT_PREFIXES=" + ",".join(x[:12] for x in unique_first))

    if args.other_env:
        second = key_fingerprints(args.other_env)
        unique_second = list(dict.fromkeys(second))
        if len(second) != args.required_keys or len(unique_second) != args.required_keys:
            raise SystemExit(
                f"Other environment failed count/uniqueness: "
                f"configured={len(second)} unique={len(unique_second)}"
            )
        overlap = set(unique_first) & set(unique_second)
        print(f"SECOND_ENV_UNIQUE_FINGERPRINTS={len(unique_second)}")
        print(f"CROSS_WORKER_FINGERPRINT_OVERLAP={len(overlap)}")
        if overlap:
            raise SystemExit("Gemini key fingerprint overlap detected")
    else:
        print("CROSS_WORKER_COMPARISON=NOT_REQUESTED")
    print("COMPLETE_KEY_VALUES_PRINTED=NO")


if __name__ == "__main__":
    main()
