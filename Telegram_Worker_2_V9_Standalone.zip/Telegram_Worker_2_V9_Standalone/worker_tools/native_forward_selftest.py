#!/usr/bin/env python3
"""Zero-network native-forward contract test."""

import asyncio
import os
import sys
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from native_forward import _metadata_text, try_native_forward
from native_forward_runtime import set_user_client


class FakeClient:
    def __init__(self):
        self.forward_calls = []
        self.detail_calls = []

    async def get_entity(self, target):
        assert target == -100555
        return SimpleNamespace(id=555)

    async def forward_messages(self, entity, message_ids, **kwargs):
        self.forward_calls.append((entity.id, message_ids, kwargs))
        return [SimpleNamespace(id=900 + index) for index, _ in enumerate(message_ids)]

    async def send_message(self, entity, text, **kwargs):
        self.detail_calls.append((entity.id, text, kwargs))


async def main():
    os.environ["NATIVE_QUOTE_FORWARD"] = "true"
    os.environ["NATIVE_QUOTE_TARGET"] = "-100555"
    os.environ["NATIVE_QUOTE_FALLBACK_COPY"] = "true"
    os.environ["NATIVE_QUOTE_DETAILS"] = "true"
    os.environ["NATIVE_QUOTE_CAPTURED_BY"] = "Telegram Worker 2"

    client = FakeClient()
    set_user_client(client)
    rule = SimpleNamespace(
        id=7,
        target_chat=SimpleNamespace(telegram_chat_id="555"),
        source_chat=SimpleNamespace(name="جامعة شقراء"),
        enable_media_type_filter=False,
        enable_media_size_filter=False,
        enable_extension_filter=False,
        enable_push=False,
        message_mode=SimpleNamespace(value="md"),
    )
    messages = [SimpleNamespace(id=12), SimpleNamespace(id=10), SimpleNamespace(id=11)]
    context = SimpleNamespace(
        rule=rule,
        event=SimpleNamespace(message=messages[0], chat_id=-100777),
        media_group_messages=messages,
        skipped_media=[],
        media_blocked=False,
        media_files=[],
        sender_info=(
            "👤 Sender: Student\n"
            "🆔 Telegram ID: 12345\n"
            "👤 Username: @student\n"
            "🔗 Username URL: https://t.me/student"
        ),
        time_info="🕒 Sent: 2026-08-30 20:11:22",
        original_link="🔗 Original message: https://t.me/source/10",
        forwarded_messages=[],
    )
    assert await try_native_forward(context) is True
    _, ids, kwargs = client.forward_calls[0]
    assert ids == [10, 11, 12]
    assert kwargs["from_peer"] == -100777
    assert kwargs["drop_author"] is False
    assert len(client.detail_calls) == 1
    details = client.detail_calls[0][1]
    assert details.startswith("👤 Sender: Student")
    assert "📩 Source: جامعة شقراء" in details
    assert "📥 Captured by: Telegram Worker 2" in details
    assert "🕒 Sent: 2026-08-30 20:11:22" in details
    assert "🔗 Original message: https://t.me/source/10" in details
    assert "ℹ️ Message information" not in details
    assert client.detail_calls[0][2]["reply_to"] == 900
    assert client.detail_calls[0][2]["parse_mode"] is None
    assert len(context.forwarded_messages) == 3

    empty_details = SimpleNamespace(
        rule=SimpleNamespace(source_chat=SimpleNamespace(name="Fallback source")),
        event=SimpleNamespace(chat_id=-100777),
        chat_id=-100777,
        sender_info="",
        time_info="",
        original_link="",
    )
    fallback = _metadata_text(empty_details)
    assert "👤 Sender: Details unavailable" in fallback
    assert "📩 Source: Fallback source" in fallback
    assert "📥 Captured by: Telegram Worker 2" in fallback
    assert "🕒 Sent: Time unavailable" in fallback
    assert "🔗 Original message: Link unavailable" in fallback

    rule.target_chat.telegram_chat_id = "999"
    assert await try_native_forward(context) is None

    print("NATIVE_FORWARD_DROP_AUTHOR_FALSE=OK")
    print("NATIVE_FORWARD_ALBUM_ORDER=OK")
    print("NATIVE_FORWARD_TARGET_GUARD=OK")
    print("NATIVE_FORWARD_METADATA_REPLY=OK")
    print("NATIVE_FORWARD_SCREENSHOT_LAYOUT=OK")
    print("NATIVE_FORWARD_INFORMATION_REPLY_ALWAYS_PRESENT=OK")
    print("NO_NETWORK_REQUESTS=YES")


if __name__ == "__main__":
    asyncio.run(main())
