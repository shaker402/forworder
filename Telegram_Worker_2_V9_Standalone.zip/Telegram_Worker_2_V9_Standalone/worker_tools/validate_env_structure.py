#!/usr/bin/env python3
"""Validate required settings without loading or printing credential values."""

import argparse
import re
from pathlib import Path


def read_env(path):
    values = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line or line.lstrip().startswith("#") or "=" not in line:
            continue
        name, value = line.split("=", 1)
        if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", name.strip()):
            values[name.strip()] = value.strip()
    return values


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--env", type=Path, required=True)
    parser.add_argument("--required-keys", type=int, default=10)
    args = parser.parse_args()
    values = read_env(args.env)

    required = ("API_ID", "API_HASH", "PHONE_NUMBER", "BOT_TOKEN", "USER_ID")
    missing = [name for name in required if not values.get(name)]
    if missing:
        raise SystemExit("Missing required environment names: " + ",".join(missing))

    raw = values.get("GEMINI_API_KEYS", "")
    candidates = []
    for chunk in raw.replace(";", ",").replace("\\n", ",").split(","):
        candidates.extend(chunk.split())
    keys = list(dict.fromkeys(key for key in candidates if key))
    if not keys and values.get("GEMINI_API_KEY"):
        keys = [values["GEMINI_API_KEY"]]
    if len(keys) != args.required_keys:
        raise SystemExit(
            f"Expected {args.required_keys} unique Gemini keys, found {len(keys)}"
        )
    if values.get("GEMINI_API_BASE", "").strip():
        raise SystemExit("GEMINI_API_BASE must be empty for native ten-key rotation")

    output_id = values.get("OUTPUT_GROUP_RAW_ID", "")
    if not output_id or not re.fullmatch(r"-?\d+", output_id):
        raise SystemExit("OUTPUT_GROUP_RAW_ID must be an integer")

    print("ENV_STRUCTURE=OK")
    print(f"GEMINI_UNIQUE_KEYS={len(keys)}")
    print("CREDENTIAL_VALUES_PRINTED=NO")


if __name__ == "__main__":
    main()
