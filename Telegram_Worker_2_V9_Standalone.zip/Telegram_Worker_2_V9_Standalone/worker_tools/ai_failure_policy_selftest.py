#!/usr/bin/env python3
"""Prove queued/provider failures cannot forward the original message."""

import asyncio
import os
import sys
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import filters.ai_filter as ai_filter
from ai.gemini_provider import GeminiQueueDeferred, GeminiReviewRequired


def context():
    message = SimpleNamespace(media=None, id=5, grouped_id=None)
    event = SimpleNamespace(message=message)
    rule = SimpleNamespace(
        id=7,
        is_ai=True,
        enable_ai_upload_image=False,
        is_keyword_after_ai=False,
    )
    return SimpleNamespace(
        rule=rule,
        message_text="wanted candidate",
        original_message_text="wanted candidate",
        event=event,
        chat_id=100,
        is_media_group=False,
        media_files=[],
        media_group_messages=[],
        errors=[],
        should_forward=True,
        ai_state=None,
        shadow_event_key=None,
    )


async def check_failure(exception, expected_state):
    original = ai_filter._ai_handle

    async def failing(*_args, **_kwargs):
        raise exception

    ai_filter._ai_handle = failing
    try:
        item = context()
        result = await ai_filter.AIFilter()._process(item)
        assert result is False
        assert item.should_forward is False
        assert item.ai_state == expected_state
        assert item.message_text == "wanted candidate"
    finally:
        ai_filter._ai_handle = original


async def main():
    os.environ["LOCAL_SHADOW_ENABLED"] = "false"
    await check_failure(GeminiQueueDeferred("a" * 64), "QUEUED")
    await check_failure(
        GeminiReviewRequired("b" * 64, "test"), "REVIEW_REQUIRED"
    )
    await check_failure(RuntimeError("unexpected"), "REVIEW_REQUIRED")
    print("AI_FAILURE_FORWARDING_BLOCKED=OK")
    print("EXPLICIT_QUEUED_STATE=OK")
    print("EXPLICIT_REVIEW_REQUIRED_STATE=OK")


if __name__ == "__main__":
    asyncio.run(main())
