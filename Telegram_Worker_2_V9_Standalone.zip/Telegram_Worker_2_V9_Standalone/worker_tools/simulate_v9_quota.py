#!/usr/bin/env python3
"""Deterministic no-network simulation of the V9 project scheduler."""

import argparse
import heapq


def simulate(messages=200, projects=10, interval=5.0, parallel=3, duration=0.2):
    next_start = [0.0] * projects
    inflight_until = [0.0] * projects
    active = []
    starts = [[] for _ in range(projects)]
    now = 0.0

    for _ in range(messages):
        while True:
            while active and active[0] <= now + 1e-9:
                heapq.heappop(active)
            ready = [
                slot for slot in range(projects)
                if max(next_start[slot], inflight_until[slot]) <= now + 1e-9
            ]
            if ready and len(active) < parallel:
                slot = min(ready, key=lambda item: (next_start[item], item))
                break
            candidates = [
                max(next_start[slot], inflight_until[slot])
                for slot in range(projects)
            ]
            if len(active) >= parallel:
                candidates.append(active[0])
            future = [value for value in candidates if value > now + 1e-9]
            now = min(future)

        starts[slot].append(now)
        next_start[slot] = now + interval
        inflight_until[slot] = now + duration
        heapq.heappush(active, now + duration)

    for project_starts in starts:
        for first, second in zip(project_starts, project_starts[1:]):
            assert second - first >= interval - 1e-9
    return {
        "messages": messages,
        "projects": projects,
        "parallel": parallel,
        "minimum_interval_seconds": interval,
        "modeled_quota_failures": 0,
        "last_start_seconds": round(max(max(values) for values in starts), 3),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--messages", type=int, default=200)
    args = parser.parse_args()
    report = simulate(messages=args.messages)
    if args.messages == 200:
        assert report["last_start_seconds"] <= 100
    for name, value in report.items():
        print(f"{name.upper()}={value}")
    print("NO_NETWORK_REQUESTS=YES")


if __name__ == "__main__":
    main()
