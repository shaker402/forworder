#!/usr/bin/env python3
"""Offline V8 prefilter recall and substring-collision regression test."""

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from filter_policy_v8 import WHITELIST, REGEX_WHITELIST


WANTED = [
    "يااخوان انا اختباري بعد اسبوعين ولاادري وش اذاكر احد عنده شي معين يدلني عليه",
    "الي جابوا أ+ بالفيز كانوا مع مين؟ او اكثر خصوصي ممتاز",
    "في احد عنده حلول كتاب الكتابة الاكاديميه؟",
    "تكفون اللي قد اختبروا قدرات ودرجتهم مرتفعه يساعدوني وش اذاكر",
    "السلام عليكم في احد تخصصه علوم حاسب؟",
    "نقطه رقم ٦ ما فهمتها الله يرضى عليكم احد يشرحه",
    "أبي خصوصي تنظيم كويس",
    "تعرفون برامج نسجل فيها المحاضرات ثم نقدر نفرغ الكلام المسجل؟",
    "السلام عليكم احد يعرف لكانفا ضروري احتاج احد فاهم فيه",
    "احد يعرف موقع ولا بوت يترجم السلايدات",
    "احتاج احد يشرح شبكات ويسوي واجب",
    "اختباري بعد 20 يوم شسويييي اذاكر بنوك منووو",
    "ابي رقم الخصوصيين اسراء وحافظ",
    "السلام عليكم ابي مصادر تدريب للكمي",
    "احد يعرف منحة مفتوحة للماجستير؟",
    "ابحث عن زميل امن سيبراني يشارك معي في بحث",
    "عندي كويز قواعد بيانات و ابغى مصادر تدريب",
    "احد عنده ملخص او اي شي يخص مادة تحليل وتصميم الوظائف",
    "محتاج مشارك في مشروع التخرج",
    "من يعرف مدرس بايثون ممتاز؟",
]


# Each string previously collided with a short literal keyword. These tests
# contain no other target term, so a match would prove the collision returned.
MUST_NOT_MATCH = [
    "الموعد يوم الاحد الساعة الثامنة",
    "تم تحديث الجدول الميداني",
    "التقويم التدريبي",
    "موعد حفل التخرج غدا",
    "موعد بداية التدريب التعاوني",
]


compiled_regex = [re.compile(pattern, re.IGNORECASE) for pattern in REGEX_WHITELIST]


def matches(text):
    folded = text.casefold()
    literal_hits = [kw for kw in WHITELIST if str(kw).casefold() in folded]
    regex_hits = [pattern.pattern for pattern in compiled_regex if pattern.search(text)]
    return literal_hits + regex_hits


missing = [(message, matches(message)) for message in WANTED if not matches(message)]
collisions = [(message, matches(message)) for message in MUST_NOT_MATCH if matches(message)]

print("LOCAL_PREFILTER_LITERAL_TERMS=", len(WHITELIST))
print("LOCAL_PREFILTER_REGEX_TERMS=", len(REGEX_WHITELIST))
print("IMPORTANT_SELFTEST_MESSAGES=", len(WANTED))
print("IMPORTANT_MESSAGES_MATCHING_PREFILTER=", len(WANTED) - len(missing))
print("COLLISION_SELFTEST_MESSAGES=", len(MUST_NOT_MATCH))
print("COLLISION_MESSAGES_REJECTED_LOCALLY=", len(MUST_NOT_MATCH) - len(collisions))

if missing:
    print("ERROR: important examples that would be lost before AI:")
    for message, _ in missing:
        print(" -", message)
    raise SystemExit(1)

if collisions:
    print("ERROR: substring collisions still match the local prefilter:")
    for message, hits in collisions:
        print(" -", message, "=>", hits)
    raise SystemExit(1)

print("PREFILTER_RECALL_AND_COLLISION_SELFTEST=OK")
