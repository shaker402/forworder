"""Lazy AI-provider routing so one optional SDK cannot break every provider."""

from utils.constants import DEFAULT_AI_MODEL
from utils.settings import load_ai_models


async def get_ai_provider(model=None):
    model = model or DEFAULT_AI_MODEL
    providers_config = load_ai_models(type="dict")

    provider_name = next(
        (
            name
            for name, models in providers_config.items()
            if model in models
        ),
        None,
    )
    if provider_name is None:
        raise ValueError(f"不支持的模型: {model}")

    if provider_name == "openai":
        from .openai_provider import OpenAIProvider
        return OpenAIProvider()
    if provider_name == "gemini":
        from .gemini_provider import GeminiProvider
        return GeminiProvider()
    if provider_name == "deepseek":
        from .deepseek_provider import DeepSeekProvider
        return DeepSeekProvider()
    if provider_name == "qwen":
        from .qwen_provider import QwenProvider
        return QwenProvider()
    if provider_name == "grok":
        from .grok_provider import GrokProvider
        return GrokProvider()
    if provider_name == "claude":
        from .claude_provider import ClaudeProvider
        return ClaudeProvider()
    raise ValueError(f"不支持的 AI provider: {provider_name}")


__all__ = ["get_ai_provider"]
