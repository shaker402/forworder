"""
Core functionality
""" 