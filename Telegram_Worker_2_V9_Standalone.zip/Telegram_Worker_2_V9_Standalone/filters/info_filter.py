import logging
import os
import pytz

from filters.base_filter import BaseFilter
from telethon.tl import types

logger = logging.getLogger(__name__)


class InfoFilter(BaseFilter):
    """
    Add useful metadata to forwarded messages:

    - sender display name
    - sender Telegram numeric ID
    - sender @username
    - sender https://t.me/username URL
    - original message URL
    - original message timestamp
    """

    async def _process(self, context):
        rule = context.rule
        event = context.event

        try:
            # ============================================================
            # ORIGINAL MESSAGE LINK
            # ============================================================

            if rule.is_original_link:
                try:
                    chat = await event.get_chat()
                    chat_username = getattr(chat, "username", None)

                    # Public groups/channels have the most portable link.
                    if chat_username:
                        original_link = (
                            f"https://t.me/{chat_username}/"
                            f"{event.message.id}"
                        )
                    elif isinstance(chat, types.Channel):
                        # Official private-post links work for channels and
                        # supergroups. Use the raw MTProto channel ID directly.
                        original_link = (
                            f"https://t.me/c/{int(chat.id)}/"
                            f"{event.message.id}"
                        )
                    else:
                        # Legacy basic groups do not have an official per-message
                        # t.me/c private-post URL. Generating one produces the
                        # misleading 'no access' error even for members.
                        original_link = None

                    if original_link:
                        if (
                            hasattr(rule, "original_link_template")
                            and rule.original_link_template
                        ):
                            link_info = rule.original_link_template
                            link_info = link_info.replace(
                                "{original_link}",
                                original_link,
                            )
                            context.original_link = f"\n\n{link_info}"
                        else:
                            context.original_link = (
                                f"\n\n🔗 Original message: "
                                f"{original_link}"
                            )
                    else:
                        context.original_link = (
                            "\n\n🔗 Original message: "
                            "link unavailable for legacy basic group"
                        )

                    logger.debug(
                        f"Original message link: {original_link or 'legacy-basic-group'}"
                    )

                except Exception as e:
                    logger.error(
                        f"Error creating original message link: {e}"
                    )


            # ============================================================
            # SENDER INFORMATION
            # ============================================================

            if rule.is_original_sender:
                try:
                    sender_name = "Unknown Sender"
                    sender_id = "Unknown"

                    sender_username = None
                    sender_username_display = "No public username"
                    sender_username_url = "No public username URL"

                    sender = None

                    # ----------------------------------------------------
                    # MESSAGE SENT AS A CHANNEL
                    # ----------------------------------------------------

                    if (
                        hasattr(event.message, "sender_chat")
                        and event.message.sender_chat
                    ):
                        sender = event.message.sender_chat

                    # ----------------------------------------------------
                    # NORMAL USER / SENDER
                    # ----------------------------------------------------

                    if sender is None:
                        try:
                            sender = await event.get_sender()
                        except Exception as e:
                            logger.warning(
                                f"Could not resolve sender entity: {e}"
                            )

                    # ----------------------------------------------------
                    # EXTRACT DETAILS
                    # ----------------------------------------------------

                    if sender is not None:
                        sender_id = getattr(
                            sender,
                            "id",
                            "Unknown",
                        )

                        if getattr(sender, "title", None):
                            sender_name = sender.title

                        else:
                            first_name = (
                                getattr(sender, "first_name", None)
                                or ""
                            )

                            last_name = (
                                getattr(sender, "last_name", None)
                                or ""
                            )

                            sender_name = (
                                f"{first_name} {last_name}"
                            ).strip()

                            if not sender_name:
                                sender_name = "Unknown Sender"

                        sender_username = getattr(
                            sender,
                            "username",
                            None,
                        )

                        if sender_username:
                            sender_username_display = (
                                f"@{sender_username}"
                            )

                            sender_username_url = (
                                f"https://t.me/{sender_username}"
                            )

                    # ----------------------------------------------------
                    # FALLBACK ID
                    # ----------------------------------------------------

                    if sender_id == "Unknown":
                        if getattr(event, "sender_id", None):
                            sender_id = event.sender_id

                    # ----------------------------------------------------
                    # CUSTOM TEMPLATE
                    # ----------------------------------------------------

                    if (
                        hasattr(rule, "userinfo_template")
                        and rule.userinfo_template
                    ):
                        user_info = rule.userinfo_template

                        user_info = user_info.replace(
                            "{name}",
                            str(sender_name),
                        )

                        user_info = user_info.replace(
                            "{id}",
                            str(sender_id),
                        )

                        user_info = user_info.replace(
                            "{username}",
                            sender_username_display,
                        )

                        user_info = user_info.replace(
                            "{username_url}",
                            sender_username_url,
                        )

                        context.sender_info = (
                            f"{user_info}\n\n"
                        )

                    # ----------------------------------------------------
                    # DEFAULT FORMAT
                    # ----------------------------------------------------

                    else:
                        context.sender_info = (
                            f"👤 Sender: {sender_name}\n"
                            f"🆔 Telegram ID: {sender_id}\n"
                            f"👤 Username: "
                            f"{sender_username_display}\n"
                            f"🔗 Username URL: "
                            f"{sender_username_url}\n\n"
                        )

                    logger.debug(
                        "Added sender information: "
                        f"name={sender_name}, "
                        f"id={sender_id}, "
                        f"username={sender_username_display}"
                    )

                except Exception as e:
                    logger.error(
                        f"Error obtaining sender information: {e}"
                    )


            # ============================================================
            # ORIGINAL TIME
            # ============================================================

            if rule.is_original_time:
                try:
                    timezone = pytz.timezone(
                        os.getenv(
                            "DEFAULT_TIMEZONE",
                            "Asia/Shanghai",
                        )
                    )

                    local_time = (
                        event.message.date.astimezone(timezone)
                    )

                    formatted_time = local_time.strftime(
                        "%Y-%m-%d %H:%M:%S"
                    )

                    if (
                        hasattr(rule, "time_template")
                        and rule.time_template
                    ):
                        time_info = rule.time_template.replace(
                            "{time}",
                            formatted_time,
                        )

                        context.time_info = (
                            f"\n\n{time_info}"
                        )

                    else:
                        context.time_info = (
                            f"\n\n🕒 Sent: "
                            f"{formatted_time}"
                        )

                    logger.info(
                        f"Added original time: {formatted_time}"
                    )

                except Exception as e:
                    logger.error(
                        f"Error processing time information: {e}"
                    )

            return True

        finally:
            pass
