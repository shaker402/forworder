# Build provenance

## Worker 2 V9 inputs

| Input | SHA-256 | Use |
|---|---|---|
| `Telegram_Worker_2_V8_Standalone_Fixed (1)(1).zip` | `59a9f8bf89532005ee4683a01e20d28dd5f98b6891da749031a4f575ffd92337` | Validated Worker 2 baseline, coexistence behavior, and identity isolation |
| `Telegram_Worker_1_V9_Standalone.zip` | `f831c12367d1978ac7dcee488556cd2cce2defc6562d41bea146e0f245073df8` | Previously validated durable queue, retry, explicit-state, deduplication, cache, and shadow implementation |
| `Shaker_Independent_Project_AI_Plan_V2(2).zip` | `ec28e99c333c83d1fd158e3119c83ebbb135557209335450be7d5eabbb64591a` | Weak TF-IDF shadow model and evaluation design |

The supplied `worker2.env` and installed-Worker-1 environment sample were used
only for structural and SHA-256 key-fingerprint validation. Each contains ten
unique Gemini keys and the two fingerprint sets have zero overlap. Neither
environment file nor any complete credential value is included in this source
tree or deliverable.

The V9 implementation was ported onto the Worker 2 V8 baseline while preserving
Worker 2's container, image, project directory, Telegram runtime lock,
attribution label, mutable volumes, and same-destination coexistence checks.
Cross-worker Gemini validation now compares per-key SHA-256 fingerprints instead
of complete environment strings.

The queue, retry, fail-safe state, context-cache, delivery-deduplication, and
shadow telemetry changes are contained directly in this standalone source. No
GitHub checkout and no live Gemini, Telegram, or model-provider request was used
for this build.

## Earlier standalone provenance

The Worker 2 V8 baseline records its own rebuild chain from the user-supplied
Heavrnl/TelegramForwarder 1.7.2 archive and earlier Worker 2 migration inputs.
The upstream documentation remains in `UPSTREAM_README.md` and the GPL license
remains in `LICENSE`.
