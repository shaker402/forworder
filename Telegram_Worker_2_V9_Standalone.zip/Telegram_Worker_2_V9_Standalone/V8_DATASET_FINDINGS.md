# Telegram Worker V8 — Dataset Findings and Validation Status

## Source corpus

- Archive SHA-256: `a804b77c03618e9cc1d7d4ac671c597ec0f1c91a017762705287e002f88bfe08`
- JSON messages parsed: **351,061**
- JSON parse errors: **0**
- Date range: **2026-01-29 to 2026-06-10**
- Non-empty text messages: **351,027**
- Arabic messages: **327,077**
- Mixed Arabic/English messages: **23,948**
- Normalized unique non-empty texts: **308,676**
- Duplicate groups: **13,323**
- Repeated copies beyond the first occurrence: **42,351**

The corpus is the output of an earlier keyword filter. It is suitable for
studying precision among candidates, duplicates, advertisements, and hard
negative patterns. It cannot measure messages missed before the old whitelist,
so it cannot by itself establish end-to-end recall.

## Measured prefilter problems

- `احد` occurred as a substring in 168,522 messages, but only 122,493 contained
  it as a standalone word. At least 10,095 contained `الاحد` (Sunday).
- `تخرج` appeared in 43,848 messages; 12,877 also contained ceremony,
  document, date, or similar administrative language.
- `تدريب` appeared in 36,744 messages; 9,053 also contained internship/co-op
  language.
- `ميد` appeared in 5,474 messages; 990 contained `ميداني`.
- `تعاون` was heavily contaminated by `التدريب التعاوني`.

V8 therefore represents `احد/أحد`, `ميد`, `تدريب`, `تخرج`, and `تعاون` as
boundary-aware regular expressions rather than raw substrings.

Applied offline to the historical export, the original terms matched 339,936
messages and V8 matched 261,312. This removes 79,134 old candidates before AI,
an estimated **23.28% reduction in Gemini calls**, while adding 510 candidates
through new high-signal academic/technical terms. This is a cost/load estimate,
not proof of recall, because the export contains no messages rejected by the
older upstream filter.

## Duplicate evidence

The largest normalized duplicate groups contained 1,146, 823, 776, 591, and
563 copies. Repeated medical-document advertisements and academic-service ads
were prominent. V8 stores only a SHA-256-derived cache key plus `KEEP/#SKIP` in
a persistent SQLite decision cache. It does not store message text in the
cache. A prompt/model change automatically changes the key. Messages shorter
than 60 normalized characters and messages with images bypass the cache so
context-sensitive short replies are always classified afresh.

## V8 semantic policy

V8 keeps genuine requesters seeking academic/technical help, tutors,
course/exam material, scholarship eligibility/application help, or real
research/project collaboration. It rejects providers, advertisements,
paid-authorship promotions, answers, administration, university IT support,
transport/logistics, job/internship announcements, scholarship broadcasts,
and vague keyword-only messages.

The direct Gemini REST path now uses a Gemini system instruction and wraps the
Telegram message as untrusted data. The model outputs only `KEEP` or `#SKIP`.
The provider maps `KEEP` back to the untouched original message, preserving the
existing native Telegram-forwarding path and preventing model rewrites.

## Validation completed without API calls

- All changed Python files compile.
- Twenty wanted recall cases reach the local prefilter.
- Five known substring-collision cases do not reach Gemini.
- Sixty-four frozen wanted/unwanted regression cases validate structurally.
- Contract tests verify `KEEP/#SKIP`, malformed-output rejection, contact
  redaction in cache keys, cache hits, system-instruction separation, and the
  eight-token classifier output limit.

## Validation still required on the deployed VPS

No Gemini key from the uploaded `.env` was read or used during this analysis.
Therefore, no fabricated Gemini accuracy percentage is reported. After the V8
patch is installed, run:

```bash
cd /opt/TelegramForwarder-worker2
docker compose exec -T telegram-forwarder \
  python /app/worker_tools/evaluate_gemini_filter.py \
  --output /app/logs/gemini_v8_regression_report.json
```

This makes 64 intentional model calls with fail-open and caching disabled and
reports precision, recall, specificity, F1, accuracy, and exact mistakes.

For a trained local classifier, first human-label the supplied 1,800-record
privacy-redacted review sample. Heuristic labels are never treated as gold
truth. A later time/group-split sample of unfiltered source traffic is still
required before a local model may block messages in production.
