"""Runtime access to the already-authenticated Telegram user client."""

_user_client = None


def set_user_client(client):
    global _user_client
    _user_client = client


def get_user_client():
    return _user_client
