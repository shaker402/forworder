# Worker 2 V9 validation report

Validation date: 2026-08-31 UTC

## Input and configuration checks

- The supplied Worker 2 V8 Fixed archive passed ZIP integrity and its internal
  manifest before modification.
- Worker 2 and Worker 1 each passed structural validation with exactly ten
  configured and ten unique Gemini SHA-256 key fingerprints.
- Cross-worker fingerprint intersection is zero. Complete key values were never
  printed or copied into this project.
- Thirty sensitive values from the two supplied environments were byte-scanned
  across the Worker 2 V9 source and external scripts: zero matches. A generic
  AQ key-pattern scan also returned zero matches. No environment, database, or
  Telethon session file is included.
- The Worker 2 installer forces GEMINI_MAX_KEY_ATTEMPTS=1,
  GEMINI_MAX_PARALLEL_REQUESTS=3, and
  MAX_CONCURRENT_MESSAGE_HANDLERS=10; it contains no assignment that restores
  ten immediate attempts or enables fail-open.

## Passed zero-network tests

- All Python files parse and install_worker2.sh,
  install_worker2_same_vps.sh, and worker2_follow_script_fix.sh pass bash syntax
  validation.
- The V9 Gemini test passed ten persistent project buckets, 429 delayed requeue
  without immediate project cascade, Retry-After, authentication quarantine and
  bounded failover, malformed-output review, three-call global concurrency,
  per-project spacing, terminal queue states, and nine-key rejection.
- Dummy key material was absent from the SQLite queue files. Production request
  URLs do not contain keys; credentials are sent only in the API header.
- The 200-candidate scheduler simulation produced zero modeled quota failures
  and a final dispatch start at 95.6 seconds with ten projects, five-second
  spacing, and three global in-flight calls.
- Injected QUEUED, REVIEW_REQUIRED, and unexpected provider failures all
  stopped AIFilter; none forwarded the unchanged candidate.
- Classifier-cache tests passed complete filled-context, policy/model, and
  worker/source namespace separation as well as contact redaction.
- Persistent Telegram delivery tests passed claim, busy, release/reclaim, and
  completed-delivery suppression across independent SQLite connections.
- The included Shaker weak TF-IDF model loaded in shadow-only mode. Accepted and
  sampled-rejected schema, pseudonymous source/message identity, contact
  redaction, Gemini/effective states, and human review-label storage passed.
- Existing V8 tests passed: all 20 important wanted examples reached the
  prefilter, all five known substring collisions were rejected, and the frozen
  64-case regression file validated.
- Native forwarding, album ordering, target guarding, metadata replies,
  information reply fallback, detached database rules, bulk policy migration,
  destination feedback exclusion, and auto-bind cloning all passed.
- Runtime verification observed ten scheduler buckets, three global Gemini
  calls, 12 RPM/project, Worker 2 namespaces, 100 literal whitelist entries,
  five regex entries, one blacklist entry, and zero checked-out DB connections.
- Worker 2 coexistence tests passed distinct image, container, project path,
  session lock, and mutable mounts, plus same-destination preflight and
  fingerprint-only cross-worker key comparison.
- Mocked installer rollback restored the previous Worker 2 tree after a forced
  build failure. The success path preserved credential values, database and
  session state, forced the V9 settings, and retained a timestamped backup.
- The follow-up script environment transformer copied exactly ten source keys
  without printing them, preserved Telegram/destination settings, forced the V9
  limits, and retained zero overlap with Worker 1.

## Deployment-time validation

This workspace has no Docker daemon and made no live Telegram or Gemini calls.
The same-VPS wrapper skips live Gemini health by default; live health calls
require explicit WORKER2_RUN_LIVE_GEMINI_HEALTH=true.

On the VPS, the installer repeats zero-network tests inside the final image,
validates Telegram authorization and the destination, starts only Worker 2,
waits for health, verifies queue/shadow/runtime state, and confirms Worker 1 was
not restarted. A failed Worker 2 deployment restores its previous project.

## Operational limitation made explicit

The SQLite queue preserves pending and review work and never turns provider
failure into a forward. If the entire process is interrupted after Telegram has
stopped delivering an event, the queue item remains observable for manual
review; V9 does not claim autonomous reconstruction of an orphaned Telegram
event.

The weak local model is not authorized to keep or skip production messages.
Promotion requires several thousand representative human labels and later-time
plus source-group holdout evaluation against an Arabic transformer.
