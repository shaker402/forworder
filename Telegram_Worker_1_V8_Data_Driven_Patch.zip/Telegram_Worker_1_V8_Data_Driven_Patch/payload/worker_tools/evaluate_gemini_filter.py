#!/usr/bin/env python3
"""Evaluate the live Gemini V8 filter on a frozen labeled JSONL set.

The evaluator disables fail-open and the decision cache so API errors cannot be
misreported as wanted classifications and every record exercises the model.
"""

import argparse
import asyncio
import collections
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from dotenv import load_dotenv

load_dotenv(ROOT / ".env", override=False)

from ai.gemini_provider import GeminiProvider
from filter_policy_v8 import MODEL, PROMPT


def read_cases(path, limit=None, category=None):
    cases = []
    with path.open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, 1):
            if not line.strip():
                continue
            case = json.loads(line)
            if case.get("label") not in {"wanted", "unwanted"}:
                raise ValueError(f"line {line_number}: label must be wanted/unwanted")
            if not isinstance(case.get("text"), str) or not case["text"].strip():
                raise ValueError(f"line {line_number}: missing text")
            if category and case.get("category") != category:
                continue
            cases.append(case)
            if limit and len(cases) >= limit:
                break
    return cases


def ratio(numerator, denominator):
    return round(numerator / denominator, 6) if denominator else None


async def evaluate(cases, concurrency):
    os.environ["GEMINI_FAIL_OPEN"] = "false"
    os.environ["GEMINI_CLASSIFIER_CACHE"] = "false"

    provider = GeminiProvider()
    await provider.initialize(model=MODEL)
    semaphore = asyncio.Semaphore(concurrency)

    async def classify(case):
        async with semaphore:
            try:
                result = await provider.process_message(
                    case["text"],
                    prompt=PROMPT,
                    model=MODEL,
                )
                prediction = "unwanted" if result.strip() == "#SKIP" else "wanted"
                return {**case, "prediction": prediction, "error": None}
            except Exception as exc:
                return {
                    **case,
                    "prediction": None,
                    "error": f"{type(exc).__name__}: {exc}",
                }

    return await asyncio.gather(*(classify(case) for case in cases))


def build_report(results):
    tp = fp = tn = fn = 0
    errors = []
    mistakes = []
    category_totals = collections.Counter()
    category_errors = collections.Counter()

    for result in results:
        category = result.get("category") or "unknown"
        category_totals[category] += 1
        if result["error"]:
            errors.append({
                "id": result.get("id"),
                "category": category,
                "error": result["error"],
            })
            category_errors[category] += 1
            continue

        actual = result["label"]
        predicted = result["prediction"]
        if actual == "wanted" and predicted == "wanted":
            tp += 1
        elif actual == "unwanted" and predicted == "wanted":
            fp += 1
        elif actual == "unwanted" and predicted == "unwanted":
            tn += 1
        elif actual == "wanted" and predicted == "unwanted":
            fn += 1

        if actual != predicted:
            mistakes.append({
                "id": result.get("id"),
                "category": category,
                "actual": actual,
                "prediction": predicted,
                "text": result["text"],
            })

    evaluated = tp + fp + tn + fn
    return {
        "model": MODEL,
        "policy": "SHAKER_WANTED_V8",
        "cases_total": len(results),
        "cases_evaluated": evaluated,
        "api_errors": len(errors),
        "confusion_matrix": {"tp": tp, "fp": fp, "tn": tn, "fn": fn},
        "metrics": {
            "precision": ratio(tp, tp + fp),
            "recall": ratio(tp, tp + fn),
            "specificity": ratio(tn, tn + fp),
            "accuracy": ratio(tp + tn, evaluated),
            "f1": ratio(2 * tp, 2 * tp + fp + fn),
        },
        "category_totals": dict(category_totals),
        "category_api_errors": dict(category_errors),
        "mistakes": mistakes,
        "errors": errors,
    }


async def async_main(args):
    cases = read_cases(args.dataset, args.limit, args.category)
    if not cases:
        raise SystemExit("No matching evaluation cases")
    if args.validate_only:
        print(f"VALID_CASES={len(cases)}")
        return 0

    results = await evaluate(cases, args.concurrency)
    report = build_report(results)
    rendered = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        args.output.write_text(rendered, encoding="utf-8")
        print(f"REPORT={args.output}")
    print(rendered, end="")
    return 1 if report["api_errors"] else 0


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--dataset",
        type=Path,
        default=ROOT / "worker_tools" / "regression_cases_v8.jsonl",
    )
    parser.add_argument("--output", type=Path)
    parser.add_argument("--limit", type=int)
    parser.add_argument("--category")
    parser.add_argument("--concurrency", type=int, default=5)
    parser.add_argument("--validate-only", action="store_true")
    args = parser.parse_args()
    if args.concurrency < 1 or args.concurrency > 10:
        parser.error("--concurrency must be between 1 and 10")
    raise SystemExit(asyncio.run(async_main(args)))


if __name__ == "__main__":
    main()
