#!/usr/bin/env python3
import os
import sys
from pathlib import Path

# Running this file directly sets sys.path to /app/worker_tools. Add /app so
# imports from ai/, models/, filters/, etc. resolve exactly as main.py sees them.
APP_ROOT = Path(__file__).resolve().parents[1]
if str(APP_ROOT) not in sys.path:
    sys.path.insert(0, str(APP_ROOT))

from dotenv import load_dotenv
load_dotenv('/app/.env', override=True)

from ai.gemini_provider import (
    MULTI_KEY_GEMINI_POOL,
    CLASSIFIER_CONTRACT_V8,
    _load_api_keys,
)
from filter_policy_v8 import PROMPT, WHITELIST, REGEX_WHITELIST
from models.models import get_session, Chat, ForwardRule, Keyword

if MULTI_KEY_GEMINI_POOL is not True:
    raise SystemExit('Direct multi-key Gemini provider is not loaded')

keys = _load_api_keys()
if len(keys) != 10 or len(set(keys)) != 10:
    raise SystemExit(f'Expected 10 unique Gemini keys, found {len(keys)}')

if os.getenv('GEMINI_POOL_URL', '').strip():
    raise SystemExit('Unexpected GEMINI_POOL_URL: this worker must be standalone')

target_id = os.getenv('OUTPUT_GROUP_RAW_ID', '').strip()
s = get_session()
try:
    target = s.query(Chat).filter(Chat.telegram_chat_id == target_id).first()
    if target is None:
        raise SystemExit(f'Target raw DB ID not found: {target_id}')

    rules = s.query(ForwardRule).filter(ForwardRule.target_chat_id == target.id).all()
    if not rules:
        raise SystemExit('No forwarding rules target AI_filter')

    first = rules[0]
    literal_whitelist = s.query(Keyword).filter(
        Keyword.rule_id == first.id,
        Keyword.is_blacklist == False,
        Keyword.is_regex == False,
    ).count()
    regex_whitelist = s.query(Keyword).filter(
        Keyword.rule_id == first.id,
        Keyword.is_blacklist == False,
        Keyword.is_regex == True,
    ).count()
    blacklist = s.query(Keyword).filter(
        Keyword.rule_id == first.id,
        Keyword.is_blacklist == True,
    ).count()

    if CLASSIFIER_CONTRACT_V8 not in PROMPT:
        raise SystemExit('V8 classifier contract marker is missing from prompt')
    if literal_whitelist != len(WHITELIST):
        raise SystemExit(
            f'Literal whitelist mismatch: runtime={literal_whitelist} '
            f'policy={len(WHITELIST)}'
        )
    if regex_whitelist != len(REGEX_WHITELIST):
        raise SystemExit(
            f'Regex whitelist mismatch: runtime={regex_whitelist} '
            f'policy={len(REGEX_WHITELIST)}'
        )

    print('RUNTIME_VERIFY=OK')
    print('LOCAL_GEMINI_10_KEY_POOL=', MULTI_KEY_GEMINI_POOL)
    print('GEMINI_KEYS=', len(keys))
    print('GEMINI_MAX_PARALLEL=', os.getenv('GEMINI_MAX_PARALLEL_REQUESTS'))
    print('GEMINI_MAX_ATTEMPTS=', os.getenv('GEMINI_MAX_KEY_ATTEMPTS'))
    print('GEMINI_TIMEOUT_SECONDS=', os.getenv('GEMINI_REQUEST_TIMEOUT_SECONDS'))
    print('GEMINI_FAIL_OPEN=', os.getenv('GEMINI_FAIL_OPEN'))
    print('GEMINI_CLASSIFIER_CACHE=', os.getenv('GEMINI_CLASSIFIER_CACHE', 'true'))
    print('GEMINI_CLASSIFIER_CACHE_TTL_DAYS=', os.getenv('GEMINI_CLASSIFIER_CACHE_TTL_DAYS', '30'))
    print('GEMINI_CLASSIFIER_CACHE_MIN_CHARS=', os.getenv('GEMINI_CLASSIFIER_CACHE_MIN_CHARS', '60'))
    print('AI_ENABLED=', bool(first.is_ai))
    print('POST_AI_KEYWORD_CHECK=', bool(first.is_keyword_after_ai))
    print('TARGET_NAME=', target.name)
    print('TARGET_RAW_ID=', target.telegram_chat_id)
    print('RULES=', len(rules))
    print('SAMPLE_LITERAL_WHITELIST=', literal_whitelist)
    print('SAMPLE_REGEX_WHITELIST=', regex_whitelist)
    print('SAMPLE_BLACKLIST=', blacklist)
    print('NATIVE_QUOTE_TARGET=', os.getenv('NATIVE_QUOTE_TARGET'))
    print('WORKER_LABEL=', os.getenv('WORKER_LABEL'))
finally:
    s.close()
