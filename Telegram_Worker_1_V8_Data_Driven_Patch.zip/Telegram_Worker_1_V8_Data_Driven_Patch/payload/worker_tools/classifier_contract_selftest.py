#!/usr/bin/env python3
"""Zero-network V8 Gemini classifier contract and cache self-test."""

import os
import tempfile

from ai.gemini_provider import (
    CLASSIFIER_CONTRACT_V8,
    GeminiRequestError,
    _cache_get,
    _cache_put,
    _classifier_cache_key,
    _classifier_cacheable,
    _classifier_mode,
    _normalize_classifier_result,
)


prompt = CLASSIFIER_CONTRACT_V8 + "\nOutput exactly KEEP or #SKIP"
original = "احد يعرف خصوصي يشرح الجبر؟"

assert _classifier_mode(prompt)
assert not _classifier_mode("ordinary summary prompt")
assert _normalize_classifier_result("KEEP", original) == ("KEEP", original)
assert _normalize_classifier_result("  #skip\n", original) == ("#SKIP", "#SKIP")
assert _normalize_classifier_result("```\nKEEP\n```", original) == ("KEEP", original)

try:
    _normalize_classifier_result("The message is relevant", original)
except GeminiRequestError:
    pass
else:
    raise AssertionError("Malformed classifier output was accepted")

key_a = _classifier_cache_key("model", prompt, "للتواصل +967 777 111 222")
key_b = _classifier_cache_key("model", prompt, "للتواصل +967 733 999 888")
assert key_a == key_b, "Contact redaction must stabilize advertisement cache keys"
user_key_a = _classifier_cache_key("model", prompt, "للطلب@SellerOne")
user_key_b = _classifier_cache_key("model", prompt, "للطلب@SellerTwo")
assert user_key_a == user_key_b, "Username redaction must stabilize cache keys"
assert key_a != _classifier_cache_key("model", prompt + " changed", original)
assert not _classifier_cacheable("خصوصي")
assert _classifier_cacheable(
    "نوفر خدمات بحوث ومشاريع تخرج وواجبات وتقارير وعروض للتواصل واتساب [PHONE]"
)

with tempfile.TemporaryDirectory() as directory:
    os.environ["GEMINI_CLASSIFIER_CACHE"] = "true"
    os.environ["GEMINI_CLASSIFIER_CACHE_PATH"] = os.path.join(directory, "cache.sqlite3")
    _cache_put(key_a, "#SKIP")
    assert _cache_get(key_a) == "#SKIP"

print("CLASSIFIER_CONTRACT_V8=OK")
print("CLASSIFIER_CACHE_REDACTION=OK")
print("NO_NETWORK_REQUESTS=YES")
