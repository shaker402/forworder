TELEGRAM WORKER 1 — V8 DATA-DRIVEN PATCH
========================================

Purpose
-------
Upgrade the installed V7 worker at /opt/TelegramForwarder-worker1 without
replacing or printing its .env, Telegram database, login sessions, or API keys.

Install
-------
1. Copy/extract this directory on the VPS.
2. Enter the directory.
3. Run:

   chmod +x apply_v8_patch.sh
   sudo ./apply_v8_patch.sh

Safety
------
- The patch verifies its own payload before changing the worker.
- It accepts only the exact supplied V7 runtime files or an already-applied V8.
  If local runtime files were manually changed, it stops instead of overwriting.
- It stops the worker before copying the database backup.
- It creates a timestamped backup beside the worker directory.
- On failure it preserves the failed V8 state, restores V7 files/database, and
  attempts to restart the worker.
- It never copies, rewrites, displays, or packages .env.

V8 behavior
-----------
- Boundary-aware prefilter prevents measured Arabic substring collisions.
- Genuine academic/technical/scholarship/research requests are kept.
- Providers, ads, administration, IT support, transport, job/internship and
  scholarship announcements, vague messages, and paid-authorship offers are rejected.
- Gemini receives a trusted system instruction and untrusted message content.
- Gemini outputs KEEP/#SKIP only; KEEP restores the untouched original message.
- Privacy-safe SQLite decision cache stores hashes and decisions, not text.
- Historical replay estimates 23.28% fewer Gemini calls before duplicate-cache savings.

Optional live Gemini regression test
------------------------------------
The installer performs zero-network tests only. To measure the configured model
on 64 frozen cases (64 API calls), run after successful installation:

cd /opt/TelegramForwarder-worker1
docker compose exec -T telegram-forwarder \
  python /app/worker_tools/evaluate_gemini_filter.py \
  --output /app/logs/gemini_v8_regression_report.json

The report contains precision, recall, specificity, F1, accuracy, API errors,
and exact mistakes. Fail-open and the decision cache are disabled for this test.

