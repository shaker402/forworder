#!/usr/bin/env bash
set -Eeuo pipefail

PATCH_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PAYLOAD_DIR="$PATCH_DIR/payload"
WORKER_DIR="${TELEGRAM_WORKER_DIR:-/opt/TelegramForwarder-worker1}"
SERVICE="telegram-forwarder"
CONTAINER="telegram-forwarder-worker1"
BACKUP_DIR=""
ROLLBACK_READY=0
WORKER_STOPPED=0

log()  { printf '\n\033[1;36m[+] %s\033[0m\n' "$*"; }
warn() { printf '\n\033[1;33m[!] %s\033[0m\n' "$*" >&2; }
die()  {
  printf '\n\033[1;31m[ERROR] %s\033[0m\n' "$*" >&2
  restore_on_error 1
}

payload_files() {
  (cd "$PAYLOAD_DIR" && find . -type f -print | sed 's#^./##' | sort)
}

restore_on_error() {
  prior_rc=$?
  rc="${1:-$prior_rc}"
  trap - ERR
  if [ "$ROLLBACK_READY" -eq 1 ] && [ -n "$BACKUP_DIR" ]; then
    warn "V8 patch failed; restoring the timestamped V7 backup."
    set +e
    mkdir -p "$BACKUP_DIR/failed-v8-files"
    while IFS= read -r relative; do
      [ -n "$relative" ] || continue
      if [ -f "$BACKUP_DIR/files/$relative" ]; then
        mkdir -p "$WORKER_DIR/$(dirname "$relative")"
        cp -a "$BACKUP_DIR/files/$relative" "$WORKER_DIR/$relative"
      elif [ -e "$WORKER_DIR/$relative" ]; then
        mkdir -p "$BACKUP_DIR/failed-v8-files/$(dirname "$relative")"
        mv "$WORKER_DIR/$relative" "$BACKUP_DIR/failed-v8-files/$relative"
      fi
    done < <(payload_files)

    if [ -d "$BACKUP_DIR/db" ]; then
      if [ -d "$WORKER_DIR/db" ]; then
        mv "$WORKER_DIR/db" "$BACKUP_DIR/db.failed-v8"
      fi
      cp -a "$BACKUP_DIR/db" "$WORKER_DIR/db"
    fi

    cd "$WORKER_DIR" || true
    docker compose up -d --force-recreate "$SERVICE" || true
    warn "Rollback attempted. Backup: $BACKUP_DIR"
  elif [ "$WORKER_STOPPED" -eq 1 ]; then
    set +e
    cd "$WORKER_DIR" || true
    docker compose up -d --force-recreate "$SERVICE" || true
    warn "The worker was restarted after an error before file installation."
  fi
  exit "$rc"
}

trap restore_on_error ERR

[ "${EUID:-$(id -u)}" -eq 0 ] || die "Run this patch as root."
[ -d "$PAYLOAD_DIR" ] || die "Missing payload directory: $PAYLOAD_DIR"
[ -f "$PATCH_DIR/MANIFEST.sha256" ] || die "Missing MANIFEST.sha256"
[ -f "$PATCH_DIR/EXPECTED_V7.sha256" ] || die "Missing EXPECTED_V7.sha256"
[ -d "$WORKER_DIR" ] || die "Worker directory not found: $WORKER_DIR"
[ -f "$WORKER_DIR/.env" ] || die "Worker .env not found; refusing to continue"
[ -f "$WORKER_DIR/docker-compose.yml" ] || die "Worker docker-compose.yml not found"
[ -d "$WORKER_DIR/db" ] || die "Worker database directory is missing"
command -v docker >/dev/null 2>&1 || die "Docker is not installed"
docker compose version >/dev/null 2>&1 || die "Docker Compose v2 is required"

log "Verifying patch payload..."
(cd "$PATCH_DIR" && sha256sum -c MANIFEST.sha256)

v7_matches=1
while read -r expected relative; do
  [ -n "$relative" ] || continue
  if [ ! -f "$WORKER_DIR/$relative" ]; then
    v7_matches=0
    break
  fi
  actual="$(sha256sum "$WORKER_DIR/$relative" | awk '{print $1}')"
  if [ "$actual" != "$expected" ]; then
    v7_matches=0
    break
  fi
done < "$PATCH_DIR/EXPECTED_V7.sha256"

v8_matches=1
while IFS= read -r relative; do
  [ -n "$relative" ] || continue
  if [ ! -f "$WORKER_DIR/$relative" ] \
     || ! cmp -s "$PAYLOAD_DIR/$relative" "$WORKER_DIR/$relative"; then
    v8_matches=0
    break
  fi
done < <(payload_files)

if [ "$v7_matches" -ne 1 ] && [ "$v8_matches" -ne 1 ]; then
  die "Installed runtime differs from both the supplied V7 and this V8 payload. No files were changed."
fi

stamp="$(date +%Y%m%d-%H%M%S)"
BACKUP_DIR="${WORKER_DIR}.backup-before-v8-${stamp}"
mkdir -p "$BACKUP_DIR/files"

log "Stopping Worker 1 and creating a recoverable backup..."
cd "$WORKER_DIR"
docker compose stop "$SERVICE"
WORKER_STOPPED=1

while IFS= read -r relative; do
  [ -n "$relative" ] || continue
  if [ -e "$WORKER_DIR/$relative" ]; then
    mkdir -p "$BACKUP_DIR/files/$(dirname "$relative")"
    cp -a "$WORKER_DIR/$relative" "$BACKUP_DIR/files/$relative"
  fi
done < <(payload_files)

cp -a --reflink=auto "$WORKER_DIR/db" "$BACKUP_DIR/db"
ROLLBACK_READY=1

log "Installing V8 runtime files without touching .env or sessions..."
rsync -a "$PAYLOAD_DIR/" "$WORKER_DIR/"

cd "$WORKER_DIR"
python3 -m py_compile \
  filter_policy_v8.py \
  bulk_configure_student_filter.py \
  overrides/ai/gemini_provider.py \
  worker_tools/prefilter_recall_selftest.py \
  worker_tools/classifier_contract_selftest.py \
  worker_tools/evaluate_gemini_filter.py \
  worker_tools/verify_runtime.py

python3 worker_tools/prefilter_recall_selftest.py
docker compose config >/dev/null

log "Running V8 zero-network contract/cache tests..."
docker compose run --rm -T --no-deps "$SERVICE" \
  python /app/worker_tools/classifier_contract_selftest.py
docker compose run --rm -T --no-deps "$SERVICE" \
  python /app/worker_tools/evaluate_gemini_filter.py --validate-only

output_raw="$(sed -n 's/^OUTPUT_GROUP_RAW_ID=//p' "$WORKER_DIR/.env" | tail -n1 | tr -d '\r[:space:]')"
[[ "$output_raw" =~ ^-?[0-9]+$ ]] \
  || die "OUTPUT_GROUP_RAW_ID is missing or invalid in the existing .env"

log "Applying the V8 literal/regex policy to existing forwarding rules..."
docker compose run --rm -T --no-deps "$SERVICE" \
  python /app/bulk_configure_student_filter.py --target-id "$output_raw" --apply

log "Starting the updated worker..."
docker compose up -d --force-recreate "$SERVICE"
sleep 8

running="$(docker inspect -f '{{.State.Running}}' "$CONTAINER" 2>/dev/null || echo false)"
[ "$running" = "true" ] || die "Updated worker is not running"

docker compose exec -T "$SERVICE" \
  python /app/worker_tools/verify_runtime.py

ROLLBACK_READY=0
WORKER_STOPPED=0
trap - ERR

cat <<EOF

============================================================
WORKER 1 V8 DATA-DRIVEN PATCH INSTALLED
============================================================
Worker:  $WORKER_DIR
Backup:  $BACKUP_DIR
.env:    preserved and never displayed
DB:      backed up before policy migration
Cache:   privacy-safe hashed decision cache enabled

Optional 64-call live Gemini benchmark:
  cd $WORKER_DIR
  docker compose exec -T $SERVICE \
    python /app/worker_tools/evaluate_gemini_filter.py \
    --output /app/logs/gemini_v8_regression_report.json
============================================================
EOF
