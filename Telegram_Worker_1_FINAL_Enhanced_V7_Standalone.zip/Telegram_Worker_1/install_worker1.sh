#!/usr/bin/env bash
set -Eeuo pipefail

WORKER_NUM="1"
BUNDLE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET_DIR="/opt/TelegramForwarder-worker${WORKER_NUM}"
REPO="https://github.com/Heavrnl/TelegramForwarder.git"
SERVICE="telegram-forwarder"
CONTAINER="telegram-forwarder-worker${WORKER_NUM}"

log()  { printf '\n\033[1;36m[+] %s\033[0m\n' "$*"; }
warn() { printf '\n\033[1;33m[!] %s\033[0m\n' "$*" >&2; }
die()  { printf '\n\033[1;31m[ERROR] %s\033[0m\n' "$*" >&2; exit 1; }

[ "${EUID:-$(id -u)}" -eq 0 ] || die "Run this installer as root."
[ -f "$BUNDLE_DIR/.env" ] || die "Missing bundle .env"

get_env() {
  local key="$1"
  sed -n "s/^${key}=//p" "$BUNDLE_DIR/.env" | tail -n1
}

for key in API_ID API_HASH PHONE_NUMBER BOT_TOKEN USER_ID ADMINS; do
  value="$(get_env "$key")"
  [ -n "$value" ] && [ "$value" != "CHANGE_ME" ] \
    || die "$key is not configured in $BUNDLE_DIR/.env"
done

OUTPUT_RAW="$(get_env OUTPUT_GROUP_RAW_ID)"
OUTPUT_NAME="$(get_env OUTPUT_GROUP_NAME)"
[ -n "$OUTPUT_RAW" ] || die "OUTPUT_GROUP_RAW_ID is missing"
[ -n "$OUTPUT_NAME" ] || die "OUTPUT_GROUP_NAME is missing"

# Validate 10 unique direct Gemini keys without printing them.
python3 - "$BUNDLE_DIR/.env" <<'PY_KEYS'
from pathlib import Path
import sys
p=Path(sys.argv[1])
value=''
for line in p.read_text(encoding='utf-8').splitlines():
    if line.startswith('GEMINI_API_KEYS='):
        value=line.split('=',1)[1].strip()
        break
keys=[]
for chunk in value.replace(';',',').split(','):
    k=chunk.strip()
    if k and k not in keys:
        keys.append(k)
if len(keys) != 10:
    raise SystemExit(f'ERROR: expected 10 unique GEMINI_API_KEYS, found {len(keys)}')
print('Gemini keys: 10 unique keys configured')
PY_KEYS

log "Installing/checking prerequisites..."
export DEBIAN_FRONTEND=noninteractive
if command -v apt-get >/dev/null 2>&1; then
  apt-get update -y
  apt-get install -y git ca-certificates curl python3 rsync
  if ! command -v docker >/dev/null 2>&1; then
    apt-get install -y docker.io
  fi
  systemctl enable --now docker >/dev/null 2>&1 || true
  if ! docker compose version >/dev/null 2>&1; then
    apt-get install -y docker-compose-plugin 2>/dev/null \
      || apt-get install -y docker-compose-v2 2>/dev/null \
      || apt-get install -y docker-compose
  fi
else
  die "This automated installer currently supports apt-based Debian/Ubuntu."
fi

docker compose version >/dev/null 2>&1 || die "Docker Compose v2 is required."

log "Preparing fresh Heavrnl checkout for standalone Worker ${WORKER_NUM}..."
if [ -d "$TARGET_DIR" ]; then
  BACKUP="${TARGET_DIR}.before-reinstall-$(date +%Y%m%d-%H%M%S)"
  mv "$TARGET_DIR" "$BACKUP"
  warn "Existing $TARGET_DIR moved to $BACKUP"
fi

git clone --depth 1 "$REPO" "$TARGET_DIR"

mkdir -p \
  "$TARGET_DIR/overrides/ai" \
  "$TARGET_DIR/overrides/filters" \
  "$TARGET_DIR/overrides/handlers" \
  "$TARGET_DIR/overrides/models" \
  "$TARGET_DIR/overrides/utils" \
  "$TARGET_DIR/worker_tools" \
  "$TARGET_DIR/db" \
  "$TARGET_DIR/logs" \
  "$TARGET_DIR/sessions" \
  "$TARGET_DIR/temp" \
  "$TARGET_DIR/ufb/config" \
  "$TARGET_DIR/rss/data" \
  "$TARGET_DIR/rss/media"

cp "$BUNDLE_DIR/.env" "$TARGET_DIR/.env"
chmod 600 "$TARGET_DIR/.env"
cp "$BUNDLE_DIR/docker-compose.yml" "$TARGET_DIR/docker-compose.yml"
cp "$BUNDLE_DIR/bulk_bind_all.py" "$TARGET_DIR/bulk_bind_all.py"
cp "$BUNDLE_DIR/bulk_configure_student_filter.py" "$TARGET_DIR/bulk_configure_student_filter.py"
rsync -a "$BUNDLE_DIR/config/" "$TARGET_DIR/config/"
rsync -a "$BUNDLE_DIR/overrides/" "$TARGET_DIR/overrides/"
rsync -a "$BUNDLE_DIR/worker_tools/" "$TARGET_DIR/worker_tools/"

cd "$TARGET_DIR"

log "Validating final enhanced files..."
python3 -m py_compile \
  overrides/ai/gemini_provider.py \
  overrides/auto_bind_new_chat.py \
  overrides/filters/info_filter.py \
  overrides/filters/sender_filter.py \
  overrides/handlers/bot_handler.py \
  overrides/message_listener.py \
  overrides/models/models.py \
  overrides/native_forward_runtime.py \
  overrides/utils/common.py \
  worker_tools/authorize_user.py \
  worker_tools/discover_target.py \
  worker_tools/verify_runtime.py \
  worker_tools/prefilter_recall_selftest.py \
  bulk_bind_all.py \
  bulk_configure_student_filter.py

docker compose config >/dev/null

log "Verifying important examples hit the LOCAL pre-AI whitelist..."
python3 worker_tools/prefilter_recall_selftest.py

docker compose pull "$SERVICE"

log "Verifying Heavrnl runs LOCAL KeywordFilter BEFORE AIFilter..."
docker compose run --rm -T --no-deps "$SERVICE" python - <<'PY_ORDER'
from pathlib import Path
p = Path('/app/filters/process.py')
text = p.read_text(encoding='utf-8')
kw = text.find('filter_chain.add_filter(KeywordFilter())')
ai = text.find('filter_chain.add_filter(AIFilter())')
if kw < 0 or ai < 0:
    raise SystemExit('ERROR: could not verify KeywordFilter/AIFilter order in /app/filters/process.py')
if kw >= ai:
    raise SystemExit('ERROR: AIFilter appears before KeywordFilter; refusing deployment')
print('FILTER_ORDER=LOCAL_KEYWORD_BEFORE_AI')
print('ZERO_GEMINI_FOR_LOCAL_NON_MATCHES=YES')
PY_ORDER

log "Verifying LOCAL Gemini 10-key provider (zero Gemini requests)..."
docker compose run --rm -T --no-deps "$SERVICE" python - <<'PY_POOL'
import sys
sys.path.insert(0, '/app')
from dotenv import load_dotenv
load_dotenv('/app/.env', override=True)
from ai.gemini_provider import MULTI_KEY_GEMINI_POOL, _load_api_keys, _candidate_indices
keys=_load_api_keys()
assert MULTI_KEY_GEMINI_POOL is True
assert len(keys)==10 and len(set(keys))==10
seq=[]
for _ in range(12):
    c=_candidate_indices(keys, 10)
    assert c
    seq.append(c[0]+1)
print('LOCAL_GEMINI_POOL=OK')
print('KEY_COUNT=', len(keys))
print('ROUND_ROBIN_DRY=', seq)
PY_POOL

log "Authorizing Telegram USER account for Worker ${WORKER_NUM}..."
echo "Telegram may ask once for login code and 2FA password."
docker compose run --rm --no-deps "$SERVICE" \
  python /app/worker_tools/authorize_user.py

log "Discovering exact native target ID for ${OUTPUT_NAME}..."
DISCOVERY="$(
  docker compose run --rm -T --no-deps "$SERVICE" \
    python /app/worker_tools/discover_target.py
)"
printf '%s\n' "$DISCOVERY"

NATIVE_TARGET="$(
  printf '%s\n' "$DISCOVERY" \
    | sed -n 's/^NATIVE_QUOTE_TARGET=//p' \
    | tail -n1 \
    | tr -d '\r[:space:]'
)"
case "$NATIVE_TARGET" in
  -*) ;;
  *) die "Could not discover a valid marked Telegram target ID." ;;
esac

python3 - "$TARGET_DIR/.env" "$NATIVE_TARGET" "$OUTPUT_RAW" <<'PY_ENV'
from pathlib import Path
import sys
path=Path(sys.argv[1])
wanted={'NATIVE_QUOTE_TARGET':sys.argv[2], 'AUTO_BIND_TARGET_ID':sys.argv[3]}
lines=path.read_text(encoding='utf-8').splitlines()
out=[]; seen=set()
for line in lines:
    for k,v in wanted.items():
        if line.startswith(k+'='):
            out.append(f'{k}={v}'); seen.add(k); break
    else:
        out.append(line)
for k,v in wanted.items():
    if k not in seen:
        out.append(f'{k}={v}')
path.write_text('\n'.join(out)+'\n', encoding='utf-8')
PY_ENV

log "Binding every visible Telegram group/channel to ${OUTPUT_NAME}..."
docker compose run --rm -T --no-deps "$SERVICE" \
  python /app/bulk_bind_all.py --target-id "$OUTPUT_RAW" --apply

log "Applying high-recall LOCAL prefilter + semantic Gemini filter..."
docker compose run --rm -T --no-deps "$SERVICE" \
  python /app/bulk_configure_student_filter.py --target-id "$OUTPUT_RAW" --apply

log "Starting Worker ${WORKER_NUM}..."
docker compose up -d --force-recreate "$SERVICE"

# Wait for a stable main process; catch restart loops before declaring success.
log "Waiting for stable runtime..."
sleep 8
R1="$(docker inspect -f '{{.RestartCount}}' "$CONTAINER" 2>/dev/null || echo 999)"
RUN1="$(docker inspect -f '{{.State.Running}}' "$CONTAINER" 2>/dev/null || echo false)"
sleep 5
R2="$(docker inspect -f '{{.RestartCount}}' "$CONTAINER" 2>/dev/null || echo 999)"
RUN2="$(docker inspect -f '{{.State.Running}}' "$CONTAINER" 2>/dev/null || echo false)"

if [ "$RUN2" != "true" ] || [ "$R2" != "$R1" ]; then
  docker compose ps || true
  docker compose logs --tail=160 "$SERVICE" || true
  die "Worker is not stable (running=$RUN2 restart_count=$R2)."
fi

log "Runtime verification..."
docker compose exec -T "$SERVICE" \
  python /app/worker_tools/verify_runtime.py

log "Worker ${WORKER_NUM} status..."
docker compose ps

cat <<EOF

============================================================
TELEGRAM WORKER ${WORKER_NUM} INSTALLED - STANDALONE AI
============================================================

Project:
  $TARGET_DIR

Output:
  $OUTPUT_NAME
  raw DB ID: $OUTPUT_RAW
  native marked ID: $NATIVE_TARGET

Gemini:
  LOCAL 10-key round-robin/failover pool
  NO shared gateway
  max parallel: $(get_env GEMINI_MAX_PARALLEL_REQUESTS)
  per-message max failover attempts: $(get_env GEMINI_MAX_KEY_ATTEMPTS)
  request timeout: $(get_env GEMINI_REQUEST_TIMEOUT_SECONDS)s
  fail-open on total AI outage: $(get_env GEMINI_FAIL_OPEN)

Logs:
  cd $TARGET_DIR
  docker compose logs -f --tail=100 $SERVICE

This worker has its own Telegram USER session, BOT session, SQLite DB,
logs, temp files and its own 10-key Gemini pool.
============================================================
EOF
