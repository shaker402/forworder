TELEGRAM WORKER 1 - FINAL STANDALONE ENHANCED BUILD
=====================================================

This package installs one isolated Heavrnl/TelegramForwarder worker on a
fresh Debian/Ubuntu VPS.

FINAL ARCHITECTURE
------------------
Telegram account -> local keyword prefilter -> local Gemini 10-key pool ->
semantic requester filter -> genuine Telegram native forward -> AI_filter ->
compact metadata reply.

NO SHARED GEMINI GATEWAY IS USED.

The .env in this package already contains the credentials supplied for this
worker. The installer does not rewrite API_ID/API_HASH/PHONE_NUMBER/BOT_TOKEN,
USER_ID/ADMINS or GEMINI_API_KEYS. It only replaces NATIVE_QUOTE_TARGET=AUTO
with the exact marked Telegram destination ID discovered from the logged-in
user account.

PERFORMANCE / RELIABILITY
-------------------------
- 10 local Gemini API keys, round-robin across normal requests.
- One normal Telegram message makes ONE Gemini call, not 10 duplicate calls.
- Up to 10 Gemini calls may be active concurrently.
- A failed key is cooled down and another healthy key is tried.
- A single message tries at most 4 keys, limiting long retry/backlog chains.
- GEMINI_FAIL_OPEN=true: if all attempted AI calls fail, the already-local-
  matched candidate is preserved instead of silently losing an important request.
- Gemini timeout is 15 seconds per attempted network request.
- Gemini HTTP work runs outside Telethon's asyncio event loop.
- Local keyword filtering happens before Gemini.
- Expanded high-recall local prefilter runs BEFORE Gemini. The semantic prompt
  uses real wanted/unwanted examples to distinguish genuine academic requests from
  answers, administration, IT support, transport/logistics and advertisements.
- Shared SQLite engine/WAL performance override is retained.
- High-volume diagnostic logs use DEBUG where practical.
- Docker logs rotate at 10 MB x 3 files.
- Automatic onboarding of newly seen groups/channels is retained.
- Installer runs an offline prefilter recall self-test before deployment.
- Installer inspects Heavrnl filters/process.py and refuses deployment if AIFilter appears before KeywordFilter.

FORWARDING
----------
- Accepted content uses the authenticated Telegram USER client for native
  forward_messages(), preserving Telegram's genuine "Forwarded from" header.
- Compact metadata includes Sender, Telegram ID, Username, Source, Worker,
  original sent time, and the safest available original-message link.
- Public groups/channels use https://t.me/<username>/<message>.
- Private channels/supergroups use https://t.me/c/<raw-channel-id>/<message>.
- Legacy basic Telegram groups do not have an official per-message t.me/c
  private-post link. For those, metadata says that the per-message link is
  unavailable instead of generating a misleading "no access" URL.
- If native forwarding is blocked by Telegram content protection, the
  existing USER-copy fallback remains enabled.

FRESH VPS INSTALL
-----------------
1. Extract this ZIP.
2. Enter the Telegram_Worker_1 directory.
3. Run as root:

   chmod +x install_worker1.sh
   ./install_worker1.sh

4. Telegram may request a login code and 2FA password once.
5. The installer will find AI_filter, bind every visible group/channel, apply
   the final keyword+AI rules, start the worker, detect restart loops, and run
   a final runtime verification.

INSTALL LOCATION
----------------
/opt/TelegramForwarder-worker1

CONTAINER
---------
telegram-forwarder-worker1

LOGS
----
cd /opt/TelegramForwarder-worker1
docker compose ps
docker compose logs -f --tail=100 telegram-forwarder

ERROR-ONLY VIEW
---------------
docker compose logs --tail=300 telegram-forwarder | \
  grep -Ei 'traceback|error|exception|failed|429|forbidden|timeout'

MANAGEMENT BOT NOTE
-------------------
The destination is AI_filter rather than the private management-bot chat.
Therefore /settings without a rule ID in the bot DM can report no rules for
that current chat. Use /lr and /settings <rule_id>, or manage from AI_filter
if the management bot is intentionally added there.
