#!/usr/bin/env python3
"""Exercise installer rollback with an isolated target and mocked Docker."""

import os
import shutil
import subprocess
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main():
    temporary = Path(tempfile.mkdtemp(prefix="worker2-installer-test-"))
    try:
        target = temporary / "existing-worker"
        target.mkdir()
        (target / "OLD_TREE_MARKER").write_text("preserve me\n", encoding="utf-8")
        (target / "docker-compose.yml").write_text(
            "services:\n  telegram-forwarder:\n    image: old:test\n",
            encoding="utf-8",
        )
        keys = ",".join(f"test-slot-{index}" for index in range(1, 11))
        (target / ".env").write_text(
            "\n".join(
                (
                    "API_ID=12345",
                    "API_HASH=0123456789abcdef0123456789abcdef",
                    "PHONE_NUMBER=+10000000000",
                    "BOT_TOKEN=123456:test",
                    "USER_ID=12345",
                    f"GEMINI_API_KEYS={keys}",
                    "GEMINI_API_BASE=",
                    "OUTPUT_GROUP_RAW_ID=555",
                    "OUTPUT_GROUP_NAME=test-output",
                )
            )
            + "\n",
            encoding="utf-8",
        )

        mock_bin = temporary / "bin"
        mock_bin.mkdir()
        docker = mock_bin / "docker"
        docker.write_text(
            "#!/bin/sh\n"
            "if [ \"$1\" = compose ] && [ \"$2\" = version ]; then exit 0; fi\n"
            "if [ \"$1\" = compose ] && [ \"$2\" = build ]; then exit 17; fi\n"
            "exit 0\n",
            encoding="utf-8",
        )
        docker.chmod(0o755)

        environment = os.environ.copy()
        environment["PATH"] = str(mock_bin) + os.pathsep + environment["PATH"]
        completed = subprocess.run(
            [
                "bash",
                str(ROOT / "install_worker2.sh"),
                "--target-dir",
                str(target),
                "--skip-live-gemini-check",
                "--skip-telegram-check",
                "--skip-bind",
            ],
            cwd=ROOT,
            env=environment,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=60,
        )
        assert completed.returncode != 0, completed.stdout
        assert (target / "OLD_TREE_MARKER").read_text(encoding="utf-8") == "preserve me\n"
        assert not (target / "native_forward.py").exists()
        assert any(temporary.glob("existing-worker.failed-v8-*"))
        print("INSTALLER_FORCED_BUILD_FAILURE=OBSERVED")
        print("INSTALLER_PREVIOUS_TREE_RESTORED=OK")
        print("INSTALLER_FAILED_NEW_TREE_PRESERVED=OK")
        print("REAL_DOCKER_CALLS=0")
    finally:
        shutil.rmtree(temporary, ignore_errors=True)


if __name__ == "__main__":
    main()
