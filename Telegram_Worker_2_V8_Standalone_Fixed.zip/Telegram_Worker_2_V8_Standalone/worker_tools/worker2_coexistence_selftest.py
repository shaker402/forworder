#!/usr/bin/env python3
"""Zero-network checks that Worker 2 cannot collide with Worker 1."""

from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def require(text, fragment, description):
    if fragment not in text:
        raise SystemExit(f"Missing {description}: {fragment}")


def forbid(text, fragment, description):
    if fragment in text:
        raise SystemExit(f"Unexpected {description}: {fragment}")


def main():
    compose = (ROOT / "docker-compose.yml").read_text(encoding="utf-8")
    installer = (ROOT / "install_worker2.sh").read_text(encoding="utf-8")
    runtime = (ROOT / "main.py").read_text(encoding="utf-8")
    native = (ROOT / "native_forward.py").read_text(encoding="utf-8")

    require(
        compose,
        "image: telegram-forwarder-worker2:v8-standalone",
        "Worker 2 image",
    )
    require(
        compose,
        "container_name: telegram-forwarder-worker2",
        "Worker 2 container",
    )
    require(compose, "WORKER_INSTANCE: worker2", "Worker 2 environment marker")
    forbid(compose, "telegram-forwarder-worker1", "Worker 1 container/image reuse")
    forbid(compose, "ports:", "host port binding")

    require(
        installer,
        'TARGET_DIR="/opt/TelegramForwarder-worker2"',
        "Worker 2 installation directory",
    )
    require(
        installer,
        'CONTAINER="telegram-forwarder-worker2"',
        "Worker 2 installer container",
    )
    require(
        installer,
        'WORKER1_ENV="/opt/TelegramForwarder-worker1/.env"',
        "Worker 1 coexistence check",
    )
    require(installer, "shared destination", "shared-destination preflight")

    require(runtime, "worker2-runtime.lock", "Worker 2 session lock")
    forbid(runtime, "worker1-runtime.lock", "Worker 1 session lock reuse")
    require(native, '"Telegram Worker 2"', "Worker 2 reply attribution")

    print("WORKER2_CONTAINER_ISOLATION=OK")
    print("WORKER2_IMAGE_ISOLATION=OK")
    print("WORKER2_SESSION_LOCK_ISOLATION=OK")
    print("WORKER1_SHARED_DESTINATION_PREFLIGHT=OK")
    print("WORKER2_SCREENSHOT_REPLY_LABEL=OK")
    print("HOST_PORT_COLLISIONS=0")
    print("NO_NETWORK_REQUESTS=YES")


if __name__ == "__main__":
    main()
