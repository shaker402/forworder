#!/usr/bin/env python3
"""Exercise successful state migration with an isolated target and mocked Docker."""

import os
import shutil
import subprocess
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main():
    temporary = Path(tempfile.mkdtemp(prefix="worker2-installer-success-"))
    try:
        target = temporary / "existing-worker"
        (target / "db").mkdir(parents=True)
        (target / "sessions").mkdir()
        (target / "OLD_TREE_MARKER").write_text("old\n", encoding="utf-8")
        (target / "db" / "state.db").write_bytes(b"database-state")
        (target / "sessions" / "user.session").write_bytes(b"session-state")
        (target / "docker-compose.yml").write_text(
            "services:\n  telegram-forwarder:\n    image: old:test\n",
            encoding="utf-8",
        )
        keys = ",".join(f"test-slot-{index}" for index in range(1, 11))
        original_hash = "0123456789abcdef0123456789abcdef"
        (target / ".env").write_text(
            "\n".join(
                (
                    "API_ID=12345",
                    f"API_HASH={original_hash}",
                    "PHONE_NUMBER=+10000000000",
                    "BOT_TOKEN=123456:test",
                    "USER_ID=12345",
                    f"GEMINI_API_KEYS={keys}",
                    "GEMINI_API_BASE=",
                    "OUTPUT_GROUP_RAW_ID=555",
                    "OUTPUT_GROUP_NAME=test-output",
                    "NATIVE_QUOTE_TARGET=-100555",
                    "NATIVE_QUOTE_DETAILS=false",
                    "AUTO_BIND_TARGET_ID=555",
                )
            )
            + "\n",
            encoding="utf-8",
        )

        mock_bin = temporary / "bin"
        mock_bin.mkdir()
        docker = mock_bin / "docker"
        docker.write_text(
            "#!/bin/sh\n"
            "if [ \"$1\" = compose ] && [ \"$2\" = version ]; then exit 0; fi\n"
            "if [ \"$1\" = inspect ]; then\n"
            "  case \"$*\" in\n"
            "    *State.Running*) echo true ;;\n"
            "    *State.Health*) echo healthy ;;\n"
            "  esac\n"
            "fi\n"
            "exit 0\n",
            encoding="utf-8",
        )
        docker.chmod(0o755)

        environment = os.environ.copy()
        environment["PATH"] = str(mock_bin) + os.pathsep + environment["PATH"]
        completed = subprocess.run(
            [
                "bash",
                str(ROOT / "install_worker2.sh"),
                "--target-dir",
                str(target),
                "--skip-live-gemini-check",
                "--skip-telegram-check",
                "--skip-bind",
            ],
            cwd=ROOT,
            env=environment,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=60,
        )
        assert completed.returncode == 0, completed.stdout
        assert (target / "native_forward.py").is_file()
        assert (target / "db" / "state.db").read_bytes() == b"database-state"
        assert (target / "sessions" / "user.session").read_bytes() == b"session-state"
        values = {}
        for line in (target / ".env").read_text(encoding="utf-8").splitlines():
            if "=" in line and not line.startswith("#"):
                name, value = line.split("=", 1)
                values[name] = value
        assert values["API_HASH"] == original_hash
        assert values["GEMINI_REQUIRED_KEY_COUNT"] == "10"
        assert values["NATIVE_QUOTE_FORWARD"] == "true"
        assert values["NATIVE_QUOTE_DETAILS"] == "true"
        assert values["NATIVE_QUOTE_CAPTURED_BY"] == "Telegram Worker 2"
        assert values["WORKER_LABEL"] == "Telegram Worker 2"
        backups = list(temporary.glob("existing-worker.backup-before-v8-*"))
        assert len(backups) == 1
        assert (backups[0] / "OLD_TREE_MARKER").is_file()
        print("INSTALLER_SUCCESS_PATH=OK")
        print("INSTALLER_DATABASE_STATE_MIGRATED=OK")
        print("INSTALLER_TELETHON_SESSION_MIGRATED=OK")
        print("INSTALLER_CREDENTIAL_VALUE_PRESERVED=OK")
        print("INSTALLER_BACKUP_RETAINED=OK")
        print("REAL_DOCKER_CALLS=0")
    finally:
        shutil.rmtree(temporary, ignore_errors=True)


if __name__ == "__main__":
    main()
