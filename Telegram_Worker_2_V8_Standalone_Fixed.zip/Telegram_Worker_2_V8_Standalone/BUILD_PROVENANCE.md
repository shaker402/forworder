# Build provenance

This Worker 2 rebuild used the user-supplied local archives. No live repository
checkout is required during installation.

| Input | SHA-256 | Use |
|---|---|---|
| `TelegramForwarder-main(1).zip` | `794b5b43ce460d4c21ea3b721cccf7b385f967cf60123ad32e168b6549bdb2cb` | Complete upstream 1.7.2 baseline |
| `Telegram_Worker_1_V8_Standalone_Fixed.zip` | `63f3e4e7d80287ee727ffd98e4e3562e0bfe3e24ac33573ae82329fd17fc98a2` | Validated V8 implementation and screenshot-style reply behavior |
| `Telegram_Worker_2_FINAL_Enhanced_V7_Standalone.zip` | `c6fd4fbcc83b0354e4bb90583a1d843cc450533fd0b53e9c153faa98ce5e9a94` | Worker 2 Telegram identity, independent Gemini pool, destination, and migration requirements |

Worker 2 uses the same application behavior and destination policy as Worker 1,
but has its own container, image tag, Compose project, database, sessions,
runtime lock, logs, temporary media, Telegram identity, bot, and Gemini pool.
The separate environment file is never embedded in the source ZIP.
